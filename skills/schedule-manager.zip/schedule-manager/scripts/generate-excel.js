const XLSX = require('xlsx');
const fs = require('fs');

const employees = Array.from({ length: 25 }, (_, i) => `员工${i + 1}`);

const SHIFTS = {
  SHIFT1: '7点班',
  SHIFT2: '10点班',
  SHIFT3: '14点班',
  SHIFT4: '16点班'
};

const SHIFT_TYPES = Object.values(SHIFTS);
const DAYS = 30;
const MONTH = 4;
const MAX_ITERATIONS = 2000;

function calculateRestDays(daysWorked) {
  return Math.round((daysWorked / 7) * 2);
}

function getWeekInfo(week) {
  const weekStart = (week - 1) * 7 + 1;
  const weekEnd = Math.min(week * 7, DAYS);
  return { weekStart, weekEnd, weekDays: weekEnd - weekStart + 1 };
}

function generateSchedule() {
  const schedule = {};
  
  employees.forEach(emp => {
    schedule[emp] = [];
  });

  const targetWorkDays = 22;

  for (const emp of employees) {
    const empSchedule = schedule[emp];
    const assignedDays = new Set();
    let shuffledWeeks = [1,2,3,4,5].sort(() => Math.random() - 0.5);
    
    for (const week of shuffledWeeks) {
      const { weekStart, weekEnd, weekDays } = getWeekInfo(week);
      
      const requiredRest = calculateRestDays(weekDays);
      const requiredWork = weekDays - requiredRest;
      
      const availableDays = [];
      for (let day = weekStart; day <= weekEnd; day++) {
        if (!assignedDays.has(day)) {
          availableDays.push(day);
        }
      }
      
      availableDays.sort(() => Math.random() - 0.5);
      
      let daysWorked = 0;
      for (const day of availableDays) {
        if (daysWorked >= requiredWork) break;
        
        const shiftCandidates = [SHIFTS.SHIFT1, SHIFTS.SHIFT2, SHIFTS.SHIFT3, SHIFTS.SHIFT4]
          .sort(() => Math.random() - 0.5);
        
        for (const shift of shiftCandidates) {
          const lastEntry = empSchedule.length > 0 ? empSchedule[empSchedule.length - 1] : null;
          const lastShift = lastEntry ? lastEntry.shift : null;
          const lastDay = lastEntry ? lastEntry.day : 0;
          
          if (lastShift === SHIFTS.SHIFT4 && day === lastDay + 1) continue;
          
          const weeklyWorked = empSchedule.filter(s => s.week === week).length + 1;
          const weeklyRest = weekDays - weeklyWorked;
          const allowedRest = calculateRestDays(weeklyWorked);
          
          if (weeklyRest >= allowedRest) {
            empSchedule.push({ day, shift, week });
            assignedDays.add(day);
            daysWorked++;
            break;
          }
        }
      }
    }
  }

  return schedule;
}

function checkShiftCounts(schedule) {
  let allValid = true;
  const issues = [];
  
  for (let day = 1; day <= DAYS; day++) {
    for (const shift of SHIFT_TYPES) {
      const count = employees.filter(emp => 
        schedule[emp].some(s => s.day === day && s.shift === shift)
      ).length;
      
      if (count < 1) {
        allValid = false;
        issues.push(`${day}日${shift}没有人`);
      }
    }
  }
  
  return { valid: allValid, issues };
}

function generateExcel(schedule) {
  const dayNames = ['日', '一', '二', '三', '四', '五', '六'];

  const scheduleData = [];
  const header = ['员工'];
  for (let day = 1; day <= DAYS; day++) {
    const dayOfWeek = dayNames[(day - 1) % 7];
    header.push(`${MONTH}月${day}日(${dayOfWeek})`);
  }
  scheduleData.push(header);

  employees.forEach(emp => {
    const row = [emp];
    for (let day = 1; day <= DAYS; day++) {
      const shift = schedule[emp].find(s => s.day === day);
      row.push(shift ? shift.shift : '---');
    }
    scheduleData.push(row);
  });

  const employeeStats = [];
  employeeStats.push(['员工', '值班天数', '休息天数', '7点班', '10点班', '14点班', '16点班']);
  
  employees.forEach(emp => {
    const shifts = schedule[emp];
    const workedDays = shifts.length;
    const restDays = DAYS - workedDays;
    const shift1Count = shifts.filter(s => s.shift === '7点班').length;
    const shift2Count = shifts.filter(s => s.shift === '10点班').length;
    const shift3Count = shifts.filter(s => s.shift === '14点班').length;
    const shift4Count = shifts.filter(s => s.shift === '16点班').length;
    employeeStats.push([emp, workedDays, restDays, shift1Count, shift2Count, shift3Count, shift4Count]);
  });

  const workbook = XLSX.utils.book_new();

  const scheduleSheet = XLSX.utils.aoa_to_sheet(scheduleData);
  const colWidths = [{ wch: 10 }];
  for (let i = 0; i < DAYS; i++) {
    colWidths.push({ wch: 12 });
  }
  scheduleSheet['!cols'] = colWidths;

  for (let row = 1; row <= employees.length; row++) {
    for (let col = 1; col <= DAYS; col++) {
      const cellAddr = XLSX.utils.encode_cell({ r: row, c: col });
      const cellValue = scheduleSheet[cellAddr]?.v;
      if (cellValue === '7点班') {
        scheduleSheet[cellAddr].s = { alignment: { horizontal: 'left' } };
      } else if (cellValue === '10点班') {
        scheduleSheet[cellAddr].s = { alignment: { horizontal: 'center' } };
      } else if (cellValue === '14点班') {
        scheduleSheet[cellAddr].s = { alignment: { horizontal: 'right' } };
      }
    }
  }

  XLSX.utils.book_append_sheet(workbook, scheduleSheet, '排班表');

  const statsSheet = XLSX.utils.aoa_to_sheet(employeeStats);
  statsSheet['!cols'] = [{ wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(workbook, statsSheet, '员工统计');

  const weekStats = [];
  weekStats.push(['周次', '天数', '应工作天数', '应休息天数', '检查结果']);
  
  for (let week = 1; week <= 5; week++) {
    const { weekStart, weekEnd, weekDays } = getWeekInfo(week);
    const requiredRest = calculateRestDays(weekDays);
    const requiredWork = weekDays - requiredRest;
    
    let allPass = true;
    employees.forEach(emp => {
      const weekShifts = schedule[emp].filter(s => s.week === week);
      const worked = weekShifts.length;
      const rest = weekDays - worked;
      if (rest > requiredRest) allPass = false;
    });
    
    weekStats.push([`第${week}周`, weekDays, requiredWork, requiredRest, allPass ? '通过' : '未通过']);
  }
  
  const weekSheet = XLSX.utils.aoa_to_sheet(weekStats);
  weekSheet['!cols'] = [{ wch: 10 }, { wch: 8 }, { wch: 12 }, { wch: 12 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(workbook, weekSheet, '周规则检查');

  const shiftNames = SHIFT_TYPES.map(s => s.replace('点班', '')).join('-');
  const fileName = `排班表_${MONTH}月_${employees.length}人_${shiftNames}点班.xlsx`;
  const filePath = `/Users/juzisang/Library/Application Support/oDesk/workspaces/oDesk-schedule-manager/${fileName}`;
  XLSX.writeFile(workbook, filePath);
  console.log(`Excel文件已生成: ${fileName}`);
}

let schedule = null;
let iteration = 0;

while (iteration < MAX_ITERATIONS) {
  iteration++;
  schedule = generateSchedule();
  const result = checkShiftCounts(schedule);
  
  if (result.valid) {
    console.log(`迭代次数: ${iteration}`);
    break;
  }
}

if (!checkShiftCounts(schedule).valid) {
  console.log(`达到最大迭代次数 ${MAX_ITERATIONS}`);
}

generateExcel(schedule);

function generateHtml(schedule) {
  const dayNames = ['日', '一', '二', '三', '四', '五', '六'];
  
  const colors = {
    '7点班': '#6BB2D6',
    '10点班': '#F5A623',
    '14点班': '#7ED321',
    '16点班': '#EB6877',
    '---': '#E8E8E8'
  };
  
  let html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>排班表</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    table { border-collapse: collapse; font-size: 12px; }
    th, td { border: 1px solid #ddd; padding: 6px; text-align: center; }
    th { background: #f5f5f5; }
    .emp-name { text-align: left; font-weight: bold; }
    td.rest { background: #E8E8E8; }
    .shift-7 { background: #6BB2D6; color: white; }
    .shift-10 { background: #F5A623; color: white; }
    .shift-14 { background: #7ED321; color: white; }
    .shift-16 { background: #EB6877; color: white; }
  </style>
</head>
<body>
  <h2>${MONTH}月排班表 - ${employees.length}人</h2>
  <table>
    <tr><th>员工</th>`;
  
  for (let day = 1; day <= DAYS; day++) {
    const dayOfWeek = dayNames[(day - 1) % 7];
    html += `<th>${MONTH}/${day}(${dayOfWeek})</th>`;
  }
  html += '</tr>';
  
  employees.forEach(emp => {
    html += `<tr><td class="emp-name">${emp}</td>`;
    for (let day = 1; day <= DAYS; day++) {
      const shift = schedule[emp].find(s => s.day === day);
      const shiftValue = shift ? shift.shift : '---';
      const colorClass = shiftValue === '---' ? 'rest' : `shift-${shiftValue.replace('点班', '')}`;
      html += `<td class="${colorClass}">${shiftValue}</td>`;
    }
    html += '</tr>';
  });
  
  html += `  </table>
  <p>图例: <span class="shift-7">7点班</span> <span class="shift-10">10点班</span> <span class="shift-14">14点班</span> <span class="shift-16">16点班</span></p>
</body>
</html>`;
  
  const shiftNames = SHIFT_TYPES.map(s => s.replace('点班', '')).join('-');
  const htmlFileName = `排班表_${MONTH}月_${employees.length}人_${shiftNames}点班.html`;
  const htmlPath = `/Users/juzisang/Library/Application Support/oDesk/workspaces/oDesk-schedule-manager/${htmlFileName}`;
  fs.writeFileSync(htmlPath, html);
  console.log(`HTML预览已生成: ${htmlFileName}`);
}

generateHtml(schedule);
