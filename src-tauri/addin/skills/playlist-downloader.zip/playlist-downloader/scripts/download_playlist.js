const fs = require('fs');
const { downloadSongFromUrl } = require('./gequbao_download.js');

function sanitizeFilename(value) {
  return String(value || 'download')
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
}

function getSelectedDownloads(songs) {
  return songs.flatMap(song => {
    const results = Array.isArray(song.searchResults) ? song.searchResults : [];
    return results
      .filter(result => result.download === true)
      .map(result => ({ song, result }));
  });
}

// 读取歌单
if (!fs.existsSync('playlist_songs.json')) {
  console.error('错误: 未找到 playlist_songs.json 文件');
  console.log('请先使用 playlist-candidate-generator 生成 playlist_songs.json 和候选结果。');
  process.exit(1);
}

const songs = JSON.parse(fs.readFileSync('playlist_songs.json', 'utf8'));

if (songs.length === 0) {
  console.error('歌单中没有歌曲');
  process.exit(1);
}

const selectedDownloads = getSelectedDownloads(songs);

if (selectedDownloads.length === 0) {
  console.log('没有找到需要下载的候选。');
  console.log('请先在 playlist_songs.json 的 searchResults 中，把要下载的候选设置为 "download": true。');
  process.exit(0);
}

console.log(`开始下载 ${selectedDownloads.length} 个已选择候选到 playlist/ 目录...\n`);

// 创建目标目录
if (!fs.existsSync('playlist')) {
  fs.mkdirSync('playlist');
}

// 下载每首歌
(async () => {
  for (let i = 0; i < selectedDownloads.length; i++) {
    const { song, result } = selectedDownloads[i];
    const songName = song.title;
    const selectedForSong = selectedDownloads.filter(item => item.song === song);
    const suffix = selectedForSong.length > 1 ? `.候选${result.index}` : '';
    const prefixedName = sanitizeFilename(`${song.index}.${songName}${suffix}`);
    const tempName = sanitizeFilename(`playlist_download_${song.index}_${result.index || i + 1}`);
    
    console.log(`[${i + 1}/${selectedDownloads.length}] 正在下载: ${songName} - ${song.artist}`);
    console.log(`候选: ${result.title || result.url}`);
    
    try {
      if (!result.url) {
        throw new Error('候选缺少 url 字段');
      }

      const downloadResult = await downloadSongFromUrl(result.url, tempName);
      
      // 等待文件生成
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      if (!downloadResult.mp3Path || !fs.existsSync(downloadResult.mp3Path)) {
        throw new Error('未成功下载 MP3 文件');
      }

      // 移动文件到playlist目录（带序号前缀）
      fs.renameSync(downloadResult.mp3Path, `playlist/${prefixedName}.mp3`);
      console.log(`✓ 已保存 playlist/${prefixedName}.mp3`);

      if (downloadResult.lyricPath && fs.existsSync(downloadResult.lyricPath)) {
        fs.renameSync(downloadResult.lyricPath, `playlist/${prefixedName}.lrc`);
        console.log(`✓ 已保存 playlist/${prefixedName}.lrc`);
      }
      
      console.log(`✓ ${songName} 下载完成\n`);
      console.log('='.repeat(50) + '\n');
      
    } catch (error) {
      console.error(`✗ ${songName} 下载失败: ${error.message}\n`);
      console.log('='.repeat(50) + '\n');
    }
    
    // 每首歌之间间隔一段时间，避免被封
    if (i < selectedDownloads.length - 1) {
      console.log('等待5秒后继续下一首...\n');
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  
  console.log('所有歌曲下载任务完成！');
  console.log('文件已保存到 playlist/ 目录');
})();
