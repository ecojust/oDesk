const puppeteer = require('puppeteer-core');
const fs = require('fs');
const http = require('http');
const https = require('https');

const CHROME_PATH = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';

function sanitizeFilename(value) {
  return String(value || 'download')
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
}

async function launchBrowser(options = {}) {
  return puppeteer.launch({
    executablePath: CHROME_PATH,
    headless: options.headless ?? true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
}

async function downloadSongFromUrl(songUrl, filenameBase, options = {}) {
  const browser = options.browser || await launchBrowser({ headless: options.headless ?? false });
  const shouldCloseBrowser = !options.browser;
  const page = options.page || await browser.newPage();
  const shouldClosePage = !options.page;

  try {
    return await downloadSongFromUrlWithPage(page, songUrl, filenameBase, options);
  } finally {
    if (shouldClosePage) {
      await page.close().catch(() => {});
    }
    if (shouldCloseBrowser) {
      await browser.close();
    }
  }
}

async function downloadSongFromUrlWithPage(page, songUrl, filenameBase, options = {}) {
  let mediaUrl = null;
  const safeFilenameBase = sanitizeFilename(filenameBase);
  const mp3Path = `${safeFilenameBase}.mp3`;
  const lyricPath = `${safeFilenameBase}.lrc`;
  const onRequest = request => {
    const url = request.url();
    if (url.includes('.mp3') || url.includes('.wav') || url.includes('audio') || url.includes('music')) {
      console.log('Media request:', url);
    }
    if (url.includes('.mp3') && (url.includes('kuwo') || url.includes('kuwo.cn') || url.includes('ning') || url.includes('cdn'))) {
      mediaUrl = url;
    }
    request.continue();
  };

  await page.setRequestInterception(true);
  page.on('request', onRequest);

  try {
    console.log('Opening song:', songUrl);
    await page.goto(songUrl, { waitUntil: 'networkidle2', timeout: options.timeout || 30000 });
    await new Promise(r => setTimeout(r, 3000));

    await page.waitForSelector('#player', { timeout: 5000 }).catch(() => {});
    const playerDiv = await page.$('#player');
    if (playerDiv) {
      const innerHtml = await page.$eval('#player', el => el.innerHTML).catch(() => '');
      console.log('Player div:', innerHtml.substring(0, 500));
    }

    console.log('Media URL:', mediaUrl);

    if (!mediaUrl) {
      const audioSrc = await page.$eval('audio', el => el.src).catch(() => '');
      if (audioSrc) {
        console.log('Audio src from page:', audioSrc);
        mediaUrl = audioSrc;
      }
      const videoSrc = await page.$eval('video', el => el.src).catch(() => '');
      if (videoSrc) {
        console.log('Video src from page:', videoSrc);
        if (videoSrc.includes('.mp3') || videoSrc.includes('.wav')) {
          mediaUrl = videoSrc;
        }
      }
      const allScripts = await page.$$eval('script', scripts => scripts.map(s => s.innerHTML).filter(s => s.includes('mp3') || s.includes('playurl') || s.includes('url')));
      if (allScripts.length > 0) {
        console.log('Found scripts with url:', allScripts[0].substring(0, 500));
      }
      const pageHtml = await page.content();
      const urlMatch = pageHtml.match(/["']([^"']*\.mp3[^"']*)["']/);
      if (urlMatch) {
        console.log('Found mp3 url in html:', urlMatch[1]);
        mediaUrl = urlMatch[1];
      }
    }

    if (mediaUrl) {
      console.log('Downloading MP3 to:', mp3Path);
      await downloadFile(mediaUrl, mp3Path);
      console.log('MP3 download complete!');
    } else {
      throw new Error('未找到音频地址');
    }

    const lrcHtml = await page.$eval('#content-lrc', el => el.innerHTML).catch(() => '');
    if (lrcHtml) {
      const lrcMatch = lrcHtml.match(/\[(\d{2}:\d{2}\.\d{2,3})\]([^\[]*)/g);
      if (lrcMatch) {
        const lrcLines = lrcMatch.map(line => line.replace(/<[^>]+>/g, '').trim());
        const validLines = lrcLines.filter(line => {
          if (!line) return false;
          const match = line.match(/^\[(\d{2}):(\d{2})\.\d{2,3}\](.+)$/);
          if (!match) return false;
          const content = match[3].trim();
          if (!content) return false;
          const minutes = parseInt(match[1]);
          const seconds = parseInt(match[2]);
          const totalSeconds = minutes * 60 + seconds;
          if (totalSeconds < 25) return false;
          if (content.includes('词：') || content.includes('曲：') || content.includes('编曲') || content.includes('制作') || 
              content.includes('合声') || content.includes('吉他') || content.includes('贝斯') || content.includes('鼓') ||
              content.includes('录音') || content.includes('混音') || content.includes('制作人') || content.includes('- ')) {
            return false;
          }
          return content.length > 0;
        });
        fs.writeFileSync(lyricPath, validLines.join('\n'), 'utf8');
        console.log('Lyric saved to:', lyricPath);
      }
    } else {
      console.log('No lyric found');
    }

    return {
      mp3Path,
      lyricPath: fs.existsSync(lyricPath) ? lyricPath : null,
      mediaUrl
    };
  } finally {
    page.off('request', onRequest);
    await page.setRequestInterception(false).catch(() => {});
  }
}

function downloadFile(url, filename) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const client = urlObj.protocol === 'https:' ? https : http;

    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'Referer': 'https://www.gequbao.net/'
      }
    };

    const req = client.get(options, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        resolve(downloadFile(res.headers.location, filename));
        return;
      }

      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode}`));
        return;
      }

      const file = fs.createWriteStream(filename);
      res.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve(filename);
      });
    });

    req.on('error', reject);
  });
}

module.exports = {
  downloadSongFromUrl,
  launchBrowser
};
