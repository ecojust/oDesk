---
name: playlist-downloader
description: 下载用户已选择的歌曲候选。仅当用户明确要求下载歌曲、下载已选歌曲、下载 playlist_songs.json 中已标记的候选、批量下载 download=true 的 searchResults 时使用此 skill。此 skill 不获取歌单、不生成候选，只读取 playlist_songs.json 中 searchResults[].download === true 的候选并下载 MP3 和歌词到 playlist/ 目录。
---

# 网易云歌单已选候选下载工具

读取 `playlist_songs.json`，只下载 `searchResults` 中 `download: true` 的候选。这个 skill 不负责获取歌单或生成候选；如果用户还没有候选数据，先使用 `playlist-candidate-generator`。

## 依赖安装

首次使用需要在项目根目录安装依赖：

```bash
npm install puppeteer-core
```

## 前置条件

`playlist_songs.json` 必须已经包含 `searchResults`，并且用户已经在要下载的候选上添加：

```json
"download": true
```

示例：

```json
{
  "index": 1,
  "source": "gequbao",
  "songId": "560262209",
  "songTitle": "明月高悬不照我",
  "singer": "树离suliii_",
  "title": "明月高悬不照我 - 树离suliii_",
  "url": "https://www.gequbao.net/search_music?...",
  "matchScore": 400,
  "download": true
}
```

如果用户只是要求“生成候选”或“先不要下载”，使用 `playlist-candidate-generator`，不要运行本 skill 的下载脚本。

## 下载命令

```bash
node .opencode/skill/playlist-downloader/scripts/download_playlist.js
```

功能：

- 读取 `playlist_songs.json` 文件
- 只下载 `searchResults` 中 `download` 属性为 `true` 的候选
- 如果没有任何候选设置 `download: true`，脚本会直接退出，不会下载
- 自动将下载的MP3和歌词文件整理到 `playlist/` 目录，文件名带序号前缀（如 `1.朵.mp3`、`1.朵.lrc`）
- 歌词文件保存为 `.lrc` 格式，自动过滤前25秒内容和歌曲信息行（词、曲、编曲等）

## 工作流程

1. **读取选择**：读取 `playlist_songs.json`
2. **筛选候选**：只收集 `searchResults[].download === true` 的候选
3. **下载选中项**：按候选 `url` 精确打开歌曲宝页面下载 MP3 和歌词
4. **文件整理**：将下载文件移动到 `playlist/` 目录，保留歌单序号

## 文件结构

```
.opencode/skill/playlist-downloader/
├── SKILL.md
├── package.json
└── scripts/
    ├── download_playlist.js # 下载已标记候选
    └── gequbao_download.js  # 歌曲宝下载模块
```

## 注意事项

- 每个候选下载间隔5秒，避免被网站限制
- 单首歌下载超时时间设置为3分钟
- 如果某首歌下载失败，会跳过并继续下一首
- 只有用户明确要求下载时，才运行本 skill
- 只处理 `searchResults[].download === true` 的候选
- 没有任何 `download: true` 时会直接退出，不下载
- 需要 Google Chrome 浏览器（macOS: `/Applications/Google Chrome.app`）
- 下载的MP3和LRC文件会自动添加序号前缀（如 `1.朵.mp3`、`1.朵.lrc`），保持歌曲顺序

## 示例

```bash
# 用户已经在 playlist_songs.json 中为要下载的候选设置 "download": true
node .opencode/skill/playlist-downloader/scripts/download_playlist.js

# 查看下载结果
ls -1 playlist/
```

## 输出文件结构

```
playlist/
├── 1.朵.mp3
├── 1.朵.lrc
├── 2.感官先生.mp3
├── 2.感官先生.lrc
├── 3.I Want It That Way.mp3
├── 3.I Want It That Way.lrc
└── ...
```
