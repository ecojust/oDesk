---
name: text-to-scene-illustration
description: 使用 rough.js 将文本内容生成为场景插图。根据 content.txt 读取文本内容，解析故事情节，生成多个场景的PNG插图。支持配置文件自定义标题、场景标签和尺寸。
metadata:
  author: opencode
  version: "1.0.0"
---

# 文本转场景插图

将文本内容生成为场景插图PNG文件。

## 使用方式

当用户需要根据文本内容生成插图时使用此 skill。

## 实现步骤

### Step 1: 读取配置和内容

1. 读取项目根目录的 `config.json` 获取配置：
   - `showtitle`: 是否显示主标题
   - `showscenelabel`: 是否显示场景标签
   - `size`: 画布长宽比（可选）

2. 读取上层目录的 `content.txt` 获取需要生成插图的文本内容

### Step 2: 安装依赖

```bash
npm install roughjs canvas
```

### Step 3: 编写生成脚本

在 skill 文件夹内创建 `generate.js`，实现以下功能：

1. **读取配置**（读取上层目录的 config.json）：

   ```javascript
   const config = JSON.parse(fs.readFileSync('../config.json', 'utf8'));
   ```

2. **计算画布尺寸**：
   - 场景高度固定为 350px
   - 场景间距 30px
   - 标题区域 70px（如果显示）
   - 底部 padding 30px
   - 动态计算总高度

3. **实现绘图函数**：
   - 使用 rough.js 的 `rough.canvas()` 创建画布
   - 使用 `rc.ellipse()`, `rc.rectangle()`, `rc.circle()`, `rc.line()`, `rc.path()` 绘制图形
   - 根据文本内容抽象出主要场景和人物
   - 根据 `config.showscenelabel` 决定是否绘制场景标签

4. **绘制流程**：
   - 填充背景色
   - 如果 `config.showtitle` 为 true，绘制主标题
   - 逐个绘制场景，设置正确的 offsetY 位置
   - 保存为 PNG 文件，文件名固定为 `illustration.png`

### Step 4: 运行生成

```bash
cd 项目根目录
node .skills/text-to-scene-illustration/generate.js
```

## 配置示例

```json
{
  "showscenelabel": false,
  "showtitle": true
}
```

## 输出

生成固定名称的 `illustration.png` 文件，包含根据文本内容绘制的场景插图。
