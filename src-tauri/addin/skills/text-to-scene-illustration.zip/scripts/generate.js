const rough = require('roughjs');
const { createCanvas } = require('canvas');
const fs = require('fs');

const path = require('path');
const configPath = process.env.PWD || process.cwd();
const config = JSON.parse(fs.readFileSync(path.join(configPath, 'config.json'), 'utf8'));

const baseWidth = 800;
const sceneHeight = 350;
const gap = 30;
const titleSpace = config.showtitle ? 70 : 20;
const labelSpace = config.showscenelabel ? 40 : 10;
const bottomPadding = 30;
const totalHeight = titleSpace + gap + sceneHeight * 3 + labelSpace * 2 + bottomPadding;

const canvas = createCanvas(baseWidth, totalHeight);
const ctx = canvas.getContext('2d');

ctx.fillStyle = '#f5f0e6';
ctx.fillRect(0, 0, baseWidth, totalHeight);

if (config.showtitle) {
    ctx.fillStyle = '#2c1810';
    ctx.font = 'bold 32px SimSun';
    ctx.textAlign = 'center';
    ctx.fillText('变色龙 - 契诃夫', 400, 45);
}

const startY = titleSpace;
const scenePositions = [0, 1, 2].map(i => startY + i * (sceneHeight + gap));

drawScene1(canvas, 150, scenePositions[0], config.showscenelabel);
drawScene2(canvas, 150, scenePositions[1], config.showscenelabel);
drawScene3(canvas, 150, scenePositions[2], config.showscenelabel);

function drawScene1(canvas, offsetX, offsetY, showLabel) {
    const rc = rough.canvas(canvas);
    const ctx = canvas.getContext('2d');

    ctx.save();
    ctx.translate(offsetX, offsetY);

    ctx.fillStyle = '#e8dcc8';
    ctx.fillRect(0, 0, 500, 350);

    rc.rectangle(0, 280, 500, 70, { fill: '#c4a882', fillStyle: 'solid' });

    rc.rectangle(50, 100, 80, 180, { fill: '#8b7355', fillStyle: 'solid', stroke: '#5c4a3a' });
    rc.rectangle(150, 80, 100, 200, { fill: '#9a8470', fillStyle: 'solid', stroke: '#5c4a3a' });
    rc.rectangle(350, 90, 90, 190, { fill: '#8b7355', fillStyle: 'solid', stroke: '#5c4a3a' });

    rc.ellipse(250, 180, 60, 70, { fill: '#2d4a3e', fillStyle: 'solid' });
    rc.rectangle(210, 200, 80, 100, { fill: '#3d5a4e', fillStyle: 'solid' });
    rc.path('M210,280 L200,320 L300,320 L290,280 Z', { fill: '#3d5a4e', fillStyle: 'solid' });
    rc.ellipse(250, 155, 50, 20, { fill: '#2d4a3e', fillStyle: 'solid' });
    rc.ellipse(250, 165, 55, 10, { fill: '#1a2f28', fillStyle: 'solid' });
    rc.circle(230, 220, 5, { fill: '#1a2f28', fillStyle: 'solid' });
    rc.circle(270, 220, 5, { fill: '#1a2f28', fillStyle: 'solid' });
    rc.circle(230, 250, 5, { fill: '#1a2f28', fillStyle: 'solid' });
    rc.circle(270, 250, 5, { fill: '#1a2f28', fillStyle: 'solid' });

    rc.ellipse(340, 200, 40, 50, { fill: '#4a6b7c', fillStyle: 'solid' });
    rc.rectangle(315, 230, 50, 70, { fill: '#5a7b8c', fillStyle: 'solid' });
    rc.ellipse(340, 175, 35, 15, { fill: '#8b4513', fillStyle: 'solid' });
    rc.ellipse(370, 280, 40, 25, { fill: '#c4a882', fillStyle: 'solid' });
    rc.path('M350,280 L350,310 Q370,330 390,310 L390,280', { fill: '#d4b892', fillStyle: 'solid' });

    if (showLabel) {
        ctx.fillStyle = '#5c4a3a';
        ctx.font = '16px SimSun';
        ctx.textAlign = 'left';
        ctx.fillText('场景一：警官奥楚美洛夫穿过市集广场', 20, 30);
    }

    ctx.restore();
}

function drawScene2(canvas, offsetX, offsetY, showLabel) {
    const rc = rough.canvas(canvas);
    const ctx = canvas.getContext('2d');

    ctx.save();
    ctx.translate(offsetX, offsetY);

    ctx.fillStyle = '#e8dcc8';
    ctx.fillRect(0, 0, 500, 350);

    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 3; j++) {
            rc.ellipse(60 + i * 30 + j * 10, 250 + j * 15 - i * 8, 35, 12, { fill: '#8b6914', fillStyle: 'solid' });
        }
    }
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 2; j++) {
            rc.ellipse(100 + i * 30 + j * 10, 220 + j * 12 - i * 6, 35, 12, { fill: '#9a7520', fillStyle: 'solid' });
        }
    }

    const colors = ['#6b5b4f', '#7d6b5d', '#5d4b3f', '#8b7b6b'];
    for (let i = 0; i < 6; i++) {
        rc.ellipse(150 + i * 40, 220, 25, 35, { fill: colors[i % 4], fillStyle: 'solid' });
        rc.ellipse(150 + i * 40, 190, 20, 20, { fill: '#d4c4a8', fillStyle: 'solid' });
    }

    rc.ellipse(320, 290, 50, 30, { fill: '#f5f5f0', fillStyle: 'solid' });
    rc.ellipse(365, 280, 25, 22, { fill: '#f5f5f0', fillStyle: 'solid' });
    rc.ellipse(375, 265, 12, 18, { fill: '#e8e8e0', fillStyle: 'solid' });
    rc.ellipse(310, 285, 20, 15, { fill: '#d4a030', fillStyle: 'solid' });
    rc.circle(372, 278, 3, { fill: '#333', fillStyle: 'solid' });
    rc.line(300, 310, 290, 340);
    rc.line(330, 312, 325, 345);
    rc.line(350, 310, 355, 340);

    rc.ellipse(260, 200, 30, 35, { fill: '#c4a882', fillStyle: 'solid' });
    rc.rectangle(235, 220, 50, 70, { fill: '#d4b892', fillStyle: 'solid' });
    rc.rectangle(235, 220, 50, 40, { fill: '#a08060', fillStyle: 'solid' });
    rc.rectangle(235, 240, 50, 30, { fill: '#8b6914', fillStyle: 'solid' });
    rc.line(260, 220, 260, 180);
    rc.line(260, 180, 250, 160);
    rc.circle(250, 165, 4, { fill: '#8b0000', fillStyle: 'solid' });
    rc.circle(245, 175, 3, { fill: '#8b0000', fillStyle: 'solid' });

    if (showLabel) {
        ctx.fillStyle = '#5c4a3a';
        ctx.font = '16px SimSun';
        ctx.textAlign = 'left';
        ctx.fillText('场景二：狗咬人事件 - 赫留金的手指', 20, 30);
    }

    ctx.restore();
}

function drawScene3(canvas, offsetX, offsetY, showLabel) {
    const rc = rough.canvas(canvas);
    const ctx = canvas.getContext('2d');

    ctx.save();
    ctx.translate(offsetX, offsetY);

    ctx.fillStyle = '#e8dcc8';
    ctx.fillRect(0, 0, 500, 350);

    rc.rectangle(0, 280, 500, 70, { fill: '#c4a882', fillStyle: 'solid' });

    rc.ellipse(200, 180, 50, 60, { fill: '#3d5a4e', fillStyle: 'solid' });
    rc.rectangle(165, 210, 70, 90, { fill: '#3d5a4e', fillStyle: 'solid' });
    rc.ellipse(200, 150, 45, 18, { fill: '#2d4a3e', fillStyle: 'solid' });
    rc.ellipse(200, 160, 50, 8, { fill: '#1a2f28', fillStyle: 'solid' });

    rc.ellipse(280, 190, 35, 45, { fill: '#4a6b7c', fillStyle: 'solid' });
    rc.rectangle(255, 215, 50, 65, { fill: '#5a7b8c', fillStyle: 'solid' });
    rc.ellipse(280, 165, 30, 12, { fill: '#8b4513', fillStyle: 'solid' });

    rc.ellipse(380, 180, 45, 55, { fill: '#f5f5dc', fillStyle: 'solid' });
    rc.rectangle(345, 215, 70, 85, { fill: '#f5f5dc', fillStyle: 'solid' });
    rc.path('M350,135 L355,100 L405,100 L410,135 Z', { fill: '#fff', fillStyle: 'solid' });
    rc.ellipse(380, 145, 30, 10, { fill: '#fff', fillStyle: 'solid' });

    rc.ellipse(420, 300, 40, 25, { fill: '#f5f5f0', fillStyle: 'solid' });
    rc.ellipse(450, 290, 20, 18, { fill: '#f5f5f0', fillStyle: 'solid' });
    rc.ellipse(458, 278, 10, 15, { fill: '#e8e8e0', fillStyle: 'solid' });
    rc.ellipse(403, 295, 15, 12, { fill: '#d4a030', fillStyle: 'solid' });

    rc.ellipse(100, 200, 30, 35, { fill: '#c4a882', fillStyle: 'solid' });
    rc.rectangle(75, 220, 50, 70, { fill: '#d4b892', fillStyle: 'solid' });
    rc.line(100, 220, 90, 250);

    if (showLabel) {
        ctx.fillStyle = '#5c4a3a';
        ctx.font = '16px SimSun';
        ctx.textAlign = 'left';
        ctx.fillText('场景三：厨师普罗霍尔带走狗，众人嘲笑赫留金', 20, 30);
    }

    ctx.restore();
}

fs.writeFileSync('illustration.png', canvas.toBuffer('image/png'));
console.log('生成了 illustration.png');