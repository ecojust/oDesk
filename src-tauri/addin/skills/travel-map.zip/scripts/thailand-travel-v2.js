const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "泰国",
  days: [
    {
      title: "Day 1",
      subtitle: "曼谷古城探秘",
      color: "pink",
      schedule: [
        { time: "07:00", location: "廊曼机场", desc: "落地后搭乘机场快线进市区", tip: "推荐购买游客专属交通卡", cost: "¥80", icon: "S" },
        { time: "09:00", location: "大皇宫", desc: "金碧辉煌的皇室宫殿建筑群", tip: "门票含玉佛寺，着装需得体", cost: "¥350", icon: "1" },
        { time: "11:30", location: "卧佛寺", desc: "泰式传统按摩发源地", tip: "可体验1小时正宗泰式按摩", cost: "¥200", icon: "2" },
        { time: "13:00", location: "午餐：水上餐厅", desc: "湄南河畔享用泰式料理", cost: "¥180", icon: "B" },
        { time: "15:00", location: "郑王庙", desc: "黎明之塔的绝美剪影", tip: "穿泰国服装拍照更出片", cost: "¥80", icon: "3" },
        { time: "17:00", location: "ICONSIAM", desc: "湄南河畔奢华购物中心", tip: "室内水上市场值得一看", cost: "¥300", icon: "4" },
        { time: "20:00", location: "火车夜市", desc: "火山排骨+生腌海鲜", cost: "¥200", icon: "5" },
        { time: "22:00", location: "住宿：沙潘塔克辛", desc: "河畔精品酒店，景观绝佳", cost: "¥400", icon: "Z" }
      ],
      totalCost: "¥1,790"
    },
    {
      title: "Day 2",
      subtitle: "泰式生活体验",
      color: "blue",
      schedule: [
        { time: "07:30", location: "黎明寺早课", desc: "参与布施僧侣仪式", tip: "体验当地佛教文化", cost: "免费", icon: "1" },
        { time: "09:00", location: "美功铁道市场", desc: "火车穿越菜市场的奇观", tip: "关注火车时刻表：6:20/8:30/10:00", cost: "¥50", icon: "2" },
        { time: "11:00", location: "安帕瓦水上市场", desc: "原生态水上集市", tip: "下午1点后更热闹", cost: "¥100", icon: "3" },
        { time: "13:00", location: "午餐：河岸船面", desc: "小碗船面配上泰式奶茶", cost: "¥80", icon: "B" },
        { time: "15:00", location: "四面佛", desc: "Central World旁的许愿圣地", tip: "请舞者跳舞还愿更灵验", cost: "¥150", icon: "4" },
        { time: "17:00", location: "暹罗商圈", desc: "MBK/Siam Center购物", cost: "¥500", icon: "5" },
        { time: "19:30", location: "彩虹云霄自助餐", desc: "82楼俯瞰曼谷夜景", tip: "提前订位，选择靠窗位", cost: "¥280", icon: "6" },
        { time: "21:30", location: "考山路夜生活", desc: "体验曼谷不夜城", cost: "¥200", icon: "7" }
      ],
      totalCost: "¥1,360"
    },
    {
      title: "Day 3",
      subtitle: "暹罗风情收官",
      color: "purple",
      schedule: [
        { time: "08:00", location: "乍都乍周末市场", desc: "亚洲最大淘宝天堂", tip: "周六日开市，记得带现金", cost: "¥400", icon: "1" },
        { time: "11:00", location: "Terminal 21", desc: "航站楼主题商场", tip: "每层代表一个国家的美食", cost: "¥200", icon: "2" },
        { time: "13:00", location: "午餐：朱拉隆功美食街", desc: "本地人最爱的美食圣地", tip: "必吃：烤猪肉面/泰式奶茶", cost: "¥120", icon: "B" },
        { time: "15:00", location: "Safari World", desc: "野生动物园+海洋世界", tip: "含长颈鹿早餐互动体验", cost: "¥380", icon: "3" },
        { time: "18:00", location: "金东尼人妖秀", desc: "精彩绝伦的人妖表演", tip: "秀后可以合影留念", cost: "¥200", icon: "4" },
        { time: "20:00", location: "唐人街美食之旅", desc: "燕窝鱼翅+金箔燕窝", tip: "砍价空间大，建议对半砍", cost: "¥250", icon: "5" },
        { time: "22:00", location: "返程", desc: "前往素万那普机场回国", cost: "¥150", icon: "E" }
      ],
      totalCost: "¥1,700"
    }
  ],
  tips: {
    transport: "曼谷BTS空铁和MRT地铁是最佳出行方式，建议购买Rabbit卡充值使用",
    transport2: "嘟嘟车价格是打车的2-3倍，短程可尝试砍价，Grab更规范",
    accommodation: "沙潘塔克辛/是隆区：河景酒店体验佳，夜生活丰富",
    accommodation2: "暹罗区：购物天堂，交通便利，适合首次游客"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1150" viewBox="0 0 1200 1150">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="70%" style="stop-color:#FFB6C1"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#98FB98"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="3" dy="3" stdDeviation="4" flood-opacity="0.25"/>
    </filter>
    <filter id="glow">
      <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
    <style>
      .title { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 38px; font-weight: bold; }
      .day-title { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 22px; font-weight: bold; fill: #fff; }
      .subtitle { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 14px; fill: #fff; opacity: 0.9; }
      .time { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 14px; fill: #DC143C; font-weight: bold; }
      .location { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 16px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 13px; fill: #555; }
      .tip { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 12px; fill: #8B4513; font-style: italic; }
      .cost { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 13px; font-weight: bold; }
      .total { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 15px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1200" height="1150" fill="url(#sky)"/>
  
  <ellipse cx="100" cy="100" rx="80" ry="40" fill="#fff" opacity="0.7"/>
  <ellipse cx="180" cy="85" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="250" cy="95" rx="60" ry="30" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="950" cy="80" rx="90" ry="45" fill="#fff" opacity="0.7"/>
  <ellipse cx="1050" cy="70" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="880" cy="95" rx="50" ry="25" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="600" cy="50" rx="120" ry="60" fill="#fff" opacity="0.5"/>
  <ellipse cx="700" cy="40" rx="80" ry="40" fill="#fff" opacity="0.5"/>
  <ellipse cx="500" cy="45" rx="70" ry="35" fill="#fff" opacity="0.5"/>
  
  <path d="M50 120 Q70 100 90 120 Q110 100 130 120" stroke="#2F4F4F" stroke-width="3" fill="none"/>
  <path d="M1070 140 Q1090 120 1110 140 Q1130 120 1150 140" stroke="#2F4F4F" stroke-width="3" fill="none"/>
  
  <text x="200" y="170" fill="#FFD700" font-size="18" filter="url(#glow)">*</text>
  <text x="1000" y="160" fill="#FFD700" font-size="18" filter="url(#glow)">*</text>
  <text x="600" y="180" fill="#FF69B4" font-size="14" opacity="0.6">泰国之旅</text>
  
  <circle cx="80" cy="200" r="12" fill="#FF69B4" opacity="0.8"/>
  <circle cx="95" cy="215" r="8" fill="#FFB6C1" opacity="0.7"/>
  <circle cx="65" cy="220" r="6" fill="#FF69B4" opacity="0.6"/>
  <circle cx="1120" cy="200" r="12" fill="#87CEFA" opacity="0.8"/>
  <circle cx="1135" cy="215" r="8" fill="#B0E0E6" opacity="0.7"/>
  
  <ellipse cx="0" cy="1150" rx="350" ry="180" fill="url(#grass)" opacity="0.85"/>
  <ellipse cx="1200" cy="1150" rx="450" ry="200" fill="url(#grass)" opacity="0.75"/>
  <ellipse cx="400" cy="1150" rx="300" ry="160" fill="url(#grass)" opacity="0.65"/>
  <ellipse cx="900" cy="1150" rx="350" ry="170" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="40" y="170" width="1120" height="870" fill="#fff" rx="25" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="220" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination} · 3天2夜深度游</text>
  <text x="600" y="260" text-anchor="middle" font-size="20" fill="#FF69B4">宫崎骏风格 · 时间轴行程规划</text>
  
  <rect x="380" y="285" width="440" height="35" rx="17" fill="#FFFAF0" stroke="#FFD700" stroke-width="2"/>
  <text x="600" y="310" text-anchor="middle" font-size="16" fill="#696969">微笑国度 - 热带风情 - 佛教文化 - 美食天堂</text>
  
  <circle cx="180" cy="360" r="20" fill="#FF69B4"/>
  <circle cx="600" cy="360" r="20" fill="#4169E1"/>
  <circle cx="1020" cy="360" r="20" fill="#9370DB"/>
  <text x="180" y="366" text-anchor="middle" font-size="12" fill="#fff" font-weight="bold">Day</text>
  <text x="600" y="366" text-anchor="middle" font-size="12" fill="#fff" font-weight="bold">Day</text>
  <text x="1020" y="366" text-anchor="middle" font-size="12" fill="#fff" font-weight="bold">Day</text>
  
  <line x1="220" y1="360" x2="560" y2="360" stroke="#FFD700" stroke-width="3" stroke-dasharray="8,4"/>
  <line x1="640" y1="360" x2="980" y2="360" stroke="#FFD700" stroke-width="3" stroke-dasharray="8,4"/>
  
  <text x="180" y="395" text-anchor="middle" font-size="16" fill="#FF69B4" font-weight="bold">1</text>
  <text x="600" y="395" text-anchor="middle" font-size="16" fill="#4169E1" font-weight="bold">2</text>
  <text x="1020" y="395" text-anchor="middle" font-size="16" fill="#9370DB" font-weight="bold">3</text>`;

  const dayPositions = [
    { x: 70, y: 420, lineX: 125 },
    { x: 430, y: 420, lineX: 485 },
    { x: 790, y: 420, lineX: 845 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="620" fill="${c.bg}" rx="18" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="70" fill="${c.main}" rx="18"/>
  <rect x="${pos.x}" y="${pos.y + 50}" width="340" height="20" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 38}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 62}" text-anchor="middle" class="subtitle">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 100}" x2="${pos.lineX}" y2="${pos.y + 580}" stroke="#fff" stroke-width="5" stroke-dasharray="12,6"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 115 + i * 60;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      const iconSize = isMeal ? 22 : 18;
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="${iconSize}" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="${isMeal ? 9 : 10}" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 40}" y="${y - 3}" class="time">${item.time}</text>
  <text x="${pos.lineX + 40}" y="${y + 14}" class="location">${item.location}</text>
  <text x="${pos.lineX + 40}" y="${y + 34}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 270}" y="${y + 14}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 40}" y="${y + 52}" class="tip">${item.tip}</text>`;
      }
    });

    svg += `
  <rect x="${pos.x + 20}" y="${pos.y + 565}" width="300" height="38" fill="${c.main}" rx="12"/>
  <text x="${pos.x + 170}" y="${pos.y + 593}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
  });

  svg += `
  <rect x="70" y="1060" width="1060" height="75" fill="#FFFAF0" rx="15" stroke="#DEB887" stroke-width="2"/>
  <text x="100" y="1088" font-family="SimHei, sans-serif" font-size="14" font-weight="bold" fill="#228B22">交通指南</text>
  <text x="100" y="1110" font-family="SimHei, sans-serif" font-size="12" fill="#555">${data.tips.transport}</text>
  <text x="700" y="1088" font-family="SimHei, sans-serif" font-size="14" font-weight="bold" fill="#FF69B4">住宿推荐</text>
  <text x="700" y="1110" font-family="SimHei, sans-serif" font-size="12" fill="#555">${data.tips.accommodation}</text>
  
  <text x="600" y="1135" text-anchor="middle" fill="#696969" font-size="13">最佳出行季节：11月-2月  |  时差：比中国晚1小时  |  汇率：1人民币约5泰铢</text>
  
  <circle cx="300" cy="100" r="5" fill="#FF69B4" opacity="0.5"/>
  <circle cx="900" cy="120" r="4" fill="#87CEFA" opacity="0.5"/>
  <circle cx="450" cy="80" r="3" fill="#9370DB" opacity="0.5"/>
  <circle cx="750" cy="90" r="4" fill="#FFD700" opacity="0.5"/>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'thailand-travel-v2.svg');
  const pngPath = path.join(process.cwd(), 'thailand-travel-v2.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('Thailand travel plan generated:'))
    .then(() => console.log('SVG: ' + svgPath))
    .then(() => console.log('PNG: ' + pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
