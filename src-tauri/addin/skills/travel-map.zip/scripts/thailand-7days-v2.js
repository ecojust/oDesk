const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "泰国",
  days: [
    {
      title: "Day 1",
      subtitle: "曼谷初见",
      color: "pink",
      schedule: [
        { time: "08:00", location: "素万那普机场", desc: "落地签+机场快线进市区", tip: "提前打印好返程机票和酒店订单", cost: "¥150", icon: "S" },
        { time: "10:00", location: "大皇宫", desc: "金碧辉煌皇室宫殿", tip: "门票含玉佛寺，着装需长裤", cost: "¥350", icon: "1" },
        { time: "13:00", location: "午餐：评论餐厅", desc: "百年老店正宗泰式料理", cost: "¥150", icon: "B" },
        { time: "15:00", location: "卧佛寺", desc: "46米金身卧佛+泰式按摩", tip: "可预约正宗泰式按摩", cost: "¥200", icon: "2" },
        { time: "17:00", location: "郑王庙", desc: "湄南河畔黎明之塔", tip: "对面码头拍照更佳", cost: "¥80", icon: "3" },
        { time: "19:30", location: "Asiatique夜市", desc: "河畔摩天轮+美食", cost: "¥250", icon: "4" },
        { time: "22:00", location: "住宿：沙潘克辛", desc: "河畔精品酒店", cost: "¥400", icon: "Z" }
      ],
      totalCost: "¥1,580"
    },
    {
      title: "Day 2",
      subtitle: "市井风情",
      color: "blue",
      schedule: [
        { time: "07:00", location: "黎明寺", desc: "清晨布施僧侣仪式", tip: "体验当地佛教文化", cost: "免费", icon: "1" },
        { time: "09:00", location: "美功铁道市场", desc: "火车穿越菜市场", tip: "火车时间6:20/8:30/10:00", cost: "¥50", icon: "2" },
        { time: "11:00", location: "安帕瓦水上市场", desc: "原生态水上集市", tip: "下午1点后更热闹", cost: "¥100", icon: "3" },
        { time: "13:30", location: "午餐：水上烤鱼", desc: "现烤湄南河鲜鱼", cost: "¥120", icon: "B" },
        { time: "16:00", location: "四面佛", desc: "Central World许愿", tip: "请舞还愿更灵验", cost: "¥150", icon: "4" },
        { time: "18:00", location: "暹罗商圈", desc: "百丽宫+暹罗中心", cost: "¥500", icon: "5" },
        { time: "21:00", location: "彩虹云霄自助餐", desc: "82楼夜景+海鲜", cost: "¥280", icon: "6" }
      ],
      totalCost: "¥1,200"
    },
    {
      title: "Day 3",
      subtitle: "购物休闲",
      color: "green",
      schedule: [
        { time: "09:00", location: "乍都乍周末市场", desc: "亚洲最大淘宝天堂", tip: "周六日开市，记得带现金", cost: "¥400", icon: "1" },
        { time: "12:00", location: "Terminal 21", desc: "航站楼主题商场", tip: "每层代表一个国家", cost: "¥200", icon: "2" },
        { time: "14:00", location: "午餐：朱拉隆功", desc: "烤猪肉面+泰式奶茶", cost: "¥80", icon: "B" },
        { time: "16:00", location: "Safari World", desc: "野生动物园+海洋馆", tip: "含长颈鹿互动体验", cost: "¥380", icon: "3" },
        { time: "19:30", location: "金东尼人妖秀", desc: "精彩绝伦人妖歌舞", tip: "秀后可与演员合影", cost: "¥200", icon: "4" },
        { time: "21:30", location: "建兴酒家", desc: "招牌咖喱蟹晚餐", cost: "¥220", icon: "5" }
      ],
      totalCost: "¥1,480"
    },
    {
      title: "Day 4",
      subtitle: "清迈古城",
      color: "orange",
      schedule: [
        { time: "06:00", location: "曼谷飞清迈", desc: "1小时航班前往清迈", tip: "早班机可看日出", cost: "¥350", icon: "T" },
        { time: "09:00", location: "清迈古城", desc: "漫步兰纳王朝古城", tip: "租摩托车游览更方便", cost: "¥50", icon: "1" },
        { time: "11:00", location: "契迪龙寺", desc: "古朴庄重的佛塔", tip: "古城最高点，可俯瞰全景", cost: "¥40", icon: "2" },
        { time: "13:00", location: "午餐：凤飞飞猪脚饭", desc: "清迈知名街头美食", cost: "¥30", icon: "B" },
        { time: "15:00", location: "清曼寺", desc: "最古老的寺庙", cost: "免费", icon: "3" },
        { time: "17:00", location: "素贴山双龙寺", desc: "金塔+俯瞰清迈全景", tip: "可乘缆车上山", cost: "¥60", icon: "4" },
        { time: "19:30", location: "清迈夜市", desc: "周日夜市淘宝美食", cost: "¥200", icon: "5" },
        { time: "22:00", location: "住宿：清迈古城", desc: "精品民宿体验", cost: "¥280", icon: "Z" }
      ],
      totalCost: "¥1,010"
    },
    {
      title: "Day 5",
      subtitle: "清迈自然",
      color: "teal",
      schedule: [
        { time: "07:30", location: "美旺大象营", desc: "给大象喂食洗澡", tip: "选择无骑象项目的大象营", cost: "¥380", icon: "1" },
        { time: "12:00", location: "午餐：丛林餐厅", desc: "森林中的泰北料理", cost: "¥100", icon: "B" },
        { time: "14:00", location: "蒲屏皇宫花园", desc: "皇室避暑御花园", tip: "一年四季花开不败", cost: "¥60", icon: "2" },
        { time: "16:00", location: "清迈大学", desc: "校园湖泊+静心湖", tip: "后门有夜市美食", cost: "免费", icon: "3" },
        { time: "18:00", location: "宁曼路", desc: "文艺小资街区", tip: "咖啡店和甜品店林立", cost: "¥150", icon: "4" },
        { time: "20:00", location: "夜间动物园", desc: "近距离接触夜行动物", cost: "¥180", icon: "5" }
      ],
      totalCost: "¥870"
    },
    {
      title: "Day 6",
      subtitle: "泰北体验",
      color: "purple",
      schedule: [
        { time: "08:30", location: "厨艺学校", desc: "学习泰式料理制作", tip: "含市场采购+4道菜学习", cost: "¥350", icon: "1" },
        { time: "13:00", location: "午餐：自己做的菜", desc: "品尝学习成果", cost: "免费", icon: "B" },
        { time: "15:00", location: "回曼谷", desc: "航班返回曼谷", cost: "¥350", icon: "T" },
        { time: "18:00", location: "唐人街", desc: "燕窝鱼翅美食之旅", tip: "记得砍价50%", cost: "¥250", icon: "2" },
        { time: "21:00", location: "考山路夜生活", desc: "体验曼谷不夜城", cost: "¥200", icon: "3" },
        { time: "23:00", location: "住宿：暹罗区", desc: "方便明日购物", cost: "¥350", icon: "Z" }
      ],
      totalCost: "¥1,500"
    },
    {
      title: "Day 7",
      subtitle: "完美收官",
      color: "pink",
      schedule: [
        { time: "09:00", location: "Icon Siam", desc: "湄南河畔奢华购物中心", tip: "室内水上市场和美食广场", cost: "¥300", icon: "1" },
        { time: "12:00", location: "午餐：MK火锅", desc: "泰式皇室小火锅", cost: "¥120", icon: "B" },
        { time: "14:00", location: "Big C超市", desc: "采购泰国土特产", tip: "芒果干/榴莲干/青草膏", cost: "¥300", icon: "2" },
        { time: "16:00", location: "王权免税店", desc: "欧莱雅等品牌优惠", tip: "提前领优惠券更划算", cost: "¥200", icon: "3" },
        { time: "19:00", location: "最后一餐", desc: "建兴酒家咖喱蟹", cost: "¥200", icon: "B" },
        { time: "21:30", location: "返程", desc: "素万那普机场回国", cost: "¥100", icon: "E" }
      ],
      totalCost: "¥1,220"
    }
  ],
  tips: {
    transport: "曼谷BTS+MRT最便捷，清迈建议租摩托车（150泰铢/天）",
    transport2: "曼谷-清迈可乘飞机1小时或过夜火车，体验不同",
    accommodation: "曼谷：暹罗区购物便利/沙潘克辛河景浪漫",
    accommodation2: "清迈：古城内民宿体验兰纳风情，早餐丰盛"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    green: { bg: "#98FB98", main: "#32CD32", text: "#228B22" },
    orange: { bg: "#FFDAB9", main: "#FF8C00", text: "#FF6347" },
    teal: { bg: "#40E0D0", main: "#008B8B", text: "#008B8B" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="1450" viewBox="0 0 1400 1450">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.25"/>
    </filter>
    <style>
      .title { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 16px; font-weight: bold; fill: #fff; }
      .subtitle { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 11px; fill: #fff; opacity: 0.9; }
      .time { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 11px; fill: #DC143C; font-weight: bold; }
      .location { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 12px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 10px; fill: #555; }
      .tip { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 9px; fill: #8B4513; font-style: italic; }
      .cost { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 11px; font-weight: bold; }
      .total { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 12px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1400" height="1450" fill="url(#sky)"/>
  
  <ellipse cx="150" cy="90" rx="80" ry="40" fill="#fff" opacity="0.75"/>
  <ellipse cx="240" cy="75" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="100" cy="100" rx="50" ry="25" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="1200" cy="85" rx="90" ry="45" fill="#fff" opacity="0.75"/>
  <ellipse cx="1280" cy="70" rx="65" ry="32" fill="#fff" opacity="0.7"/>
  <ellipse cx="1100" cy="95" rx="55" ry="28" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="700" cy="50" rx="100" ry="50" fill="#fff" opacity="0.55"/>
  <ellipse cx="800" cy="40" rx="70" ry="35" fill="#fff" opacity="0.5"/>
  
  <ellipse cx="0" cy="1450" rx="400" ry="200" fill="url(#grass)" opacity="0.85"/>
  <ellipse cx="1400" cy="1450" rx="450" ry="210" fill="url(#grass)" opacity="0.75"/>
  <ellipse cx="500" cy="1450" rx="350" ry="180" fill="url(#grass)" opacity="0.65"/>
  <ellipse cx="1000" cy="1450" rx="380" ry="185" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="50" y="170" width="1300" height="1200" fill="#fff" rx="22" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="700" y="220" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination} · 7天6夜深度游</text>
  <text x="700" y="260" text-anchor="middle" font-size="22" fill="#FF69B4">宫崎骏风格 · 时间轴行程规划</text>
  
  <rect x="400" y="280" width="600" height="40" rx="20" fill="#FFF8DC" stroke="#FFD700" stroke-width="2"/>
  <text x="700" y="308" text-anchor="middle" font-size="15" fill="#696969">微笑国度 - 曼谷+清迈双城记 - 热带风情之旅</text>`;

  const dayPositions = [
    { x: 70, y: 350, lineX: 125 },
    { x: 460, y: 350, lineX: 515 },
    { x: 850, y: 350, lineX: 905 },
    { x: 70, y: 810, lineX: 125 },
    { x: 460, y: 810, lineX: 515 },
    { x: 850, y: 810, lineX: 905 },
    { x: 70, y: 1270, lineX: 125 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="${dayIndex === 6 ? 160 : 430}" fill="${c.bg}" rx="14" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="50" fill="${c.main}" rx="14"/>
  <rect x="${pos.x}" y="${pos.y + 32}" width="340" height="18" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 28}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 46}" text-anchor="middle" class="subtitle">${day.subtitle}</text>`;

    if (dayIndex !== 6) {
      svg += `
  <line x1="${pos.lineX}" y1="${pos.y + 75}" x2="${pos.lineX}" y2="${pos.y + 400}" stroke="#fff" stroke-width="4" stroke-dasharray="8,4"/>`;
    }

    const maxItems = dayIndex === 6 ? 6 : day.schedule.length;
    for (let i = 0; i < maxItems; i++) {
      const item = day.schedule[i];
      const y = pos.y + 85 + i * 52;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="14" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 4}" text-anchor="middle" font-size="8" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 30}" y="${y - 3}" class="time">${item.time}</text>
  <text x="${pos.lineX + 30}" y="${y + 9}" class="location">${item.location}</text>
  <text x="${pos.lineX + 30}" y="${y + 23}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 260}" y="${y + 9}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 30}" y="${y + 38}" class="tip">${item.tip}</text>`;
      }
    }

    if (dayIndex !== 6) {
      svg += `
  <rect x="${pos.x + 20}" y="${pos.y + 385}" width="300" height="30" fill="${c.main}" rx="8"/>
  <text x="${pos.x + 170}" y="${pos.y + 407}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
    } else {
      svg += `
  <rect x="${pos.x + 20}" y="${pos.y + 115}" width="300" height="30" fill="${c.main}" rx="8"/>
  <text x="${pos.x + 170}" y="${pos.y + 137}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
    }
  });

  svg += `
  <rect x="70" y="1360" width="1260" height="70" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="100" y="1388" font-family="SimHei, sans-serif" font-size="13" font-weight="bold" fill="#228B22">交通指南</text>
  <text x="100" y="1410" font-family="SimHei, sans-serif" font-size="11" fill="#555">${data.tips.transport}</text>
  <text x="800" y="1388" font-family="SimHei, sans-serif" font-size="13" font-weight="bold" fill="#FF69B4">住宿推荐</text>
  <text x="800" y="1410" font-family="SimHei, sans-serif" font-size="11" fill="#555">${data.tips.accommodation}</text>
  
  <text x="700" y="1440" text-anchor="middle" fill="#696969" font-size="12">最佳出行季节：11月-2月 | 时差：比中国晚1小时 | 汇率：1人民币约5泰铢</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'thailand-7days.svg');
  const pngPath = path.join(process.cwd(), 'thailand-7days.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('Thailand 7-day travel plan generated: ' + pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
