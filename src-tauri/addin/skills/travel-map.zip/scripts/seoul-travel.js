const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "首尔",
  days: [
    {
      title: "Day 1",
      subtitle: "历史宫殿与韩屋风情",
      color: "pink",
      schedule: [
        { time: "09:00", location: "仁川机场T1抵达", desc: "机场快线直达首尔站", icon: "S" },
        { time: "10:00", location: "景福宫", desc: "朝鲜王朝正宫，韩服体验", tip: "韩服租赁约150元/2小时", icon: "1" },
        { time: "12:30", location: "午餐：土俗村参鸡汤", desc: "传统韩定食必吃", icon: "B" },
        { time: "14:00", location: "北村韩屋村", desc: "传统韩屋八景，文青漫步", tip: "安国站1号出口步行10分钟", icon: "2" },
        { time: "16:00", location: "三清洞", desc: "艺术画廊+特色咖啡厅", icon: "3" },
        { time: "18:00", location: "仁寺洞", desc: "传统文化街，纪念品购物", icon: "4" },
        { time: "20:00", location: "首尔塔夜景", desc: "南山之巅，俯瞰城市灯火", tip: "推荐18:30前乘缆车上山", icon: "5" }
      ]
    },
    {
      title: "Day 2",
      subtitle: "购物天堂与美食之旅",
      color: "blue",
      schedule: [
        { time: "09:00", location: "明洞商圈", desc: "美妆购物+换钱所", tip: "Olive Young必逛，汇率好", icon: "1" },
        { time: "12:00", location: "午餐：明洞饺子", desc: "韩国连锁饺子店", icon: "B" },
        { time: "13:30", location: "南大门市场", desc: "传统市场，鱼糕包子", icon: "2" },
        { time: "15:30", location: "东大门设计广场", desc: "DDP地标建筑，潮流打卡", tip: "晚上21:00后批發更便宜", icon: "3" },
        { time: "19:00", location: "广藏市场", desc: "韩式小吃夜市，绿豆煎饼", icon: "4" },
        { time: "21:00", location: "东大门斗塔", desc: "现代百货，时尚购物", icon: "5" }
      ]
    },
    {
      title: "Day 3",
      subtitle: "文青艺术探索之旅",
      color: "purple",
      schedule: [
        { time: "09:30", location: "弘大商圈", desc: "年轻潮流文化街头艺术", tip: "周末街头表演丰富", icon: "1" },
        { time: "11:30", location: "延南洞", desc: "文青咖啡一条街", icon: "2" },
        { time: "13:00", location: "午餐：弘大烤肉", desc: "学生价烤肉吃到饱", icon: "B" },
        { time: "14:30", location: "圣水洞", desc: "韩国布鲁克林，潮牌旗舰", tip: "Dior圣水旗舰店必打卡", icon: "3" },
        { time: "16:30", location: "益善洞韩屋村", desc: "韩屋咖啡厅，日落绝美", icon: "4" },
        { time: "19:00", location: "清溪川", desc: "城市溪流夜景散步", icon: "5" }
      ]
    },
    {
      title: "Day 4",
      subtitle: "现代都市与休闲体验",
      color: "green",
      schedule: [
        { time: "09:00", location: "COEX星空图书馆", desc: "巨型书柜网红打卡地", tip: "早9点开门人少", icon: "1" },
        { time: "11:00", location: "江南新沙洞林荫道", desc: "国际名品街，品味生活", icon: "2" },
        { time: "13:00", location: "午餐：江南韩牛", desc: "高级韩牛烤肉体验", icon: "B" },
        { time: "15:00", location: "汝矣岛汉江公园", desc: "首尔地标，春日樱花", tip: "租借单车环岛骑行", icon: "3" },
        { time: "17:00", location: "乐天世界塔SEOUL SKY", desc: "世界第5高，透明观景台", icon: "4" },
        { time: "20:00", location: "返程", desc: "仁川机场出发", icon: "E" }
      ]
    }
  ],
  tips: {
    transport: "T-money交通卡必备，地铁覆盖全面，机场快线AREX约60元/1小时",
    transport2: "打车建议用Kakao T，明洞/弘大步行更方便",
    accommodation: "推荐住明洞或弘大，交通便利，购物美食丰富",
    accommodation2: "明洞对中国游客友好，换钱方便；弘大年轻活力，夜生活丰富"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" },
    green: { bg: "#98FB98", main: "#228B22", text: "#228B22" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1100" viewBox="0 0 1200 1100">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 14px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 16px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 13px; fill: #696969; }
      .tip { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 12px; fill: #8B4513; font-style: italic; }
    </style>
  </defs>
  
  <rect width="1200" height="1100" fill="url(#sky)"/>
  <ellipse cx="150" cy="80" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="200" cy="70" rx="50" ry="25" fill="#fff" opacity="0.8"/>
  <ellipse cx="1000" cy="120" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="1060" cy="110" rx="50" ry="25" fill="#fff" opacity="0.7"/>
  <ellipse cx="600" cy="50" rx="80" ry="40" fill="#fff" opacity="0.6"/>
  <ellipse cx="0" cy="1100" rx="300" ry="150" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1200" cy="1100" rx="400" ry="180" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="30" y="150" width="1140" height="900" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="90" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination} 4天3夜 · 宫崎骏风格时间规划</text>
  <text x="600" y="125" text-anchor="middle" font-size="18" fill="#696969">韩服穿越 · 潮流购物 · 文青漫步 · 美食之旅</text>
  
  <circle cx="80" cy="160" r="8" fill="#FF69B4"/>
  <circle cx="90" cy="170" r="6" fill="#FFB6C1"/>
  <circle cx="70" cy="175" r="5" fill="#FF69B4"/>
  <circle cx="1120" cy="160" r="8" fill="#87CEFA"/>
  <circle cx="1130" cy="170" r="6" fill="#B0E0E6"/>`;

  const dayPositions = [
    { x: 50, y: 190, lineX: 100 },
    { x: 340, y: 190, lineX: 390 },
    { x: 630, y: 190, lineX: 680 },
    { x: 920, y: 190, lineX: 970 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="270" height="760" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="270" height="60" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="270" height="20" fill="${c.main}"/>
  <text x="${pos.x + 135}" y="${pos.y + 35}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 135}" y="${pos.y + 58}" text-anchor="middle" font-size="13" fill="#fff">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 95}" x2="${pos.lineX}" y2="${pos.y + 930}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 110 + i * 90;
      const isMeal = item.icon === "B";
      const isEnd = item.icon === "E";
      const bgColor = isMeal ? "#FFD700" : isEnd ? "#FF6B6B" : "#fff";
      const iconColor = isEnd ? "#fff" : c.text;
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="22" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="10" fill="${iconColor}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 35}" y="${y - 5}" class="time">${item.time}</text>
  <text x="${pos.lineX + 35}" y="${y + 15}" class="location">${item.location}</text>
  <text x="${pos.lineX + 35}" y="${y + 35}" class="desc">${item.desc}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 35}" y="${y + 55}" class="tip">${item.tip}</text>`;
      }
    });
  });

  svg += `
  <rect x="50" y="980" width="1100" height="100" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="80" y="1010" class="location" fill="#228B22">交通小贴士</text>
  <text x="80" y="1030" class="desc">${data.tips.transport}</text>
  <text x="80" y="1050" class="tip">${data.tips.transport2}</text>
  <text x="650" y="1010" class="location" fill="#FF69B4">住宿推荐</text>
  <text x="650" y="1030" class="desc">${data.tips.accommodation}</text>
  <text x="650" y="1050" class="tip">${data.tips.accommodation2}</text>
  <text x="600" y="1090" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：3-5月樱花季 / 9-11月枫叶季</text>
  <path d="M400 40 Q410 30 420 40 Q430 30 440 40" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M800 70 Q810 60 820 70 Q830 60 840 70" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <text x="120" y="130" fill="#FFD700" font-size="14">✦</text>
  <text x="1080" y="130" fill="#FFD700" font-size="14">✦</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'seoul-travel.svg');
  const pngPath = path.join(process.cwd(), 'seoul-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('首尔4天3夜行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
