const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "泰国",
  days: [
    {
      title: "Day 1",
      subtitle: "皇室与佛教文化",
      color: "pink",
      schedule: [
        { time: "08:30", location: "廊曼机场", desc: "落地签+机场快线进城", tip: "提前准备好返程机票和酒店订单", cost: "¥100", icon: "S" },
        { time: "10:00", location: "大皇宫", desc: "金碧辉煌皇室宫殿建筑群", tip: "门票包含玉佛寺，着装需长裤", cost: "¥350", icon: "1" },
        { time: "12:30", location: "午餐：评论餐厅", desc: "百年老店正宗泰式料理", cost: "¥150", icon: "B" },
        { time: "14:30", location: "卧佛寺", desc: "46米金身卧佛+泰式按摩", tip: "按摩学校体验正宗泰式按摩", cost: "¥200", icon: "2" },
        { time: "16:30", location: "考山路", desc: "背包客天堂美食街", cost: "¥180", icon: "3" },
        { time: "19:00", location: "河畔夜市", desc: "Asiatique摩天轮夜景", tip: "可乘坐摩天轮看日落", cost: "¥220", icon: "4" },
        { time: "21:30", location: "住宿：考山路", desc: "便利热闹的经济型酒店", cost: "¥280", icon: "Z" }
      ],
      totalCost: "¥1,480"
    },
    {
      title: "Day 2",
      subtitle: "市井与购物",
      color: "blue",
      schedule: [
        { time: "07:00", location: "黎明寺", desc: "清晨布施僧侣仪式", tip: "体验当地佛教文化", cost: "免费", icon: "1" },
        { time: "09:00", location: "美功铁道市场", desc: "火车穿越菜市场奇景", tip: "火车经过时间：6:20/8:30/10:00", cost: "¥50", icon: "2" },
        { time: "11:00", location: "安帕瓦水上市场", desc: "原生态水上集市体验", tip: "下午1点后更热闹", cost: "¥80", icon: "3" },
        { time: "13:00", location: "午餐：水上烤鱼", desc: "现烤湄南河鲜鱼", cost: "¥100", icon: "B" },
        { time: "15:30", location: "四面佛", desc: "Central World许愿", tip: "请舞者跳舞还愿更灵验", cost: "¥120", icon: "4" },
        { time: "17:30", location: "暹罗广场", desc: "Siam Center+MBK购物", cost: "¥450", icon: "5" },
        { time: "20:00", location: "建兴酒家", desc: "招牌咖喱蟹+芒果糯米饭", cost: "¥200", icon: "6" }
      ],
      totalCost: "¥1,000"
    },
    {
      title: "Day 3",
      subtitle: "自然与表演",
      color: "purple",
      schedule: [
        { time: "08:30", location: "乍都乍市场", desc: "亚洲最大淘宝天堂", tip: "周六日开市，记得带现金", cost: "¥350", icon: "1" },
        { time: "11:30", location: "Terminal 21", desc: "航站楼主题商场", tip: "每层代表一个国家美食", cost: "¥150", icon: "2" },
        { time: "13:30", location: "午餐：朱拉美食", desc: "烤猪肉面+泰式奶茶", cost: "¥80", icon: "B" },
        { time: "15:30", location: "Safari World", desc: "野生动物园+海洋馆", tip: "含长颈鹿早餐体验", cost: "¥380", icon: "3" },
        { time: "19:00", location: "金东尼人妖秀", desc: "精彩绝伦人妖歌舞秀", tip: "秀后可与演员合影", cost: "¥200", icon: "4" },
        { time: "21:00", location: "唐人街", desc: "燕窝鱼翅美食之旅", tip: "记得砍价50%", cost: "¥200", icon: "5" },
        { time: "23:00", location: "返程", desc: "素万那普机场回国", cost: "¥100", icon: "E" }
      ],
      totalCost: "¥1,460"
    }
  ],
  tips: {
    transport: "BTS空铁+MRT地铁覆盖主要景点，建议购买Rabbit交通卡",
    transport2: "嘟嘟车价格是打车的2-3倍，Grab打车更规范",
    accommodation: "考山路：背包客首选，夜生活丰富，性价比高",
    accommodation2: "暹罗区：购物便利，交通四通八达，适合家庭游客"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1120" viewBox="0 0 1200 1120">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="45%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <filter id="glow">
      <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
    <style>
      .title { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 38px; font-weight: bold; }
      .day-title { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .subtitle { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 12px; fill: #fff; opacity: 0.9; }
      .time { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 13px; fill: #DC143C; font-weight: bold; }
      .location { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 14px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 11px; fill: #555; }
      .tip { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 10px; fill: #8B4513; font-style: italic; }
      .cost { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 12px; font-weight: bold; }
      .total { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 14px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1200" height="1120" fill="url(#sky)"/>
  
  <ellipse cx="120" cy="90" rx="80" ry="40" fill="#fff" opacity="0.75"/>
  <ellipse cx="200" cy="75" rx="65" ry="32" fill="#fff" opacity="0.7"/>
  <ellipse cx="80" cy="100" rx="50" ry="25" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="1000" cy="85" rx="85" ry="42" fill="#fff" opacity="0.75"/>
  <ellipse cx="1080" cy="70" rx="65" ry="32" fill="#fff" opacity="0.7"/>
  <ellipse cx="920" cy="95" rx="55" ry="28" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="580" cy="55" rx="110" ry="55" fill="#fff" opacity="0.55"/>
  <ellipse cx="680" cy="45" rx="80" ry="40" fill="#fff" opacity="0.5"/>
  <ellipse cx="480" cy="50" rx="65" ry="33" fill="#fff" opacity="0.5"/>
  
  <ellipse cx="0" cy="1120" rx="380" ry="190" fill="url(#grass)" opacity="0.85"/>
  <ellipse cx="1200" cy="1120" rx="420" ry="200" fill="url(#grass)" opacity="0.75"/>
  <ellipse cx="450" cy="1120" rx="320" ry="170" fill="url(#grass)" opacity="0.65"/>
  <ellipse cx="850" cy="1120" rx="350" ry="175" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="50" y="175" width="1100" height="860" fill="#fff" rx="22" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="220" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination} · 3天2夜深度游</text>
  <text x="600" y="260" text-anchor="middle" font-size="22" fill="#FF69B4">宫崎骏风格 · 时间轴行程规划</text>
  
  <rect x="350" y="280" width="500" height="38" rx="19" fill="#FFF8DC" stroke="#FFD700" stroke-width="2"/>
  <text x="600" y="307" text-anchor="middle" font-size="15" fill="#696969">微笑国度 - 热带风情 - 佛教文化 - 美食天堂</text>
  
  <circle cx="170" cy="360" r="25" fill="#FF69B4" filter="url(#shadow)"/>
  <circle cx="600" cy="360" r="25" fill="#4169E1" filter="url(#shadow)"/>
  <circle cx="1030" cy="360" r="25" fill="#9370DB" filter="url(#shadow)"/>
  <text x="170" y="365" text-anchor="middle" font-size="12" fill="#fff" font-weight="bold">Day 1</text>
  <text x="600" y="365" text-anchor="middle" font-size="12" fill="#fff" font-weight="bold">Day 2</text>
  <text x="1030" y="365" text-anchor="middle" font-size="12" fill="#fff" font-weight="bold">Day 3</text>
  
  <line x1="215" y1="360" x2="555" y2="360" stroke="#FFD700" stroke-width="3" stroke-dasharray="8,5"/>
  <line x1="645" y1="360" x2="985" y2="360" stroke="#FFD700" stroke-width="3" stroke-dasharray="8,5"/>`;

  const dayPositions = [
    { x: 75, y: 410, lineX: 130 },
    { x: 430, y: 410, lineX: 485 },
    { x: 785, y: 410, lineX: 840 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="620" fill="${c.bg}" rx="16" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="62" fill="${c.main}" rx="16"/>
  <rect x="${pos.x}" y="${pos.y + 42}" width="340" height="20" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 35}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 56}" text-anchor="middle" class="subtitle">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 92}" x2="${pos.lineX}" y2="${pos.y + 580}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 108 + i * 68;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="17" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="9" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 35}" y="${y - 4}" class="time">${item.time}</text>
  <text x="${pos.lineX + 35}" y="${y + 11}" class="location">${item.location}</text>
  <text x="${pos.lineX + 35}" y="${y + 28}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 270}" y="${y + 11}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 35}" y="${y + 45}" class="tip">${item.tip}</text>`;
      }
    });

    svg += `
  <rect x="${pos.x + 20}" y="${pos.y + 565}" width="300" height="36" fill="${c.main}" rx="10"/>
  <text x="${pos.x + 170}" y="${pos.y + 590}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
  });

  svg += `
  <rect x="75" y="1045" width="1050" height="60" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="105" y="1068" font-family="SimHei, sans-serif" font-size="13" font-weight="bold" fill="#228B22">交通指南</text>
  <text x="105" y="1088" font-family="SimHei, sans-serif" font-size="11" fill="#555">${data.tips.transport}</text>
  <text x="680" y="1068" font-family="SimHei, sans-serif" font-size="13" font-weight="bold" fill="#FF69B4">住宿推荐</text>
  <text x="680" y="1088" font-family="SimHei, sans-serif" font-size="11" fill="#555">${data.tips.accommodation}</text>
  
  <text x="600" y="1115" text-anchor="middle" fill="#696969" font-size="12">最佳出行季节：11月-2月 | 时差：比中国晚1小时 | 汇率：1人民币约5泰铢</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'thailand-3days-v4.svg');
  const pngPath = path.join(process.cwd(), 'thailand-3days-v4.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('Thailand travel plan generated: ' + pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
