const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "泰国",
  days: [
    {
      title: "Day 1",
      subtitle: "曼谷经典",
      color: "pink",
      schedule: [
        { time: "08:00", location: "素万那普机场", desc: "落地签快速通道+机场快线", tip: "提前打印好酒店和机票订单", cost: "¥150", icon: "S" },
        { time: "09:30", location: "大皇宫", desc: "金碧辉煌皇室宫殿", tip: "门票含玉佛寺，请着长裤", cost: "¥350", icon: "1" },
        { time: "12:00", location: "午餐：MK火锅", desc: "泰式皇室自助小火锅", cost: "¥120", icon: "B" },
        { time: "14:00", location: "卧佛寺", desc: "46米金身卧佛+按摩学校", tip: "可预约正宗泰式按摩", cost: "¥150", icon: "2" },
        { time: "16:00", location: "郑王庙", desc: "湄南河畔黎明之塔", tip: "对面码头拍照最佳", cost: "¥80", icon: "3" },
        { time: "18:30", location: "Asiatique码头夜市", desc: "河畔摩天轮+旋转木马", tip: "摩天轮可看日落", cost: "¥200", icon: "4" },
        { time: "21:00", location: "住宿：沙潘克辛", desc: "河畔精品酒店", cost: "¥380", icon: "Z" }
      ],
      totalCost: "¥1,430"
    },
    {
      title: "Day 2",
      subtitle: "文化探索",
      color: "blue",
      schedule: [
        { time: "06:30", location: "黎明寺", desc: "参与布施僧侣仪式", tip: "体验当地佛教文化", cost: "免费", icon: "1" },
        { time: "08:30", location: "美功铁道市场", desc: "火车穿越菜市场奇观", tip: "火车时间6:20/8:30/10:00", cost: "¥50", icon: "2" },
        { time: "10:30", location: "安帕瓦水上市场", desc: "原生态水上集市", tip: "下午1点后更热闹", cost: "¥100", icon: "3" },
        { time: "13:00", location: "午餐：船面小摊", desc: "正宗泰式船面+椰子冰", cost: "¥60", icon: "B" },
        { time: "15:00", location: "四面佛", desc: "Central World许愿", tip: "请舞还愿更灵验", cost: "¥100", icon: "4" },
        { time: "17:00", location: "暹罗百丽宫", desc: "东南亚最大购物中心", tip: "美食广场美食多样", cost: "¥400", icon: "5" },
        { time: "20:00", location: "彩虹云霄82楼", desc: "海鲜自助+夜景", tip: "提前订靠窗位", cost: "¥280", icon: "6" }
      ],
      totalCost: "¥990"
    },
    {
      title: "Day 3",
      subtitle: "风情收官",
      color: "purple",
      schedule: [
        { time: "08:00", location: "乍都乍周末市场", desc: "亚洲最大淘宝天堂", tip: "周六日开市，记得带现金", cost: "¥300", icon: "1" },
        { time: "11:00", location: "Terminal 21", desc: "航站楼主题商场", tip: "每层代表一个国家", cost: "¥150", icon: "2" },
        { time: "13:00", location: "午餐：建兴酒家", desc: "咖喱蟹+芒果糯米饭", cost: "¥180", icon: "B" },
        { time: "15:00", location: "Safari World", desc: "野生动物园+海洋馆", tip: "含长颈鹿早餐", cost: "¥380", icon: "3" },
        { time: "18:30", location: "金东尼人妖秀", desc: "精彩歌舞表演", tip: "秀后可合影", cost: "¥200", icon: "4" },
        { time: "20:30", location: "唐人街", desc: "燕窝鱼翅美食之旅", tip: "记得砍价50%", cost: "¥250", icon: "5" },
        { time: "22:30", location: "返程", desc: "前往机场回国", cost: "¥120", icon: "E" }
      ],
      totalCost: "¥1,580"
    }
  ],
  tips: {
    transport: "BTS空铁+MRT地铁最便捷，建议购买一日通票（50元）",
    transport2: "嘟嘟车价格高2-3倍，Grab打车更规范",
    accommodation: "沙潘克辛/是隆区：河景酒店体验佳，夜生活丰富",
    accommodation2: "暹罗区：购物天堂，交通便利，适合首次游客"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1100" viewBox="0 0 1200 1100">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .subtitle { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 13px; fill: #fff; opacity: 0.9; }
      .time { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 14px; fill: #DC143C; font-weight: bold; }
      .location { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 15px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 12px; fill: #555; }
      .tip { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 11px; fill: #8B4513; font-style: italic; }
      .cost { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 12px; font-weight: bold; }
      .total { font-family: SimHei, Microsoft YaHei, sans-serif; font-size: 14px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1200" height="1100" fill="url(#sky)"/>
  
  <ellipse cx="150" cy="80" rx="70" ry="35" fill="#fff" opacity="0.8"/>
  <ellipse cx="220" cy="70" rx="55" ry="28" fill="#fff" opacity="0.7"/>
  <ellipse cx="100" cy="90" rx="45" ry="22" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="980" cy="100" rx="80" ry="40" fill="#fff" opacity="0.8"/>
  <ellipse cx="1050" cy="85" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="900" cy="95" rx="50" ry="25" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="550" cy="55" rx="100" ry="50" fill="#fff" opacity="0.6"/>
  <ellipse cx="650" cy="45" rx="70" ry="35" fill="#fff" opacity="0.5"/>
  
  <ellipse cx="0" cy="1100" rx="350" ry="180" fill="url(#grass)" opacity="0.85"/>
  <ellipse cx="1200" cy="1100" rx="400" ry="190" fill="url(#grass)" opacity="0.75"/>
  <ellipse cx="500" cy="1100" rx="300" ry="160" fill="url(#grass)" opacity="0.65"/>
  
  <rect x="40" y="160" width="1120" height="850" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="205" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination} - 3天2夜深度游</text>
  <text x="600" y="245" text-anchor="middle" font-size="20" fill="#FF69B4">宫崎骏风格 - 时间轴行程</text>
  
  <circle cx="180" cy="310" r="22" fill="#FF69B4"/>
  <circle cx="600" cy="310" r="22" fill="#4169E1"/>
  <circle cx="1020" cy="310" r="22" fill="#9370DB"/>
  <text x="180" y="315" text-anchor="middle" font-size="11" fill="#fff" font-weight="bold">Day 1</text>
  <text x="600" y="315" text-anchor="middle" font-size="11" fill="#fff" font-weight="bold">Day 2</text>
  <text x="1020" y="315" text-anchor="middle" font-size="11" fill="#fff" font-weight="bold">Day 3</text>
  
  <line x1="220" y1="310" x2="560" y2="310" stroke="#FFD700" stroke-width="3" stroke-dasharray="8,4"/>
  <line x1="640" y1="310" x2="980" y2="310" stroke="#FFD700" stroke-width="3" stroke-dasharray="8,4"/>`;

  const dayPositions = [
    { x: 70, y: 360, lineX: 125 },
    { x: 430, y: 360, lineX: 485 },
    { x: 790, y: 360, lineX: 845 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="640" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="60" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="340" height="20" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 32}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 55}" text-anchor="middle" class="subtitle">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 90}" x2="${pos.lineX}" y2="${pos.y + 600}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 105 + i * 72;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="18" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="9" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 35}" y="${y - 5}" class="time">${item.time}</text>
  <text x="${pos.lineX + 35}" y="${y + 12}" class="location">${item.location}</text>
  <text x="${pos.lineX + 35}" y="${y + 30}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 270}" y="${y + 12}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 35}" y="${y + 48}" class="tip">${item.tip}</text>`;
      }
    });

    svg += `
  <rect x="${pos.x + 20}" y="${pos.y + 585}" width="300" height="35" fill="${c.main}" rx="10"/>
  <text x="${pos.x + 170}" y="${pos.y + 610}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
  });

  svg += `
  <rect x="70" y="1020" width="1060" height="65" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="100" y="1045" font-family="SimHei, sans-serif" font-size="13" font-weight="bold" fill="#228B22">交通指南</text>
  <text x="100" y="1065" font-family="SimHei, sans-serif" font-size="11" fill="#555">${data.tips.transport}</text>
  <text x="650" y="1045" font-family="SimHei, sans-serif" font-size="13" font-weight="bold" fill="#FF69B4">住宿推荐</text>
  <text x="650" y="1065" font-family="SimHei, sans-serif" font-size="11" fill="#555">${data.tips.accommodation}</text>
  
  <text x="600" y="1095" text-anchor="middle" fill="#696969" font-size="12">最佳出行：11月-2月 | 时差：比中国晚1小时 | 汇率：1人民币约5泰铢</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'thailand-3days-v3.svg');
  const pngPath = path.join(process.cwd(), 'thailand-3days-v3.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('Generated: ' + pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
