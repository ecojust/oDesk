const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const chengduMapData = {
  destination: "成都",
  days: [
    {
      name: "Day1 市区",
      color: "#FF69B4",
      pois: [
        { name: "宽窄巷子", x: 250, y: 300, desc: "清代古街" },
        { name: "武侯祠", x: 350, y: 380, desc: "三国圣地" },
        { name: "锦里", x: 400, y: 420, desc: "仿古商业街" },
        { name: "春熙路", x: 500, y: 280, desc: "商圈中心" }
      ]
    },
    {
      name: "Day2 熊猫",
      color: "#4169E1",
      pois: [
        { name: "大熊猫基地", x: 550, y: 180, desc: "看萌主" },
        { name: "东郊记忆", x: 480, y: 250, desc: "文创园" },
        { name: "339电视塔", x: 420, y: 320, desc: "城市地标" },
        { name: "建设路", x: 380, y: 380, desc: "美食天堂" }
      ]
    },
    {
      name: "Day3 古镇",
      color: "#9370DB",
      pois: [
        { name: "洛带古镇", x: 650, y: 350, desc: "客家第一镇" },
        { name: "博客小镇", x: 720, y: 400, desc: "民国风建筑" },
        { name: "返回市区", x: 600, y: 300, desc: "取行李" }
      ]
    }
  ],
  tips: "建议购买天府通卡，地铁公交全覆盖"
};

function generateChengduMiyazakiMap(data) {
  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="750" viewBox="0 0 1000 750">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#E8F5E9"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow">
      <feDropShadow dx="3" dy="3" stdDeviation="3" flood-opacity="0.25"/>
    </filter>
    <filter id="glow">
      <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 32px; font-weight: bold; }
      .subtitle { font-family: 'SimHei', sans-serif; font-size: 16px; }
      .poi-name { font-family: 'SimHei', sans-serif; font-size: 14px; font-weight: bold; }
      .poi-desc { font-family: 'SimHei', sans-serif; font-size: 12px; }
      .legend-text { font-family: 'SimHei', sans-serif; font-size: 13px; }
    </style>
  </defs>
  
  <!-- 天空背景 -->
  <rect width="1000" height="750" fill="url(#sky)"/>
  
  <!-- 装饰云朵 -->
  <ellipse cx="120" cy="80" rx="70" ry="35" fill="#fff" opacity="0.85"/>
  <ellipse cx="180" cy="70" rx="55" ry="28" fill="#fff" opacity="0.85"/>
  <ellipse cx="80" cy="90" rx="45" ry="22" fill="#fff" opacity="0.8"/>
  
  <ellipse cx="850" cy="100" rx="80" ry="40" fill="#fff" opacity="0.8"/>
  <ellipse cx="920" cy="85" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="800" cy="110" rx="50" ry="25" fill="#fff" opacity="0.75"/>
  
  <ellipse cx="500" cy="60" rx="90" ry="45" fill="#fff" opacity="0.7"/>
  <ellipse cx="580" cy="50" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  
  <!-- 飞鸟装饰 -->
  <path d="M300 40 Q310 35 320 40 Q330 35 340 40" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M380 55 Q388 50 396 55 Q404 50 412 55" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M700 70 Q710 65 720 70 Q730 65 740 70" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  
  <!-- 草地装饰 -->
  <ellipse cx="0" cy="750" rx="350" ry="180" fill="url(#grass)" opacity="0.85"/>
  <ellipse cx="1000" cy="750" rx="400" ry="200" fill="url(#grass)" opacity="0.75"/>
  
  <!-- 地图区域背景 -->
  <rect x="50" y="130" width="900" height="580" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <!-- 地图网格 -->
  <g stroke="#E0E0E0" stroke-width="0.8" opacity="0.6">`;
  
  for (let i = 0; i <= 900; i += 60) {
    svg += `\n    <line x1="${50 + i}" y1="130" x2="${50 + i}" y2="710"/>`;
  }
  for (let i = 0; i <= 580; i += 60) {
    svg += `\n    <line x1="50" y1="${130 + i}" x2="950" y2="${130 + i}"/>`;
  }
  
  svg += `\n  </g>
  
  <!-- 河流示意（成都锦江） -->
  <path d="M50,450 Q200,420 350,450 Q500,480 650,420 Q800,360 950,400" fill="none" stroke="#64B5F6" stroke-width="18" opacity="0.5"/>
  <path d="M50,470 Q200,440 350,470 Q500,500 650,440 Q800,380 950,420" fill="none" stroke="#42A5F5" stroke-width="12" opacity="0.4"/>
  
  <!-- 标题 -->
  <text x="500" y="50" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}景点地图</text>
  <text x="500" y="80" text-anchor="middle" class="subtitle" fill="#696969">三日游路线图 · 宫崎骏风格</text>
  
  <!-- 小装饰 -->
  <circle cx="100" cy="100" r="6" fill="#FFD700"/>
  <circle cx="900" cy="100" r="6" fill="#FFD700"/>
  <circle cx="95" cy="110" r="4" fill="#FF69B4"/>
  <circle cx="905" cy="110" r="4" fill="#4169E1"/>`;

  const dayColors = ["#FF69B4", "#4169E1", "#9370DB"];
  const dayNames = ["Day1 市区经典", "Day2 熊猫之旅", "Day3 古镇休闲"];
  
  data.days.forEach((day, dayIndex) => {
    const color = dayColors[dayIndex];
    
    svg += `\n  
  <!-- ${day.name} 路线 -->`;
    
    // 连接线（天到天）
    if (dayIndex > 0) {
      const prevDay = data.days[dayIndex - 1];
      const lastPoi = prevDay.pois[prevDay.pois.length - 1];
      const firstPoi = day.pois[0];
      svg += `\n  <line x1="${lastPoi.x + 50}" y1="${lastPoi.y + 130}" x2="${firstPoi.x + 50}" y2="${firstPoi.y + 130}" stroke="${color}" stroke-width="3" stroke-dasharray="12,6" opacity="0.7"/>`;
    }
    
    day.pois.forEach((poi, i) => {
      const baseX = poi.x + 50;
      const baseY = poi.y + 130;
      const x = baseX;
      const y = baseY + i * 60;
      
      // 景点间连线
      if (i < day.pois.length - 1) {
        const nextPoi = day.pois[i + 1];
        const nextY = baseY + (i + 1) * 60;
        svg += `\n  <line x1="${x}" y1="${y}" x2="${x}" y2="${nextY}" stroke="${color}" stroke-width="3" stroke-dasharray="8,4" opacity="0.6"/>`;
      }
      
      // 景点图标
      svg += `\n  <circle cx="${x}" cy="${y}" r="22" fill="${color}" filter="url(#shadow)"/>`;
      svg += `\n  <text x="${x}" y="${y + 5}" text-anchor="middle" font-size="11" fill="#fff" font-weight="bold">${dayIndex + 1}.${i + 1}</text>`;
      
      // 景点名称气泡
      svg += `\n  <rect x="${x + 30}" y="${y - 22}" width="110" height="44" fill="#fff" rx="8" filter="url(#shadow)"/>`;
      svg += `\n  <rect x="${x + 30}" y="${y - 22}" width="6" height="44" fill="${color}" rx="3"/>`;
      svg += `\n  <text x="${x + 90}" y="${y - 5}" text-anchor="middle" class="poi-name" fill="${color}">${poi.name}</text>`;
      svg += `\n  <text x="${x + 90}" y="${y + 12}" text-anchor="middle" class="poi-desc" fill="#696969">${poi.desc}</text>`;
    });
  });

  svg += `
  
  <!-- 右侧图例卡片 -->
  <rect x="700" y="500" width="220" height="180" fill="#fff" rx="15" filter="url(#shadow)"/>
  <text x="810" y="530" text-anchor="middle" font-size="16" font-weight="bold" fill="#2F4F4F">路线图例</text>
  
  <circle cx="740" cy="565" r="10" fill="#FF69B4" filter="url(#shadow)"/>
  <text x="760" y="570" class="legend-text" fill="#333">Day1 市区经典</text>
  
  <circle cx="740" cy="605" r="10" fill="#4169E1" filter="url(#shadow)"/>
  <text x="760" y="610" class="legend-text" fill="#333">Day2 熊猫之旅</text>
  
  <circle cx="740" cy="645" r="10" fill="#9370DB" filter="url(#shadow)"/>
  <text x="760" y="650" class="legend-text" fill="#333">Day3 古镇休闲</text>
  
  <line x1="720" y1="670" x2="900" y2="670" stroke="#ddd" stroke-width="1"/>
  <text x="810" y="690" text-anchor="middle" font-size="12" fill="#888">--- 天间连接</text>
  
  <!-- 底部提示 -->
  <rect x="80" y="720" width="840" height="25" fill="rgba(255,255,255,0.8)" rx="5"/>
  <text x="500" y="738" text-anchor="middle" font-size="13" fill="#228B22">${data.tips}</text>
  
  <!-- 装饰元素 -->
  <path d="M150 720 Q160 710 170 720 Q180 710 190 720" stroke="#90EE90" stroke-width="2" fill="none"/>
  <path d="M800 720 Q810 710 820 720 Q830 710 840 720" stroke="#90EE90" stroke-width="2" fill="none"/>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateChengduMiyazakiMap(chengduMapData);
  const svgPath = path.join(process.cwd(), 'chengdu-map.svg');
  const pngPath = path.join(process.cwd(), 'chengdu-map-route.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格地图路线图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateChengduMiyazakiMap, chengduMapData };
