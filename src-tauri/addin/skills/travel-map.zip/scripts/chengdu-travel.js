const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "成都",
  days: [
    {
      title: "Day 1",
      subtitle: "市区经典漫游",
      color: "pink",
      schedule: [
        { time: "09:00", location: "双流机场/成都东站", desc: "地铁1号线直达市区", icon: "S" },
        { time: "10:00", location: "宽窄巷子", desc: "清代古街+川西民居", tip: "早去人少，9点开门", icon: "1" },
        { time: "12:00", location: "午餐：龙抄手", desc: "成都名小吃聚集地", icon: "B" },
        { time: "13:30", location: "武侯祠", desc: "三国圣地+红墙竹影", tip: "锦里隔壁，一起逛", icon: "2" },
        { time: "16:00", location: "锦里古街", desc: "夜景超美的仿古商业街", tip: "傍晚灯光亮起更美", icon: "3" },
        { time: "18:30", location: "春熙路商圈", desc: "成都时尚地标+太古里", icon: "4" },
        { time: "20:30", location: "住宿休息", desc: "推荐春熙路/太古里附近", icon: "Z" }
      ]
    },
    {
      title: "Day 2",
      subtitle: "熊猫萌主探访",
      color: "blue",
      schedule: [
        { time: "07:00", location: "早起出发", desc: "前往大熊猫繁育基地", icon: "T" },
        { time: "08:00", location: "大熊猫基地", desc: "看超萌国宝大熊猫", tip: "上午去！下午熊猫睡觉", icon: "1" },
        { time: "11:30", location: "午餐：基地周边", desc: "推荐农家乐川菜", icon: "B" },
        { time: "13:00", location: "东郊记忆", desc: "工业风文创园", tip: "拍照圣地，很出片", icon: "2" },
        { time: "15:30", location: "339电视塔", desc: "俯瞰成都夜景", icon: "3" },
        { time: "18:00", location: "建设路小吃街", desc: "成都地道美食天堂", tip: "必吃：降龙爪爪、烤脑花", icon: "4" },
        { time: "20:30", location: "住宿休息", desc: "可换住九眼桥附近", icon: "Z" }
      ]
    },
    {
      title: "Day 3",
      subtitle: "古镇休闲收官",
      color: "purple",
      schedule: [
        { time: "09:00", location: "洛带古镇", desc: "中国西部客家第一镇", tip: "距市区40分钟车程", icon: "1" },
        { time: "11:30", location: "博客小镇", desc: "民国风客家建筑群", icon: "2" },
        { time: "13:00", location: "午餐：客家菜", desc: "体验客家特色美食", icon: "B" },
        { time: "15:00", location: "返程准备", desc: "返回市区取行李", icon: "T" },
        { time: "17:00", location: "双流机场/成都东站", desc: "完美收官，返程回家", icon: "E" }
      ]
    }
  ],
  tips: {
    transport: "地铁覆盖广（12条线），景点集中在1号线和2号线",
    transport2: "大熊猫基地需提前在官方公众号预约门票",
    accommodation: "春熙路/太古里商圈交通便利，美食购物方便",
    accommodation2: "九眼桥附近夜景美，酒吧一条街适合年轻人"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="950" viewBox="0 0 1200 950">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: 'SimHei', sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', sans-serif; font-size: 14px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', sans-serif; font-size: 16px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', sans-serif; font-size: 13px; fill: #696969; }
      .tip { font-family: 'SimHei', sans-serif; font-size: 12px; fill: #8B4513; font-style: italic; }
    </style>
  </defs>
  
  <rect width="1200" height="950" fill="url(#sky)"/>
  <ellipse cx="150" cy="80" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="200" cy="70" rx="50" ry="25" fill="#fff" opacity="0.8"/>
  <ellipse cx="1000" cy="120" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="1060" cy="110" rx="50" ry="25" fill="#fff" opacity="0.7"/>
  <ellipse cx="600" cy="50" rx="80" ry="40" fill="#fff" opacity="0.6"/>
  <ellipse cx="0" cy="950" rx="300" ry="150" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1200" cy="950" rx="400" ry="180" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="30" y="140" width="1140" height="770" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="90" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}3日游 · 宫崎骏风格时间规划</text>
  <text x="600" y="125" text-anchor="middle" font-size="18" fill="#696969">天府之国 · 熊猫故乡</text>
  
  <circle cx="80" cy="160" r="8" fill="#FF69B4"/>
  <circle cx="90" cy="170" r="6" fill="#FFB6C1"/>
  <circle cx="70" cy="175" r="5" fill="#FF69B4"/>
  <circle cx="1120" cy="160" r="8" fill="#87CEFA"/>
  <circle cx="1130" cy="170" r="6" fill="#B0E0E6"/>`;

  const dayPositions = [
    { x: 60, y: 180, lineX: 110 },
    { x: 430, y: 180, lineX: 480 },
    { x: 800, y: 180, lineX: 850 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="620" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="60" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="340" height="20" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 35}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 58}" text-anchor="middle" font-size="14" fill="#fff">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 90}" x2="${pos.lineX}" y2="${pos.y + 770}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 105 + i * 75;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="22" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="10" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 35}" y="${y - 5}" class="time">${item.time}</text>
  <text x="${pos.lineX + 35}" y="${y + 15}" class="location">${item.location}</text>
  <text x="${pos.lineX + 35}" y="${y + 35}" class="desc">${item.desc}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 35}" y="${y + 55}" class="tip">${item.tip}</text>`;
      }
    });
  });

  svg += `
  <rect x="60" y="830" width="1080" height="90" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="90" y="860" class="location" fill="#228B22">交通小贴士</text>
  <text x="90" y="880" class="desc">${data.tips.transport}</text>
  <text x="90" y="900" class="tip">${data.tips.transport2}</text>
  <text x="650" y="860" class="location" fill="#FF69B4">住宿推荐</text>
  <text x="650" y="880" class="desc">${data.tips.accommodation}</text>
  <text x="650" y="900" class="tip">${data.tips.accommodation2}</text>
  <text x="600" y="940" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：3-5月 / 9-11月</text>
  <path d="M400 40 Q410 30 420 40 Q430 30 440 40" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M800 70 Q810 60 820 70 Q830 60 840 70" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <text x="120" y="130" fill="#FFD700" font-size="14">*</text>
  <text x="1080" y="130" fill="#FFD700" font-size="14">*</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'chengdu-travel.svg');
  const pngPath = path.join(process.cwd(), 'chengdu-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
