const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "广州",
  days: [
    {
      title: "Day 1",
      subtitle: "老城风情",
      color: "pink",
      schedule: [
        { time: "09:00", location: "广州南站/白云机场", desc: "高铁/飞机抵达广州", cost: "¥50", icon: "S" },
        { time: "10:00", location: "陈家祠", desc: "岭南建筑艺术明珠", tip: "广东最大祠堂建筑", cost: "¥10", icon: "1" },
        { time: "12:00", location: "午餐：点都德", desc: "广式早茶必体验", tip: "虾饺/凤爪/流沙包", cost: "¥120", icon: "B" },
        { time: "14:00", location: "永庆坊", desc: "西关风情文创街区", tip: "月亮桥打卡点", cost: "免费", icon: "2" },
        { time: "16:00", location: "沙面岛", desc: "欧陆风情建筑群", tip: "150多座欧洲风格建筑", cost: "免费", icon: "3" },
        { time: "18:30", location: "晚餐：上下九", desc: "骑楼建筑老字号", cost: "¥100", icon: "B" },
        { time: "20:30", location: "住宿：天河/越秀", desc: "推荐地铁沿线酒店", cost: "¥350", icon: "Z" }
      ],
      totalCost: "¥630"
    },
    {
      title: "Day 2",
      subtitle: "中轴线之旅",
      color: "blue",
      schedule: [
        { time: "08:00", location: "酒店出发", desc: "前往花城广场", cost: "¥10", icon: "T" },
        { time: "09:00", location: "花城广场", desc: "远眺广州塔全景", tip: "最佳拍摄小蛮腰位置", cost: "免费", icon: "1" },
        { time: "10:30", location: "广东省博物馆", desc: "需提前预约", tip: "免费入场", cost: "免费", icon: "2" },
        { time: "12:30", location: "午餐：太古汇", desc: "高端美食广场", cost: "¥150", icon: "B" },
        { time: "14:30", location: "广州塔", desc: "中国第一高塔", tip: "433米观光层", cost: "¥180", icon: "3" },
        { time: "17:00", location: "海心沙公园", desc: "亚运会开幕地", cost: "免费", icon: "4" },
        { time: "19:30", location: "珠江夜游", desc: "欣赏两岸灯光夜景", tip: "推荐大沙头码头", cost: "¥98", icon: "5" },
        { time: "21:30", location: "返回酒店", desc: "海珠/天河区域", cost: "¥30", icon: "Z" }
      ],
      totalCost: "¥468"
    },
    {
      title: "Day 3",
      subtitle: "长隆欢乐世界",
      color: "green",
      schedule: [
        { time: "08:30", location: "酒店出发", desc: "前往长隆度假区", cost: "¥30", icon: "T" },
        { time: "09:30", location: "长隆欢乐世界", desc: "中国最大主题乐园", tip: "必玩：十环过山车/大摆锤", cost: "¥350", icon: "1" },
        { time: "12:00", location: "午餐：园区内", desc: "简餐为主", cost: "¥100", icon: "B" },
        { time: "14:00", location: "长隆水上乐园", desc: "水上游乐设施", tip: "夏季必玩", cost: "¥100", icon: "2" },
        { time: "17:30", location: "长隆野生动物世界", desc: "看熊猫三胞胎", tip: "全球唯一存活大熊猫三胞胎", cost: "¥139", icon: "3" },
        { time: "20:00", location: "长隆国际大马戏", desc: "世界级马戏表演", tip: "视觉盛宴（可选）", cost: "¥335", icon: "4" },
        { time: "22:00", location: "返回酒店", desc: "海珠/天河区域", cost: "¥30", icon: "Z" }
      ],
      totalCost: "¥744"
    },
    {
      title: "Day 4",
      subtitle: "自然与返程",
      color: "orange",
      schedule: [
        { time: "08:00", location: "酒店出发", desc: "前往白云山", cost: "¥20", icon: "T" },
        { time: "08:30", location: "白云山", desc: "羊城第一高峰", tip: "乘索道登顶更轻松", cost: "¥5", icon: "1" },
        { time: "11:00", location: "麓湖公园", desc: "市区绿肺休闲", cost: "免费", icon: "2" },
        { time: "12:30", location: "午餐：陶陶居", desc: "百年老字号早茶", tip: "始创于1880年", cost: "¥150", icon: "B" },
        { time: "14:30", location: "北京路步行街", desc: "千年古道遗址", tip: "历史与现代交融", cost: "¥200", icon: "3" },
        { time: "16:30", location: "收拾行李", desc: "返回酒店取行李", cost: "—", icon: "4" },
        { time: "18:00", location: "广州返程", desc: "南站/白云机场送机", cost: "¥50", icon: "E" }
      ],
      totalCost: "¥425"
    }
  ],
  tips: {
    transport: "地铁覆盖全面，建议使用微信乘车码；打车起步价12元",
    transport2: "广州南站在番禺，距市区较远，建议地铁3号线换乘",
    accommodation: "天河/珠江新城：高端现代；越秀/荔湾：老城风情",
    accommodation2: "长隆附近有主题酒店，适合亲子游"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    green: { bg: "#98FB98", main: "#228B22", text: "#228B22" },
    orange: { bg: "#FFDAB9", main: "#FF8C00", text: "#FF8C00" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1350" height="1250" viewBox="0 0 1350 1250">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: 'SimHei', sans-serif; font-size: 18px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', sans-serif; font-size: 12px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', sans-serif; font-size: 13px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', sans-serif; font-size: 11px; fill: #696969; }
      .tip { font-family: 'SimHei', sans-serif; font-size: 10px; fill: #8B4513; font-style: italic; }
      .cost { font-family: 'SimHei', sans-serif; font-size: 11px; font-weight: bold; }
      .total { font-family: 'SimHei', sans-serif; font-size: 14px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1350" height="1250" fill="url(#sky)"/>
  <ellipse cx="150" cy="80" rx="70" ry="35" fill="#fff" opacity="0.8"/>
  <ellipse cx="220" cy="70" rx="55" ry="28" fill="#fff" opacity="0.8"/>
  <ellipse cx="1100" cy="100" rx="80" ry="40" fill="#fff" opacity="0.7"/>
  <ellipse cx="1180" cy="90" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="650" cy="50" rx="90" ry="45" fill="#fff" opacity="0.6"/>
  <ellipse cx="0" cy="1250" rx="400" ry="200" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1350" cy="1250" rx="500" ry="220" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="30" y="130" width="1290" height="1080" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="675" y="75" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}4日3夜 · 宫崎骏风格时间规划</text>
  <text x="675" y="110" text-anchor="middle" font-size="18" fill="#696969">千年商都 · 岭南美食之旅（含费用明细）</text>
  
  <circle cx="80" cy="150" r="8" fill="#FF69B4"/>
  <circle cx="90" cy="160" r="6" fill="#FFB6C1"/>
  <circle cx="70" cy="165" r="5" fill="#FF69B4"/>
  <circle cx="1270" cy="150" r="8" fill="#87CEFA"/>
  <circle cx="1280" cy="160" r="6" fill="#B0E0E6"/>`;

  const dayPositions = [
    { x: 40, y: 160, lineX: 90 },
    { x: 375, y: 160, lineX: 425 },
    { x: 710, y: 160, lineX: 760 },
    { x: 1045, y: 160, lineX: 1095 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="310" height="760" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="310" height="55" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="310" height="15" fill="${c.main}"/>
  <text x="${pos.x + 155}" y="${pos.y + 32}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 155}" y="${pos.y + 52}" text-anchor="middle" font-size="13" fill="#fff">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 90}" x2="${pos.lineX}" y2="${pos.y + 700}" stroke="#fff" stroke-width="3" stroke-dasharray="8,4"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 105 + i * 85;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="16" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 4}" text-anchor="middle" font-size="9" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 28}" y="${y - 2}" class="time">${item.time}</text>
  <text x="${pos.lineX + 28}" y="${y + 12}" class="location">${item.location}</text>
  <text x="${pos.lineX + 28}" y="${y + 28}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 250}" y="${y + 12}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 28}" y="${y + 45}" class="tip">${item.tip}</text>`;
      }
    });

    svg += `
  <rect x="${pos.x + 15}" y="${pos.y + 720}" width="280" height="35" fill="${c.main}" rx="10"/>
  <text x="${pos.x + 155}" y="${pos.y + 743}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
  });

  svg += `
  <rect x="40" y="960" width="1270" height="220" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="675" y="990" text-anchor="middle" font-size="20" font-weight="bold" fill="#2F4F4F">💰 4天3夜费用汇总</text>
  
  <rect x="70" y="1010" width="180" height="70" fill="#FFE4E1" rx="8"/>
  <text x="160" y="1035" text-anchor="middle" font-size="13" fill="#696969">景点门票</text>
  <text x="160" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥1,257</text>
  
  <rect x="270" y="1010" width="180" height="70" fill="#E0FFFF" rx="8"/>
  <text x="360" y="1035" text-anchor="middle" font-size="13" fill="#696969">餐饮美食</text>
  <text x="360" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥620</text>
  
  <rect x="470" y="1010" width="180" height="70" fill="#F0FFF0" rx="8"/>
  <text x="560" y="1035" text-anchor="middle" font-size="13" fill="#696969">当地交通</text>
  <text x="560" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥200</text>
  
  <rect x="670" y="1010" width="180" height="70" fill="#FFF8DC" rx="8"/>
  <text x="760" y="1035" text-anchor="middle" font-size="13" fill="#696969">住宿(3晚)</text>
  <text x="760" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥1,050</text>
  
  <rect x="870" y="1010" width="180" height="70" fill="#E6E6FA" rx="8"/>
  <text x="960" y="1035" text-anchor="middle" font-size="13" fill="#696969">往返交通</text>
  <text x="960" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥100</text>
  
  <rect x="1070" y="1010" width="180" height="70" fill="#FFDAB9" rx="8"/>
  <text x="1160" y="1035" text-anchor="middle" font-size="13" fill="#696969">弹性预算</text>
  <text x="1160" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥400</text>
  
  <rect x="70" y="1100" width="1210" height="60" fill="#DC143C" rx="12"/>
  <text x="675" y="1130" text-anchor="middle" font-size="22" font-weight="bold" fill="#fff">舒适型总预算：¥3,627/人</text>
  
  <text x="80" y="1210" class="location" fill="#228B22">交通小贴士</text>
  <text x="80" y="1230" class="desc">${data.tips.transport}</text>
  <text x="750" y="1210" class="location" fill="#FF69B4">住宿推荐</text>
  <text x="750" y="1230" class="desc">${data.tips.accommodation}</text>
  
  <path d="M300 45 Q310 35 320 45 Q330 35 340 45" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M1000 60 Q1010 50 1020 60 Q1030 50 1040 60" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <text x="140" y="125" fill="#FFD700" font-size="14">✦</text>
  <text x="1200" y="125" fill="#FFD700" font-size="14">✦</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'guangzhou-travel.svg');
  const pngPath = path.join(process.cwd(), 'guangzhou-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
