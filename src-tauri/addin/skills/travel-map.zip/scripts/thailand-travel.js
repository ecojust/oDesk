const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "泰国",
  days: [
    {
      title: "Day 1",
      subtitle: "曼谷经典打卡",
      color: "pink",
      schedule: [
        { time: "08:00", location: "素万那普机场", desc: "落地签快速通道入境", tip: "提前准备好往返机票和酒店预订单", cost: "¥200", icon: "S" },
        { time: "09:30", location: "大皇宫·玉佛寺", desc: "泰国皇室供奉玉佛", tip: "门票包含玉佛寺+柚木宫殿", cost: "¥350", icon: "1" },
        { time: "12:00", location: "午餐：建兴酒家", desc: "咖喱蟹配芒果糯米饭", cost: "¥150", icon: "B" },
        { time: "14:00", location: "卧佛寺", desc: "46米金身卧佛像", tip: "按摩学校可体验正宗泰式按摩", cost: "¥100", icon: "2" },
        { time: "16:00", location: "郑王庙", desc: "湄南河畔黎明之塔", tip: "最佳拍摄点在对面码头", cost: "¥80", icon: "3" },
        { time: "18:00", location: "考山路夜市", desc: "背包客天堂逛吃", cost: "¥200", icon: "4" },
        { time: "21:00", location: "住宿：暹罗商圈", desc: "推荐地铁沿线酒店", cost: "¥350", icon: "Z" }
      ],
      totalCost: "¥1,430"
    },
    {
      title: "Day 2",
      subtitle: "文化艺术探秘",
      color: "blue",
      schedule: [
        { time: "08:30", location: "乍都乍周末市场", desc: "亚洲最大露天市场", tip: "周六日9点开门，可以砍价30%", cost: "¥300", icon: "1" },
        { time: "11:00", location: "美功铁道市场", desc: "火车穿越菜市场奇观", tip: "关注火车经过时间表", cost: "¥50", icon: "2" },
        { time: "13:00", location: "午餐：火车头夜市", desc: "火山排骨+烤海鲜", cost: "¥180", icon: "B" },
        { time: "15:00", location: "四面佛", desc: "Central World旁许愿", tip: "请香买花环参拜", cost: "¥100", icon: "3" },
        { time: "17:00", location: "暹罗广场", desc: "购物+美食+电影", cost: "¥500", icon: "4" },
        { time: "19:30", location: "天空酒吧", desc: "Banyan Tree赏夜景", tip: "着装要求smart casual", cost: "¥250", icon: "5" },
        { time: "22:00", location: "返回酒店休息", desc: "为明天行程养精蓄锐", cost: "¥350", icon: "Z" }
      ],
      totalCost: "¥1,730"
    },
    {
      title: "Day 3",
      subtitle: "泰式风情体验",
      color: "purple",
      schedule: [
        { time: "07:30", location: "水上市场", desc: "丹嫩沙多或安帕瓦", tip: "早起7点到最热闹", cost: "¥150", icon: "1" },
        { time: "10:30", location: "Safari World", desc: "野生动物园+海洋世界", tip: "包含长颈鹿互动", cost: "¥380", icon: "2" },
        { time: "13:00", location: "午餐：园区内", desc: "自助餐选择多样", cost: "¥120", icon: "B" },
        { time: "15:00", location: "金东尼人妖秀", desc: "精彩歌舞表演", tip: "提前订座选好位置", cost: "¥200", icon: "3" },
        { time: "17:00", location: "唐人街", desc: "黄金圣殿+街头美食", tip: "燕窝和鱼翅价格实惠", cost: "¥200", icon: "4" },
        { time: "19:30", location: "返程准备", desc: "前往机场准备回国", cost: "¥100", icon: "E" }
      ],
      totalCost: "¥1,150"
    }
  ],
  tips: {
    transport: "BTS空铁和MRT地铁覆盖主要景点，建议购买一日通票（¥50）",
    transport2: "嘟嘟车和摩的记得砍价，Grab打车更规范",
    accommodation: "暹罗/是隆商圈交通便利，湄南河畔酒店景观佳",
    accommodation2: "建议选靠近地铁站的酒店，出门更方便"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1050" viewBox="0 0 1200 1050">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 14px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 16px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 13px; fill: #696969; }
      .tip { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 12px; fill: #8B4513; font-style: italic; }
      .cost { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 12px; font-weight: bold; }
      .total { font-family: 'SimHei', 'Microsoft YaHei', sans-serif; font-size: 14px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1200" height="1050" fill="url(#sky)"/>
  <ellipse cx="150" cy="80" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="200" cy="70" rx="50" ry="25" fill="#fff" opacity="0.8"/>
  <ellipse cx="1000" cy="120" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="1060" cy="110" rx="50" ry="25" fill="#fff" opacity="0.7"/>
  <ellipse cx="600" cy="50" rx="80" ry="40" fill="#fff" opacity="0.6"/>
  <ellipse cx="0" cy="1050" rx="300" ry="150" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1200" cy="1050" rx="400" ry="180" fill="url(#grass)" opacity="0.7"/>
  
  <path d="M50 60 Q60 40 70 60 Q80 40 90 60" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M1050 90 Q1060 70 1070 90 Q1080 70 1090 90" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  
  <text x="120" y="130" fill="#FFD700" font-size="14">✦</text>
  <text x="1080" y="130" fill="#FFD700" font-size="14">✦</text>
  
  <circle cx="80" cy="160" r="8" fill="#FF69B4"/>
  <circle cx="90" cy="170" r="6" fill="#FFB6C1"/>
  <circle cx="70" cy="175" r="5" fill="#FF69B4"/>
  <circle cx="1120" cy="160" r="8" fill="#87CEFA"/>
  <circle cx="1130" cy="170" r="6" fill="#B0E0E6"/>
  
  <rect x="30" y="150" width="1140" height="820" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="95" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}3日游 · 宫崎骏风格时间规划</text>
  <text x="600" y="130" text-anchor="middle" font-size="18" fill="#696969">微笑国度 · 热带风情之旅（含费用明细）</text>
  
  <circle cx="250" cy="170" r="15" fill="#FF69B4"/>
  <circle cx="600" cy="170" r="15" fill="#4169E1"/>
  <circle cx="950" cy="170" r="15" fill="#9370DB"/>
  <text x="250" y="175" text-anchor="middle" font-size="10" fill="#fff">3</text>
  <text x="600" y="175" text-anchor="middle" font-size="10" fill="#fff">天</text>
  <text x="950" y="175" text-anchor="middle" font-size="10" fill="#fff">2</text>
  
  <line x1="280" y1="170" x2="530" y2="170" stroke="#FFD700" stroke-width="2" stroke-dasharray="5,3"/>
  <line x1="670" y1="170" x2="920" y2="170" stroke="#FFD700" stroke-width="2" stroke-dasharray="5,3"/>
  
  <text x="250" y="195" text-anchor="middle" font-size="12" fill="#FF69B4">夜</text>
  <text x="950" y="195" text-anchor="middle" font-size="12" fill="#9370DB">夜</text>`;

  const dayPositions = [
    { x: 60, y: 220, lineX: 110 },
    { x: 430, y: 220, lineX: 480 },
    { x: 800, y: 220, lineX: 850 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="660" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="60" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="340" height="20" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 35}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 58}" text-anchor="middle" font-size="14" fill="#fff">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 90}" x2="${pos.lineX}" y2="${pos.y + 620}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 105 + i * 72;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="20" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="10" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 35}" y="${y - 5}" class="time">${item.time}</text>
  <text x="${pos.lineX + 35}" y="${y + 12}" class="location">${item.location}</text>
  <text x="${pos.lineX + 35}" y="${y + 32}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 280}" y="${y + 12}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 35}" y="${y + 52}" class="tip">${item.tip}</text>`;
      }
    });

    svg += `
  <rect x="${pos.x + 20}" y="${pos.y + 600}" width="300" height="35" fill="${c.main}" rx="10"/>
  <text x="${pos.x + 170}" y="${pos.y + 625}" text-anchor="middle" class="total">${day.title}小计 ${day.totalCost}</text>`;
  });

  svg += `
  <rect x="60" y="920" width="1080" height="110" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="90" y="950" class="location" fill="#228B22">交通小贴士</text>
  <text x="90" y="975" class="desc">${data.tips.transport}</text>
  <text x="90" y="995" class="tip">${data.tips.transport2}</text>
  <text x="650" y="950" class="location" fill="#FF69B4">住宿推荐</text>
  <text x="650" y="975" class="desc">${data.tips.accommodation}</text>
  <text x="650" y="995" class="tip">${data.tips.accommodation2}</text>
  <text x="600" y="1030" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：11月-次年2月  |  汇率：1人民币≈5泰铢</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'thailand-travel.svg');
  const pngPath = path.join(process.cwd(), 'thailand-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('泰国旅行计划已导出:', pngPath, svgPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
