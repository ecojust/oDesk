const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "香港",
  days: [
    {
      title: "Day 1",
      subtitle: "维港精华游",
      color: "pink",
      totalCost: "¥820",
      schedule: [
        { time: "10:00", location: "西九龙站/机场", desc: "高铁/飞机抵达香港", cost: "¥350", icon: "S" },
        { time: "11:30", location: "尖沙咀", desc: "弥敦道逛街+办理八达通", tip: "港铁+巴士全覆盖", cost: "¥50", icon: "1" },
        { time: "12:30", location: "午餐：兰芳园", desc: "丝袜奶茶+金牌猪扒包", tip: "必吃港式经典", cost: "¥80", icon: "B" },
        { time: "14:00", location: "星光大道", desc: "明星手印+李小龙铜像", cost: "免费", icon: "2" },
        { time: "16:00", location: "天星小轮", desc: "尖沙咀→中环维港之旅", tip: "2港币超值的交通体验", cost: "¥4", icon: "3" },
        { time: "17:00", location: "中环", desc: "中环至半山自动扶梯", cost: "免费", icon: "4" },
        { time: "18:30", location: "太平山顶", desc: "山顶缆车登顶观景", tip: "建议提前网购门票", cost: "¥150", icon: "5" },
        { time: "20:00", location: "凌霄阁", desc: "360度夜景+晚餐", tip: "欣赏维港璀璨夜景", cost: "¥150", icon: "N" },
        { time: "22:00", location: "住宿：尖沙咀", desc: "海景酒店休息", cost: "¥150", icon: "Z" }
      ]
    },
    {
      title: "Day 2",
      subtitle: "美食购物游",
      color: "blue",
      totalCost: "¥680",
      schedule: [
        { time: "09:00", location: "酒店早餐", desc: "港式早茶体验", tip: "推荐翠园/点点心", cost: "¥100", icon: "B" },
        { time: "10:30", location: "铜锣湾", desc: "时代广场+希慎广场", tip: "购物天堂", cost: "¥200", icon: "1" },
        { time: "12:00", location: "午餐：港岛", desc: "一兰拉面/九记牛腩", tip: "米其林推荐", cost: "¥120", icon: "B" },
        { time: "14:00", location: "旺角", desc: "波鞋街/女人街/金鱼街", tip: "体验地道香港风情", cost: "¥100", icon: "2" },
        { time: "16:00", location: "油麻地", desc: "庙街夜市+天后庙", cost: "¥50", icon: "3" },
        { time: "18:00", location: "晚餐：庙街", desc: "咖喱鱼蛋+鸡蛋仔", tip: "街头美食推荐", cost: "¥80", icon: "B" },
        { time: "20:00", location: "维港夜景", desc: "最后一次欣赏维港", tip: "幻彩咏香江灯光秀", cost: "免费", icon: "N" },
        { time: "21:30", location: "返程准备", desc: "采购伴手礼", tip: "钜记手信/曲奇四重奏", cost: "¥150", icon: "E" }
      ]
    }
  ],
  budgetSummary: {
    tickets: "¥354",
    food: "¥510",
    transport: "¥100",
    accommodation: "¥150",
    flight: "¥1,200",
    total: "¥2,314"
  },
  tips: {
    transport: "推荐购买八达通卡，地铁+巴士+叮叮车全覆盖，天星小轮游维港必体验",
    transport2: "太平山顶缆车建议提前网购门票，可省20%排队时间",
    accommodation: "尖沙咀首选，交通便利，距离维港最近，购物美食方便",
    accommodation2: "海景酒店推荐香港喜来登/尖沙咀皇悦，步行可达星光大道"
  }
};

function generateHongKong2DaysMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="1350" viewBox="0 0 1400 1350">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <linearGradient id="budgetBg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#FFFAF0"/>
      <stop offset="100%" style="stop-color:#FFE4E1"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'PingFang SC', 'SimHei', 'Heiti SC', sans-serif; font-size: 38px; font-weight: bold; }
      .day-title { font-family: 'PingFang SC', 'SimHei', 'Heiti SC', sans-serif; font-size: 22px; font-weight: bold; fill: #fff; }
      .time { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 14px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 15px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 12px; fill: #696969; }
      .tip { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 11px; fill: #8B4513; font-style: italic; }
      .cost { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 12px; font-weight: bold; }
      .total-cost { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 14px; font-weight: bold; fill: #DC143C; }
      .budget-title { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 18px; font-weight: bold; fill: #2F4F4F; }
      .budget-item { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 14px; fill: #555; }
      .budget-value { font-family: 'PingFang SC', 'SimHei', sans-serif; font-size: 14px; font-weight: bold; }
    </style>
  </defs>
  
  <rect width="1400" height="1350" fill="url(#sky)"/>
  
  <!-- 云朵装饰 -->
  <ellipse cx="150" cy="80" rx="80" ry="40" fill="#fff" opacity="0.8"/>
  <ellipse cx="220" cy="70" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="1100" cy="130" rx="90" ry="45" fill="#fff" opacity="0.7"/>
  <ellipse cx="1180" cy="115" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="700" cy="60" rx="100" ry="50" fill="#fff" opacity="0.6"/>
  <ellipse cx="350" cy="50" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="1250" cy="60" rx="50" ry="25" fill="#fff" opacity="0.6"/>
  
  <!-- 草地装饰 -->
  <ellipse cx="0" cy="1350" rx="400" ry="200" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1400" cy="1350" rx="500" ry="220" fill="url(#grass)" opacity="0.7"/>
  
  <!-- 飞鸟装饰 -->
  <path d="M300 120 Q310 110 320 120 Q330 110 340 120" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M1000 90 Q1010 80 1020 90 Q1030 80 1040 90" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M600 100 Q610 90 620 100 Q630 90 640 100" stroke="#2F4F4F" stroke-width="1.5" fill="none"/>
  <path d="M850 130 Q860 120 870 130 Q880 120 890 130" stroke="#2F4F4F" stroke-width="1.5" fill="none"/>
  
  <!-- 星星装饰 -->
  <text x="120" y="150" fill="#FFD700" font-size="18">✦</text>
  <text x="1280" y="160" fill="#FFD700" font-size="18">✦</text>
  <text x="500" y="170" fill="#FFD700" font-size="14">✦</text>
  <text x="900" y="180" fill="#FFD700" font-size="14">✦</text>
  
  <!-- 主卡片背景 -->
  <rect x="40" y="180" width="1320" height="900" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <!-- 标题 -->
  <text x="700" y="105" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}2日游 · 宫崎骏风格行程规划</text>
  <text x="700" y="145" text-anchor="middle" font-size="20" fill="#696969">东方之珠 · 精华速览之旅</text>

  <!-- 顶部装饰圆点 -->
  <circle cx="80" cy="200" r="8" fill="#FF69B4"/>
  <circle cx="95" cy="210" r="6" fill="#FFB6C1"/>
  <circle cx="65" cy="215" r="5" fill="#FF69B4"/>
  <circle cx="1320" cy="200" r="8" fill="#87CEFA"/>
  <circle cx="1335" cy="210" r="6" fill="#B0E0E6"/>`;

  const dayWidth = 580;
  const dayHeight = 850;
  const startX = 60;
  const dayY = 230;
  const lineXPositions = [400, 920];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const x = startX + dayIndex * 640;
    
    svg += `
  <!-- Day ${dayIndex + 1} 卡片 -->
  <rect x="${x}" y="${dayY}" width="${dayWidth}" height="${dayHeight}" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${x}" y="${dayY}" width="${dayWidth}" height="70" fill="${c.main}" rx="15"/>
  <rect x="${x}" y="${dayY + 50}" width="${dayWidth}" height="20" fill="${c.main}"/>
  <text x="${x + 290}" y="${dayY + 40}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${x + 290}" y="${dayY + 62}" text-anchor="middle" font-size="14" fill="#fff">${day.subtitle}</text>
  
  <!-- 时间轴线 -->
  <line x1="${lineXPositions[dayIndex]}" y1="${dayY + 100}" x2="${lineXPositions[dayIndex]}" y2="${dayY + 1000}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = dayY + 115 + i * 95;
      const isMeal = item.icon === "B" || item.icon === "S" || item.icon === "Z" || item.icon === "E";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const iconSize = item.icon.length > 1 ? 8 : 11;
      const costColor = item.cost === "免费" ? "#228B22" : "#DC143C";
      
      svg += `
  <!-- 行程项 -->
  <circle cx="${lineXPositions[dayIndex]}" cy="${y}" r="26" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${lineXPositions[dayIndex]}" y="${y + 4}" text-anchor="middle" font-size="${iconSize}" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${lineXPositions[dayIndex] + 45}" y="${y - 10}" class="time">${item.time}</text>
  <text x="${lineXPositions[dayIndex] + 45}" y="${y + 12}" class="location">${item.location}</text>
  <text x="${lineXPositions[dayIndex] + 45}" y="${y + 32}" class="desc">${item.desc}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${lineXPositions[dayIndex] + 45}" y="${y + 52}" class="tip">${item.tip}</text>`;
      }
      
      svg += `
  <text x="${lineXPositions[dayIndex] + 460}" y="${y + 5}" class="cost" fill="${costColor}">${item.cost}</text>`;
    });
    
    // 每日小计
    svg += `
  <!-- 每日小计 -->
  <rect x="${x + 30}" y="${dayY + 1005}" width="${dayWidth - 60}" height="40" fill="#fff" rx="10" opacity="0.9"/>
  <text x="${x + 130}" y="${dayY + 1032}" class="total-cost">今日合计：${day.totalCost}</text>`;
  });

  svg += `
  <!-- 底部提示区域 -->
  <rect x="60" y="1100" width="1280" height="85" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="100" y="1130" class="budget-title" fill="#228B22">✦ 交通小贴士</text>
  <text x="100" y="1152" class="desc">${data.tips.transport}</text>
  <text x="100" y="1170" class="tip">${data.tips.transport2}</text>
  <text x="750" y="1130" class="budget-title" fill="#FF69B4">✦ 住宿推荐</text>
  <text x="750" y="1152" class="desc">${data.tips.accommodation}</text>
  <text x="750" y="1170" class="tip">${data.tips.accommodation2}</text>
  
  <!-- 费用汇总面板 -->
  <rect x="60" y="1200" width="1280" height="100" fill="url(#budgetBg)" rx="12" stroke="#FFB6C1" stroke-width="2"/>
  <text x="100" y="1230" class="budget-title" fill="#FF69B4">💰 费用预算</text>
  
  <text x="100" y="1255" class="budget-item">门票/项目:</text>
  <text x="220" y="1255" class="budget-value" fill="#DC143C">${data.budgetSummary.tickets}</text>
  
  <text x="340" y="1255" class="budget-item">餐饮美食:</text>
  <text x="460" y="1255" class="budget-value" fill="#DC143C">${data.budgetSummary.food}</text>
  
  <text x="580" y="1255" class="budget-item">当地交通:</text>
  <text x="700" y="1255" class="budget-value" fill="#DC143C">${data.budgetSummary.transport}</text>
  
  <text x="820" y="1255" class="budget-item">住宿:</text>
  <text x="910" y="1255" class="budget-value" fill="#DC143C">${data.budgetSummary.accommodation}</text>
  
  <text x="1000" y="1255" class="budget-item">机票:</text>
  <text x="1070" y="1255" class="budget-value" fill="#DC143C">${data.budgetSummary.flight}</text>
  
  <rect x="100" y="1270" width="1180" height="2" fill="#FFB6C1" opacity="0.5"/>
  
  <text x="100" y="1295" class="budget-title" fill="#2F4F4F">💎 总预算:</text>
  <text x="230" y="1295" class="budget-value" fill="#DC143C" font-size="20">${data.budgetSummary.total}</text>
  <text x="350" y="1295" class="budget-item">(人均)</text>
  
  <!-- 页脚 -->
  <text x="700" y="1330" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：3-5月 / 9-11月 | 汇率参考：1港币≈0.92人民币</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateHongKong2DaysMiyazakiStyle(itinerary);
  const svgPath = path.join(__dirname, 'temp-hongkong-2days.svg');
  const pngPath = path.join(__dirname, '..', '..', '..', 'hongkong-2days-miyazaki.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => {
      console.log('✅ 香港2天2夜宫崎骏风格行程图已生成:', pngPath);
      fs.unlinkSync(svgPath);
    })
    .catch(console.error);
}

module.exports = { generateHongKong2DaysMiyazakiStyle, itinerary };
