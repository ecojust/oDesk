const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const chongqingMapData = {
  destination: "重庆",
  days: [
    {
      name: "Day1 渝中",
      color: "#FF69B4",
      pois: [
        { name: "鹅岭栈桥", x: 300, y: 280, desc: "新晋顶流" },
        { name: "鹅岭二厂", x: 350, y: 320, desc: "文创园" },
        { name: "解放碑", x: 450, y: 400, desc: "商圈" },
        { name: "洪崖洞", x: 500, y: 450, desc: "夜景" }
      ]
    },
    {
      name: "Day2 南岸",
      color: "#4169E1",
      pois: [
        { name: "长江索道", x: 550, y: 350, desc: "索道" },
        { name: "南山一棵树", x: 650, y: 300, desc: "观景台" },
        { name: "南滨路", x: 600, y: 400, desc: "江景" }
      ]
    },
    {
      name: "Day3 沙坪坝",
      color: "#9370DB",
      pois: [
        { name: "磁器口", x: 200, y: 500, desc: "古镇" },
        { name: "白公馆", x: 250, y: 550, desc: "纪念馆" },
        { name: "歌乐山", x: 180, y: 600, desc: "森林公园" }
      ]
    }
  ],
  tips: "轻轨为主，建议购买一日票"
};

function generateMapStyle(data) {
  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="900" height="700" viewBox="0 0 900 700">
  <defs>
    <linearGradient id="mapBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#E8F5E9"/>
      <stop offset="100%" style="stop-color:#C8E6C9"/>
    </linearGradient>
    <filter id="shadow">
      <feDropShadow dx="2" dy="2" stdDeviation="2" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 28px; font-weight: bold; }
      .poi-name { font-family: 'SimHei', sans-serif; font-size: 13px; font-weight: bold; }
      .poi-desc { font-family: 'SimHei', sans-serif; font-size: 11px; }
    </style>
  </defs>
  
  <!-- 地图背景 -->
  <rect width="900" height="700" fill="url(#mapBg)"/>
  
  <!-- 网格线 -->
  <g stroke="#A5D6A7" stroke-width="0.5" opacity="0.5">`;
  
  for (let i = 0; i <= 900; i += 50) {
    svg += `\n    <line x1="${i}" y1="0" x2="${i}" y2="700"/>`;
  }
  for (let i = 0; i <= 700; i += 50) {
    svg += `\n    <line x1="0" y1="${i}" x2="900" y2="${i}"/>`;
  }
  
  svg += `\n  </g>
  
  <!-- 河流示意 -->
  <path d="M0,400 Q200,350 400,420 Q600,480 900,400" fill="none" stroke="#64B5F6" stroke-width="20" opacity="0.6"/>
  <path d="M0,450 Q300,400 500,480 Q700,550 900,500" fill="none" stroke="#42A5F5" stroke-width="15" opacity="0.5"/>
  
  <!-- 标题 -->
  <text x="450" y="50" text-anchor="middle" class="title" fill="#2E7D32">${data.destination}景点地图</text>
  <text x="450" y="80" text-anchor="middle" font-size="14" fill="#388E3C">三日游路线概览</text>`;

  const dayColors = ["#FF69B4", "#4169E1", "#9370DB"];
  const dayNames = ["Day1 渝中区", "Day2 南岸区", "Day3 沙坪坝区"];
  
  data.days.forEach((day, dayIndex) => {
    const color = dayColors[dayIndex];
    const yOffset = 120 + dayIndex * 180;
    
    svg += `\n  <!-- ${dayNames[dayIndex]} -->`;
    
    if (dayIndex > 0) {
      const prevDay = data.days[dayIndex - 1];
      const lastPoi = prevDay.pois[prevDay.pois.length - 1];
      const firstPoi = day.pois[0];
      svg += `\n  <line x1="${lastPoi.x}" y1="${lastPoi.y}" x2="${firstPoi.x}" y2="${firstPoi.y}" stroke="${color}" stroke-width="2" stroke-dasharray="8,4" opacity="0.6"/>`;
    }
    
    day.pois.forEach((poi, i) => {
      const x = poi.x;
      const y = yOffset + i * 50;
      
      if (i < day.pois.length - 1) {
        const nextPoi = day.pois[i + 1];
        svg += `\n  <line x1="${x}" y1="${y}" x2="${x}" y2="${yOffset + (i + 1) * 50}" stroke="${color}" stroke-width="2" stroke-dasharray="5,3" opacity="0.5"/>`;
      }
      
      svg += `\n  <circle cx="${x}" cy="${y}" r="18" fill="${color}" filter="url(#shadow)"/>
  <text x="${x}" y="${y + 4}" text-anchor="middle" font-size="10" fill="#fff" font-weight="bold">${dayIndex + 1}.${i + 1}</text>
  <text x="${x + 30}" y="${y - 5}" class="poi-name" fill="${color}">${poi.name}</text>
  <text x="${x + 30}" y="${y + 12}" class="poi-desc" fill="#558B2F">${poi.desc}</text>`;
    });
  });

  svg += `
  
  <!-- 图例 -->
  <rect x="700" y="550" width="180" height="120" fill="#fff" rx="10" stroke="#A5D6A7" stroke-width="2"/>
  <text x="790" y="575" text-anchor="middle" font-weight="bold" fill="#2E7D32">图例</text>
  <circle cx="730" cy="600" r="8" fill="#FF69B4"/><text x="750" y="604" font-size="12" fill="#333">Day1 渝中</text>
  <circle cx="730" cy="625" r="8" fill="#4169E1"/><text x="750" y="629" font-size="12" fill="#333">Day2 南岸</text>
  <circle cx="730" cy="650" r="8" fill="#9370DB"/><text x="750" y="654" font-size="12" fill="#333">Day3 沙坪坝</text>
  
  <!-- 底部提示 -->
  <text x="450" y="680" text-anchor="middle" font-size="12" fill="#558B2F">${data.tips}</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMapStyle(chongqingMapData);
  const svgPath = path.join(__dirname, 'chongqing-map.svg');
  const pngPath = path.join(__dirname, '..', 'chongqing-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('地图风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMapStyle, chongqingMapData };