const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

function toSvg(data) {
  const elements = data.elements || [];
  let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400">
    <style>
      @font-face {
        font-family: "Virgil";
        src: url("https://excalidraw.com/Virgil.woff2");
      }
    </style>
    <rect width="800" height="400" fill="${data.appState?.viewBackgroundColor || '#ffffff'}"/>`;

  for (const el of elements) {
    if (el.type === 'text') {
      svgContent += `\n    <text x="${el.x}" y="${el.y}" font-family="Virgil, sans-serif" font-size="${el.fontSize}" fill="${el.strokeColor}">${el.text}</text>`;
    } else if (el.type === 'rectangle') {
      svgContent += `\n    <rect x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}" fill="${el.backgroundColor || 'transparent'}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth || 2}"/>`;
    } else if (el.type === 'ellipse') {
      const cx = el.x + (el.width || 0) / 2;
      const cy = el.y + (el.height || 0) / 2;
      const rx = (el.width || 0) / 2;
      const ry = (el.height || 0) / 2;
      svgContent += `\n    <ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${el.backgroundColor || 'transparent'}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth || 2}"/>`;
    } else if (el.type === 'line') {
      svgContent += `\n    <line x1="${el.x}" y1="${el.y}" x2="${el.x + (el.width || 0)}" y2="${el.y + (el.height || 0)}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth || 2}"/>`;
    } else if (el.type === 'arrow') {
      const endX = el.x + (el.width || 0);
      const endY = el.y + (el.height || 0);
      svgContent += `\n    <line x1="${el.x}" y1="${el.y}" x2="${endX}" y2="${endY}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth || 2}" marker-end="url(#arrowhead)"/>`;
    }
  }

  svgContent += `\n</svg>`;
  return svgContent;
}

async function exportToPng(data, outputPath, options = {}) {
  const svg = toSvg(data);
  const width = options.width || 800;
  const height = options.height || 400;
  const svgBuffer = Buffer.from(svg);

  await sharp(svgBuffer)
    .resize(width, height)
    .png()
    .toFile(outputPath);

  return outputPath;
}

if (require.main === module) {
  const excalidrawData = {
    type: "excalidraw",
    version: 2,
    elements: [
      {
        type: "text",
        x: 200,
        y: 200,
        fontSize: 40,
        fontFamily: 1,
        text: "Hello World",
        strokeColor: "#000000"
      }
    ],
    appState: {
      viewBackgroundColor: "#ffffff"
    }
  };

  const outputPath = process.argv[2] || path.join(__dirname, '..', 'hello-world.png');

  exportToPng(excalidrawData, outputPath)
    .then(() => console.log('Exported to:', outputPath))
    .catch(console.error);
}

module.exports = { exportToPng, toSvg };