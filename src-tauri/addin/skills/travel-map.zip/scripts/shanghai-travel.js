const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const shanghaiData = {
  destination: "上海",
  days: [
    {
      name: "Day1 浦江经典",
      color: "#FF69B4",
      subtitle: "外滩·陆家嘴",
      pois: [
        { name: "外滩", x: 280, y: 320, desc: "万国建筑博览", icon: "1" },
        { name: "南京路步行街", x: 400, y: 280, desc: "中华第一街", icon: "2" },
        { name: "陆家嘴", x: 500, y: 380, desc: "摩天大楼群", icon: "3" },
        { name: "东方明珠", x: 550, y: 420, desc: "城市地标", icon: "4" }
      ]
    },
    {
      name: "Day2 申城文韵",
      color: "#4169E1",
      subtitle: "豫园·新天地",
      pois: [
        { name: "豫园", x: 320, y: 450, desc: "江南园林", icon: "1" },
        { name: "城隍庙", x: 380, y: 480, desc: "小吃天堂", icon: "2" },
        { name: "田子坊", x: 200, y: 520, desc: "弄堂文创", icon: "3" },
        { name: "新天地", x: 280, y: 560, desc: "石库门风情", icon: "4" }
      ]
    },
    {
      name: "Day3 海派风情",
      color: "#9370DB",
      subtitle: "静安·虹桥",
      pois: [
        { name: "静安寺", x: 450, y: 550, desc: "都市古刹", icon: "1" },
        { name: "武康路", x: 350, y: 600, desc: "梧桐街区", icon: "2" },
        { name: "上海博物馆", x: 250, y: 640, desc: "文物珍藏", icon: "3" },
        { name: "外滩源", x: 220, y: 280, desc: "历史建筑群", icon: "4" }
      ]
    }
  ],
  tips: "建议购买地铁一日票，外滩至陆家嘴可乘坐观光隧道"
};

function generateMiyazakiMapStyle(data) {
  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="900" viewBox="0 0 800 900">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="70%" style="stop-color:#FFFAF0"/>
      <stop offset="100%" style="stop-color:#FFE4E1"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <linearGradient id="river" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#64B5F6"/>
      <stop offset="100%" style="stop-color:#1976D2"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 32px; font-weight: bold; }
      .subtitle { font-family: 'SimHei', sans-serif; font-size: 16px; fill: #696969; }
      .day-title { font-family: 'SimHei', sans-serif; font-size: 14px; font-weight: bold; }
      .poi-name { font-family: 'SimHei', sans-serif; font-size: 12px; font-weight: bold; }
      .poi-desc { font-family: 'SimHei', sans-serif; font-size: 10px; }
    </style>
  </defs>
  
  <rect width="800" height="900" fill="url(#sky)"/>
  
  <ellipse cx="100" cy="60" rx="70" ry="35" fill="#fff" opacity="0.9"/>
  <ellipse cx="160" cy="50" rx="55" ry="28" fill="#fff" opacity="0.85"/>
  <ellipse cx="650" cy="90" rx="80" ry="40" fill="#fff" opacity="0.8"/>
  <ellipse cx="720" cy="80" rx="60" ry="30" fill="#fff" opacity="0.75"/>
  <ellipse cx="400" cy="40" rx="90" ry="45" fill="#fff" opacity="0.7"/>
  <ellipse cx="50" cy="120" rx="40" ry="20" fill="#fff" opacity="0.6"/>
  <ellipse cx="750" cy="150" rx="45" ry="22" fill="#fff" opacity="0.65"/>
  
  <ellipse cx="-100" cy="900" rx="400" ry="200" fill="url(#grass)" opacity="0.85"/>
  <ellipse cx="900" cy="900" rx="450" ry="220" fill="url(#grass)" opacity="0.75"/>
  <ellipse cx="400" cy="920" rx="300" ry="150" fill="url(#grass)" opacity="0.8"/>
  
  <path d="M0 380 Q150 350 300 400 Q450 450 600 420 Q700 400 800 430" fill="none" stroke="url(#river)" stroke-width="25" opacity="0.6"/>
  <path d="M0 400 Q200 380 350 430 Q500 470 650 440 Q750 420 800 450" fill="none" stroke="#42A5F5" stroke-width="15" opacity="0.4"/>
  
  <ellipse cx="650" cy="380" rx="35" ry="18" fill="#FFB6C1" opacity="0.7"/>
  <ellipse cx="100" cy="300" rx="30" ry="15" fill="#98FB98" opacity="0.6"/>
  <ellipse cx="700" cy="500" rx="25" ry="12" fill="#ADD8E6" opacity="0.5"/>
  
  <path d="M300 35 Q310 25 320 35 Q330 25 340 35" stroke="#2F4F4F" stroke-width="1.5" fill="none"/>
  <path d="M500 55 Q510 45 520 55 Q530 45 540 55" stroke="#2F4F4F" stroke-width="1.5" fill="none"/>
  
  <rect x="40" y="150" width="720" height="650" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="400" y="100" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}3日游</text>
  <text x="400" y="135" text-anchor="middle" class="subtitle">宫崎骏风格地图路线</text>`;

  const dayColors = ["#FF69B4", "#4169E1", "#9370DB"];
  const dayY = [200, 420, 640];
  
  data.days.forEach((day, dayIndex) => {
    const color = dayColors[dayIndex];
    const yBase = dayY[dayIndex];
    
    svg += `
  <rect x="60" y="${yBase}" width="680" height="180" fill="${color}" opacity="0.15" rx="12"/>
  <text x="80" y="${yBase + 30}" class="day-title" fill="${color}">${day.name}</text>
  <text x="80" y="${yBase + 50}" font-size="11" fill="#888">${day.subtitle}</text>`;
    
    day.pois.forEach((poi, i) => {
      const x = poi.x;
      const y = yBase + 80 + i * 24;
      
      svg += `
  <circle cx="${x}" cy="${y}" r="12" fill="${color}" filter="url(#shadow)"/>
  <text x="${x}" y="${y + 4}" text-anchor="middle" font-size="9" fill="#fff" font-weight="bold">${poi.icon}</text>
  <text x="${x + 22}" y="${y - 2}" class="poi-name" fill="${color}">${poi.name}</text>
  <text x="${x + 22}" y="${y + 10}" class="poi-desc" fill="#696969">${poi.desc}</text>`;
    });
  });

  svg += `
  <rect x="60" y="840" width="680" height="40" fill="#FFFAF0" rx="10" stroke="#DEB887" stroke-width="1.5"/>
  <text x="400" y="865" text-anchor="middle" font-size="12" fill="#8B4513">${data.tips}</text>
  
  <rect x="60" y="830" width="10" height="60" fill="#FF69B4" rx="3"/>
  <rect x="730" y="830" width="10" height="60" fill="#9370DB" rx="3"/>
  
  <text x="400" y="895" text-anchor="middle" font-size="12" fill="#696969">最佳出行季节：3-5月 / 9-11月</text>
</svg>`;

  return svg;
}

const svg = generateMiyazakiMapStyle(shanghaiData);
const svgPath = path.join(process.cwd(), 'shanghai-travel-map.svg');
const pngPath = path.join(process.cwd(), 'shanghai-travel-map.png');

fs.writeFileSync(svgPath, svg);

sharp(svgPath)
  .png()
  .toFile(pngPath)
  .then(() => console.log('上海旅行地图已导出:', pngPath))
  .catch(console.error);
