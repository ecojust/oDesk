const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "三亚",
  days: [
    {
      title: "Day 1",
      subtitle: "热带雨林探秘",
      color: "pink",
      schedule: [
        { time: "12:00", location: "三亚凤凰机场", desc: "专车接机前往亚龙湾", cost: "¥80", icon: "S" },
        { time: "14:00", location: "亚龙湾热带天堂森林公园", desc: "《非诚勿扰2》取景地", tip: "含观光车游览", cost: "¥158", icon: "1" },
        { time: "17:00", location: "亚龙湾海滩", desc: "天下第一湾细腻沙滩", tip: "傍晚看日落最佳", cost: "免费", icon: "2" },
        { time: "19:00", location: "晚餐：百花谷商业街", desc: "亚龙湾核心区餐饮购物", cost: "¥150", icon: "B" },
        { time: "21:00", location: "住宿：亚龙湾酒店", desc: "海景房推荐", cost: "¥350", icon: "Z" }
      ],
      totalCost: "¥738"
    },
    {
      title: "Day 2",
      subtitle: "蜈支洲岛玻璃海",
      color: "blue",
      schedule: [
        { time: "08:00", location: "酒店出发", desc: "前往蜈支洲岛码头", cost: "¥60", icon: "T" },
        { time: "09:00", location: "蜈支洲岛", desc: "中国版马尔代夫", tip: "能见度27米玻璃海", cost: "¥140", icon: "1" },
        { time: "10:30", location: "潜水体验", desc: "珊瑚礁保护区", tip: "玻璃海深潜", cost: "¥380", icon: "2" },
        { time: "13:00", location: "午餐：岛上餐厅", desc: "简餐为主", cost: "¥80", icon: "B" },
        { time: "14:30", location: "海上项目", desc: "拖伞/摩托艇/香蕉船", tip: "动感套票", cost: "¥280", icon: "3" },
        { time: "17:00", location: "返回酒店", desc: "海棠湾区域", cost: "¥60", icon: "4" }
      ],
      totalCost: "¥1,000"
    },
    {
      title: "Day 3",
      subtitle: "文化风情之旅",
      color: "purple",
      schedule: [
        { time: "08:30", location: "南山文化旅游区", desc: "108米海上观音", tip: "含园区电瓶车", cost: "¥129", icon: "1" },
        { time: "12:00", location: "午餐：南山素斋", desc: "景区特色餐饮", cost: "¥80", icon: "B" },
        { time: "14:00", location: "天涯海角", desc: "三亚地标巨石", tip: "爱情象征地", cost: "¥68", icon: "2" },
        { time: "17:30", location: "椰梦长廊", desc: "20公里看日落", tip: "17:30-18:30人少", cost: "免费", icon: "3" },
        { time: "19:30", location: "晚餐：第一市场", desc: "海鲜加工", tip: "自购加工更划算", cost: "¥200", icon: "B" }
      ],
      totalCost: "¥477"
    },
    {
      title: "Day 4",
      subtitle: "亚特兰蒂斯狂欢",
      color: "green",
      schedule: [
        { time: "09:00", location: "亚特兰蒂斯水世界", desc: "34条水上滑道", tip: "海神之跃必玩", cost: "¥298", icon: "1" },
        { time: "13:00", location: "失落空间水族馆", desc: "30个展示池", tip: "美人鱼表演", cost: "¥198", icon: "2" },
        { time: "15:00", location: "cdf三亚国际免税城", desc: "全球最大单体免税店", tip: "12万平米", cost: "—", icon: "3" },
        { time: "19:00", location: "晚餐：海棠68美食城", desc: "综合美食广场", cost: "¥180", icon: "B" }
      ],
      totalCost: "¥676"
    },
    {
      title: "Day 5",
      subtitle: "悠闲返程",
      color: "orange",
      schedule: [
        { time: "08:30", location: "鹿回头风景区", desc: "俯瞰三亚全景", tip: "登高望海", cost: "¥42", icon: "1" },
        { time: "10:30", location: "大东海", desc: "老牌海滨浴场", cost: "免费", icon: "2" },
        { time: "12:00", location: "午餐：港华广场", desc: "当地美食", cost: "¥100", icon: "B" },
        { time: "14:00", location: "收拾行李", desc: "返回酒店取行李", cost: "—", icon: "3" },
        { time: "16:00", location: "送机前往机场", desc: "凤凰机场送机", cost: "¥80", icon: "E" }
      ],
      totalCost: "¥222"
    }
  ],
  tips: {
    transport: "机场至亚龙湾约40分钟；蜈支洲岛需乘船20分钟",
    transport2: "景点间打车方便，建议下载滴滴出行",
    accommodation: "亚龙湾/海棠湾海景酒店，五星品牌居多",
    accommodation2: "亚龙湾适合亲子，海棠湾更清静"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" },
    green: { bg: "#98FB98", main: "#228B22", text: "#228B22" },
    orange: { bg: "#FFDAB9", main: "#FF8C00", text: "#FF8C00" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1450" height="1250" viewBox="0 0 1450 1250">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: 'SimHei', sans-serif; font-size: 18px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', sans-serif; font-size: 12px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', sans-serif; font-size: 13px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', sans-serif; font-size: 11px; fill: #696969; }
      .tip { font-family: 'SimHei', sans-serif; font-size: 10px; fill: #8B4513; font-style: italic; }
      .cost { font-family: 'SimHei', sans-serif; font-size: 11px; fill: #DC143C; font-weight: bold; }
      .total { font-family: 'SimHei', sans-serif; font-size: 14px; font-weight: bold; fill: #fff; }
    </style>
  </defs>
  
  <rect width="1450" height="1250" fill="url(#sky)"/>
  <ellipse cx="150" cy="80" rx="70" ry="35" fill="#fff" opacity="0.8"/>
  <ellipse cx="220" cy="70" rx="55" ry="28" fill="#fff" opacity="0.8"/>
  <ellipse cx="1200" cy="100" rx="80" ry="40" fill="#fff" opacity="0.7"/>
  <ellipse cx="1280" cy="90" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="700" cy="50" rx="90" ry="45" fill="#fff" opacity="0.6"/>
  <ellipse cx="0" cy="1250" rx="400" ry="200" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1450" cy="1250" rx="500" ry="220" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="30" y="130" width="1390" height="1080" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="725" y="75" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}5日4夜 · 宫崎骏风格时间规划</text>
  <text x="725" y="110" text-anchor="middle" font-size="18" fill="#696969">东方夏威夷 · 热带天堂之旅（含费用明细）</text>
  
  <circle cx="80" cy="150" r="8" fill="#FF69B4"/>
  <circle cx="90" cy="160" r="6" fill="#FFB6C1"/>
  <circle cx="70" cy="165" r="5" fill="#FF69B4"/>
  <circle cx="1370" cy="150" r="8" fill="#87CEFA"/>
  <circle cx="1380" cy="160" r="6" fill="#B0E0E6"/>`;

  const dayPositions = [
    { x: 40, y: 160, lineX: 90 },
    { x: 325, y: 160, lineX: 375 },
    { x: 610, y: 160, lineX: 660 },
    { x: 895, y: 160, lineX: 945 },
    { x: 1180, y: 160, lineX: 1230 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="260" height="760" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="260" height="55" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="260" height="15" fill="${c.main}"/>
  <text x="${pos.x + 130}" y="${pos.y + 32}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 130}" y="${pos.y + 52}" text-anchor="middle" font-size="13" fill="#fff">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 90}" x2="${pos.lineX}" y2="${pos.y + 700}" stroke="#fff" stroke-width="3" stroke-dasharray="8,4"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 105 + i * 95;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const isFree = item.cost === "免费" || item.cost === "—";
      const costColor = isFree ? "#228B22" : "#DC143C";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="16" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 4}" text-anchor="middle" font-size="9" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 28}" y="${y - 2}" class="time">${item.time}</text>
  <text x="${pos.lineX + 28}" y="${y + 12}" class="location">${item.location}</text>
  <text x="${pos.lineX + 28}" y="${y + 28}" class="desc">${item.desc}</text>
  <text x="${pos.lineX + 200}" y="${y + 12}" text-anchor="end" class="cost" fill="${costColor}">${item.cost}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 28}" y="${y + 45}" class="tip">${item.tip}</text>`;
      }
    });

    svg += `
  <rect x="${pos.x + 10}" y="${pos.y + 720}" width="240" height="35" fill="${c.main}" rx="10"/>
  <text x="${pos.x + 130}" y="${pos.y + 743}" text-anchor="middle" class="total">Day ${dayIndex + 1} 小计 ${day.totalCost}</text>`;
  });

  svg += `
  <rect x="40" y="960" width="1350" height="220" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="725" y="990" text-anchor="middle" font-size="20" font-weight="bold" fill="#2F4F4F">💰 5天4夜费用汇总</text>
  
  <rect x="70" y="1010" width="200" height="70" fill="#FFE4E1" rx="8"/>
  <text x="170" y="1035" text-anchor="middle" font-size="13" fill="#696969">景点+项目</text>
  <text x="170" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥2,413</text>
  
  <rect x="290" y="1010" width="200" height="70" fill="#E0FFFF" rx="8"/>
  <text x="390" y="1035" text-anchor="middle" font-size="13" fill="#696969">餐饮美食</text>
  <text x="390" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥790</text>
  
  <rect x="510" y="1010" width="200" height="70" fill="#F0FFF0" rx="8"/>
  <text x="610" y="1035" text-anchor="middle" font-size="13" fill="#696969">当地交通</text>
  <text x="610" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥340</text>
  
  <rect x="730" y="1010" width="200" height="70" fill="#FFF8DC" rx="8"/>
  <text x="830" y="1035" text-anchor="middle" font-size="13" fill="#696969">住宿(4晚)</text>
  <text x="830" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥1,400</text>
  
  <rect x="950" y="1010" width="200" height="70" fill="#E6E6FA" rx="8"/>
  <text x="1050" y="1035" text-anchor="middle" font-size="13" fill="#696969">往返机票</text>
  <text x="1050" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥2,000</text>
  
  <rect x="1170" y="1010" width="200" height="70" fill="#FFDAB9" rx="8"/>
  <text x="1270" y="1035" text-anchor="middle" font-size="13" fill="#696969">弹性预算</text>
  <text x="1270" y="1060" text-anchor="middle" font-size="18" font-weight="bold" fill="#DC143C">¥500</text>
  
  <rect x="70" y="1100" width="1310" height="60" fill="#DC143C" rx="12"/>
  <text x="725" y="1130" text-anchor="middle" font-size="22" font-weight="bold" fill="#fff">舒适型总预算：¥7,443/人</text>
  
  <text x="80" y="1210" class="location" fill="#228B22">交通小贴士</text>
  <text x="80" y="1230" class="desc">${data.tips.transport} · ${data.tips.transport2}</text>
  <text x="750" y="1210" class="location" fill="#FF69B4">住宿推荐</text>
  <text x="750" y="1230" class="desc">${data.tips.accommodation} · ${data.tips.accommodation2}</text>
  
  <path d="M300 45 Q310 35 320 45 Q330 35 340 45" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M1100 60 Q1110 50 1120 60 Q1130 50 1140 60" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <text x="140" y="125" fill="#FFD700" font-size="14">✦</text>
  <text x="1300" y="125" fill="#FFD700" font-size="14">✦</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'sanya-travel.svg');
  const pngPath = path.join(process.cwd(), 'sanya-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };
