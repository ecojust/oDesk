const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "香港",
  days: [
    {
      title: "Day 1",
      subtitle: "维港经典游",
      color: "pink",
      schedule: [
        { time: "09:00", location: "香港机场/西九龙站", desc: "机场快线/高铁直达市区", icon: "S" },
        { time: "10:30", location: "尖沙咀", desc: "弥敦道逛街+午餐", tip: "推荐港式茶餐厅", icon: "1" },
        { time: "14:00", location: "星光大道", desc: "寻找明星手印+李小龙雕像", icon: "2" },
        { time: "16:00", location: "香港艺术馆/M+", desc: "当代艺术展览", tip: "周三至周五免费", icon: "3" },
        { time: "18:00", location: "维港散步", desc: "欣赏日落+海旁漫步", icon: "4" },
        { time: "20:00", location: "幻彩詠香江", desc: "每晚8点灯光秀", tip: "建议在尖沙咀海旁观看", icon: "N" },
        { time: "21:30", location: "住宿休息", desc: "推荐尖沙咀/旺角附近", icon: "Z" }
      ]
    },
    {
      title: "Day 2",
      subtitle: "太平山全景",
      color: "blue",
      schedule: [
        { time: "08:30", location: "山顶缆车", desc: "百年缆车登太平山顶", tip: "建议提前预订门票", icon: "1" },
        { time: "10:00", location: "凌霄阁摩天台428", desc: "360度俯瞰香港全景", icon: "2" },
        { time: "11:30", location: "杜莎夫人蜡像馆", desc: "与名人明星合影", icon: "3" },
        { time: "12:30", location: "午餐：山顶广场", desc: "山顶用餐选择多", icon: "B" },
        { time: "14:00", location: "中环", desc: "中环至半山自动扶梯", icon: "4" },
        { time: "16:00", location: "叮叮车", desc: "百年电车漫游港岛", icon: "5" },
        { time: "18:00", location: "铜锣湾", desc: "时代广场购物+美食", icon: "6" },
        { time: "20:00", location: "兰桂坊", desc: "香港夜生活代表", icon: "N" }
      ]
    },
    {
      title: "Day 3",
      subtitle: "大嶼山祈福",
      color: "purple",
      schedule: [
        { time: "09:00", location: "昂坪360缆车", desc: "水晶车厢俯瞰美景", tip: "25分钟到昂坪", icon: "1" },
        { time: "10:30", location: "天坛大佛", desc: "世界最高户外坐佛", icon: "2" },
        { time: "11:30", location: "宝莲寺", desc: "百年古刹祈福", icon: "3" },
        { time: "12:30", location: "午餐：昂坪村", desc: "特色素斋/茶餐厅", icon: "B" },
        { time: "14:00", location: "昂坪返回市区", desc: "缆车/巴士返回", icon: "T" },
        { time: "16:00", location: "旺角", desc: "波鞋街/女人街/金鱼街", icon: "4" },
        { time: "18:00", location: "晚餐：港式火锅", desc: "推荐热门打边炉", icon: "B" },
        { time: "20:00", location: "购物时间", desc: "朗豪坊/西洋菜街", icon: "5" }
      ]
    },
    {
      title: "Day 4",
      subtitle: "海洋/迪士尼",
      color: "green",
      schedule: [
        { time: "09:00", location: "香港迪士尼", desc: "冰雪奇缘世界+烟火", tip: "建议买一日票", icon: "1" },
        { time: "12:00", location: "园内午餐", desc: "主题餐厅美食", icon: "B" },
        { time: "14:00", location: "继续玩乐", desc: "机动游戏+表演", icon: "2" },
        { time: "18:00", location: "烟火表演", desc: "无人机+烟花汇演", tip: "21:30开始", icon: "N" },
        { time: "20:00", location: "返回市区", desc: "迪士尼专线", icon: "T" },
        { time: "21:00", location: "最后购物", desc: "伴手礼采购", icon: "3" },
        { time: "22:00", location: "返程", desc: "机场/西九龙站出发", icon: "E" }
      ]
    }
  ],
  tips: {
    transport: "推荐八达通卡，地铁+巴士全覆盖，天星小轮游维港必体验",
    transport2: "太平山顶缆车/昂坪360建议提前网购门票",
    accommodation: "尖沙咀/旺角/铜锣湾，交通便利，购物美食方便",
    accommodation2: "海景酒店可选尖沙咀/西九龙，欣赏维港夜景"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" },
    green: { bg: "#98FB98", main: "#228B22", text: "#228B22" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="1100" viewBox="0 0 1400 1100">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 42px; font-weight: bold; }
      .day-title { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 22px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 14px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 16px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 13px; fill: #696969; }
      .tip { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 12px; fill: #8B4513; font-style: italic; }
    </style>
  </defs>
  
  <rect width="1400" height="1100" fill="url(#sky)"/>
  
  <!-- 云朵装饰 -->
  <ellipse cx="150" cy="80" rx="80" ry="40" fill="#fff" opacity="0.8"/>
  <ellipse cx="220" cy="70" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="1100" cy="130" rx="90" ry="45" fill="#fff" opacity="0.7"/>
  <ellipse cx="1180" cy="115" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="700" cy="60" rx="100" ry="50" fill="#fff" opacity="0.6"/>
  <ellipse cx="350" cy="50" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  
  <!-- 草地装饰 -->
  <ellipse cx="0" cy="1100" rx="400" ry="200" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1400" cy="1100" rx="500" ry="220" fill="url(#grass)" opacity="0.7"/>
  
  <!-- 飞鸟装饰 -->
  <path d="M300 120 Q310 110 320 120 Q330 110 340 120" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M1000 90 Q1010 80 1020 90 Q1030 80 1040 90" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M600 100 Q610 90 620 100 Q630 90 640 100" stroke="#2F4F4F" stroke-width="1.5" fill="none"/>
  
  <!-- 星星装饰 -->
  <text x="120" y="150" fill="#FFD700" font-size="18">✦</text>
  <text x="1280" y="160" fill="#FFD700" font-size="18">✦</text>
  
  <!-- 主卡片背景 -->
  <rect x="40" y="170" width="1320" height="880" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <!-- 标题 -->
  <text x="700" y="100" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}4日游 · 宫崎骏风格时间规划</text>
  <text x="700" y="140" text-anchor="middle" font-size="20" fill="#696969">东方之珠 · 梦幻之旅</text>

  <!-- 顶部装饰圆点 -->
  <circle cx="80" cy="200" r="8" fill="#FF69B4"/>
  <circle cx="95" cy="210" r="6" fill="#FFB6C1"/>
  <circle cx="65" cy="215" r="5" fill="#FF69B4"/>
  <circle cx="1320" cy="200" r="8" fill="#87CEFA"/>
  <circle cx="1335" cy="210" r="6" fill="#B0E0E6"/>`;

  const dayWidth = 310;
  const dayHeight = 700;
  const startX = 60;
  const dayY = 220;

  const lineXPositions = [130, 450, 770, 1090];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const x = startX + dayIndex * 345;
    
    svg += `
  <!-- Day ${dayIndex + 1} 卡片 -->
  <rect x="${x}" y="${dayY}" width="${dayWidth}" height="${dayHeight}" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${x}" y="${dayY}" width="${dayWidth}" height="65" fill="${c.main}" rx="15"/>
  <rect x="${x}" y="${dayY + 45}" width="${dayWidth}" height="20" fill="${c.main}"/>
  <text x="${x + 155}" y="${dayY + 38}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${x + 155}" y="${dayY + 60}" text-anchor="middle" font-size="14" fill="#fff">${day.subtitle}</text>
  
  <!-- 时间轴线 -->
  <line x1="${lineXPositions[dayIndex]}" y1="${dayY + 90}" x2="${lineXPositions[dayIndex]}" y2="${dayY + 850}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = dayY + 110 + i * 80;
      const isMeal = item.icon === "B" || item.icon === "S" || item.icon === "Z" || item.icon === "E";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      const iconSize = item.icon.length > 1 ? 8 : 11;
      
      svg += `
  <!-- 行程项 -->
  <circle cx="${lineXPositions[dayIndex]}" cy="${y}" r="24" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${lineXPositions[dayIndex]}" y="${y + 4}" text-anchor="middle" font-size="${iconSize}" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${lineXPositions[dayIndex] + 40}" y="${y - 8}" class="time">${item.time}</text>
  <text x="${lineXPositions[dayIndex] + 40}" y="${y + 12}" class="location">${item.location}</text>
  <text x="${lineXPositions[dayIndex] + 40}" y="${y + 32}" class="desc">${item.desc}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${lineXPositions[dayIndex] + 40}" y="${y + 52}" class="tip">${item.tip}</text>`;
      }
    });
  });

  svg += `
  <!-- 底部提示区域 -->
  <rect x="60" y="950" width="1280" height="100" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="100" y="985" class="location" fill="#228B22">✦ 交通小贴士</text>
  <text x="100" y="1008" class="desc">${data.tips.transport}</text>
  <text x="100" y="1030" class="tip">${data.tips.transport2}</text>
  <text x="750" y="985" class="location" fill="#FF69B4">✦ 住宿推荐</text>
  <text x="750" y="1008" class="desc">${data.tips.accommodation}</text>
  <text x="750" y="1030" class="tip">${data.tips.accommodation2}</text>
  
  <!-- 页脚 -->
  <text x="700" y="1085" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：3-5月 / 9-11月</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(__dirname, 'hongkong-miyazaki.svg');
  const pngPath = path.join(__dirname, '..', 'hongkong-miyazaki.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };