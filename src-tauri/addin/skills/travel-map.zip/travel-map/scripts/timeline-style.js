const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "重庆",
  days: [
    {
      title: "Day 1",
      subtitle: "渝中经典打卡",
      color: "pink",
      schedule: [
        { time: "09:00", location: "重庆站/机场抵达", desc: "轻轨1号线直达市区", icon: "S" },
        { time: "09:30", location: "鹅岭栈桥", desc: "460米悬空飘带桥", tip: "建议9点前到免排队", icon: "1" },
        { time: "11:00", location: "鹅岭二厂文创园", desc: "《从你的全世界路过》取景地", tip: "天台拍照江景绝美", icon: "2" },
        { time: "12:30", location: "午餐：梯坎面", desc: "体验山城板凳面文化", icon: "B" },
        { time: "14:00", location: "山城步道", desc: "从中兴路入口走江边栈道", icon: "3" },
        { time: "18:00", location: "解放碑商圈", desc: "重庆地标+购物美食", icon: "4" },
        { time: "20:00", location: "住宿休息", desc: "推荐解放碑/观音桥附近", icon: "Z" }
      ]
    },
    {
      title: "Day 2",
      subtitle: "魔幻夜景探秘",
      color: "blue",
      schedule: [
        { time: "08:30", location: "长江索道（南站）", desc: "空中俯瞰两江交汇", tip: "提前预约可走快速通道", icon: "1" },
        { time: "10:00", location: "白象居", desc: "老重庆居民楼打卡", tip: "长江索道最佳拍摄点", icon: "2" },
        { time: "12:00", location: "午餐：老火锅", desc: "居民区老火锅更地道", icon: "B" },
        { time: "14:00", location: "湖广会馆", desc: "明清建筑+移民历史", tip: "周三至周五免费参观", icon: "3" },
        { time: "17:00", location: "洪崖洞", desc: "吊脚楼11层梦幻逛吃", tip: "避开18:00-21:00高峰", icon: "4" },
        { time: "19:30", location: "千厮门大桥", desc: "观洪崖洞灯光秀全景", icon: "5" },
        { time: "21:00", location: "两江夜游（可选）", desc: "游船赏山城梦幻夜景", icon: "N" }
      ]
    },
    {
      title: "Day 3",
      subtitle: "历史文化探访",
      color: "purple",
      schedule: [
        { time: "08:30", location: "轻轨1号线出发", desc: "前往磁器口古镇", icon: "T" },
        { time: "09:00", location: "磁器口古镇", desc: "明清古街+巴渝风情", tip: "必买：磁器口麻花", icon: "1" },
        { time: "11:30", location: "白公馆", desc: "红色历史纪念馆", tip: "需提前预约", icon: "2" },
        { time: "13:00", location: "午餐：毛血旺", desc: "磁器口特色江湖菜", icon: "B" },
        { time: "15:00", location: "李子坝轻轨站", desc: "轻轨穿楼8D魔幻", tip: "最佳机位：观景平台", icon: "3" },
        { time: "17:00", location: "观音桥商圈", desc: "重庆新地标+美食", icon: "4" },
        { time: "19:00", location: "返程", desc: "重庆站/机场出发", icon: "E" }
      ]
    }
  ],
  tips: {
    transport: "轻轨为主（15条线），打车注意上下坡费10-20元",
    transport2: "长江索道/洪崖洞需提前在官方公众号预约",
    accommodation: "解放碑/观音桥商圈，地铁方便，别住洪崖洞楼上",
    accommodation2: "南滨路江景房可观梦幻夜景"
  }
};

function generateMiyazakiStyle(data) {
  const colors = {
    pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
    blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
    purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" }
  };

  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="950" viewBox="0 0 1200 950">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="50%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', sans-serif; font-size: 36px; font-weight: bold; }
      .day-title { font-family: 'SimHei', sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', sans-serif; font-size: 14px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', sans-serif; font-size: 16px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', sans-serif; font-size: 13px; fill: #696969; }
      .tip { font-family: 'SimHei', sans-serif; font-size: 12px; fill: #8B4513; font-style: italic; }
    </style>
  </defs>
  
  <rect width="1200" height="950" fill="url(#sky)"/>
  <ellipse cx="150" cy="80" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="200" cy="70" rx="50" ry="25" fill="#fff" opacity="0.8"/>
  <ellipse cx="1000" cy="120" rx="70" ry="35" fill="#fff" opacity="0.7"/>
  <ellipse cx="1060" cy="110" rx="50" ry="25" fill="#fff" opacity="0.7"/>
  <ellipse cx="600" cy="50" rx="80" ry="40" fill="#fff" opacity="0.6"/>
  <ellipse cx="0" cy="950" rx="300" ry="150" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1200" cy="950" rx="400" ry="180" fill="url(#grass)" opacity="0.7"/>
  
  <rect x="30" y="140" width="1140" height="770" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="600" y="90" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}3日游 · 宫崎骏风格时间规划</text>
  <text x="600" y="125" text-anchor="middle" font-size="18" fill="#696969">8D魔幻山城 · 梦幻之旅</text>
  
  <circle cx="80" cy="160" r="8" fill="#FF69B4"/>
  <circle cx="90" cy="170" r="6" fill="#FFB6C1"/>
  <circle cx="70" cy="175" r="5" fill="#FF69B4"/>
  <circle cx="1120" cy="160" r="8" fill="#87CEFA"/>
  <circle cx="1130" cy="170" r="6" fill="#B0E0E6"/>`;

  const dayPositions = [
    { x: 60, y: 180, lineX: 110 },
    { x: 430, y: 180, lineX: 480 },
    { x: 800, y: 180, lineX: 850 }
  ];

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const pos = dayPositions[dayIndex];
    
    svg += `
  <rect x="${pos.x}" y="${pos.y}" width="340" height="620" fill="${c.bg}" rx="15" filter="url(#shadow)"/>
  <rect x="${pos.x}" y="${pos.y}" width="340" height="60" fill="${c.main}" rx="15"/>
  <rect x="${pos.x}" y="${pos.y + 40}" width="340" height="20" fill="${c.main}"/>
  <text x="${pos.x + 170}" y="${pos.y + 35}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${pos.x + 170}" y="${pos.y + 58}" text-anchor="middle" font-size="14" fill="#fff">${day.subtitle}</text>
  
  <line x1="${pos.lineX}" y1="${pos.y + 90}" x2="${pos.lineX}" y2="${pos.y + 770}" stroke="#fff" stroke-width="4" stroke-dasharray="10,5"/>`;

    day.schedule.forEach((item, i) => {
      const y = pos.y + 105 + i * 75;
      const isMeal = item.icon === "B";
      const bgColor = isMeal ? "#FFD700" : "#fff";
      
      svg += `
  <circle cx="${pos.lineX}" cy="${y}" r="22" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${pos.lineX}" y="${y + 5}" text-anchor="middle" font-size="10" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${pos.lineX + 35}" y="${y - 5}" class="time">${item.time}</text>
  <text x="${pos.lineX + 35}" y="${y + 15}" class="location">${item.location}</text>
  <text x="${pos.lineX + 35}" y="${y + 35}" class="desc">${item.desc}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${pos.lineX + 35}" y="${y + 55}" class="tip">${item.tip}</text>`;
      }
    });
  });

  svg += `
  <rect x="60" y="830" width="1080" height="90" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="90" y="860" class="location" fill="#228B22">交通小贴士</text>
  <text x="90" y="880" class="desc">${data.tips.transport}</text>
  <text x="90" y="900" class="tip">${data.tips.transport2}</text>
  <text x="650" y="860" class="location" fill="#FF69B4">住宿推荐</text>
  <text x="650" y="880" class="desc">${data.tips.accommodation}</text>
  <text x="650" y="900" class="tip">${data.tips.accommodation2}</text>
  <text x="600" y="940" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：3-5月 / 9-11月</text>
  <path d="M400 40 Q410 30 420 40 Q430 30 440 40" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M800 70 Q810 60 820 70 Q830 60 840 70" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <text x="120" y="130" fill="#FFD700" font-size="14">*</text>
  <text x="1080" y="130" fill="#FFD700" font-size="14">*</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'chongqing-travel.svg');
  const pngPath = path.join(process.cwd(), 'chongqing-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };