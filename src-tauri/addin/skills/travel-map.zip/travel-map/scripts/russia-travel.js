const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const itinerary = {
  destination: "俄罗斯",
  days: [
    {
      title: "Day 1",
      subtitle: "抵达莫斯科",
      color: "pink",
      schedule: [
        { time: "08:00", location: "北京/上海出发", desc: "直飞莫斯科约8小时", icon: "S" },
        { time: "14:00", location: "莫斯科机场", desc: "机场快线前往市区", icon: "1" },
        { time: "16:00", location: "红场", desc: "漫步俄罗斯心脏", tip: "注意安检要求", icon: "2" },
        { time: "18:00", location: "晚餐：俄式餐厅", desc: "品尝红菜汤+布林饼", icon: "B" },
        { time: "20:00", location: "住宿休息", desc: "推荐特维尔大街附近", icon: "Z" }
      ]
    },
    {
      title: "Day 2",
      subtitle: "克里姆林宫探秘",
      color: "blue",
      schedule: [
        { time: "09:00", location: "克里姆林宫", desc: "世界最大城堡群", tip: "提前购票预约", icon: "1" },
        { time: "11:30", location: "武器库博物馆", desc: "沙皇珍宝收藏", icon: "2" },
        { time: "13:00", location: "午餐：古姆商场", desc: "百年商场美食", icon: "B" },
        { time: "15:00", location: "圣瓦西里大教堂", desc: "洋葱头穹顶绝美", icon: "3" },
        { time: "17:00", location: "亚历山大花园", desc: "无名烈士墓换岗", icon: "4" },
        { time: "19:00", location: "莫斯科地铁站", desc: "地下艺术宫殿", icon: "5" }
      ]
    },
    {
      title: "Day 3",
      subtitle: "莫斯科深度游",
      color: "purple",
      schedule: [
        { time: "09:00", location: "特列季亚科夫画廊", desc: "俄罗斯艺术宝库", icon: "1" },
        { time: "12:00", location: "午餐：老阿尔巴特街", desc: "街头美食+艺术", icon: "B" },
        { time: "14:00", location: "普希金美术馆", desc: "印象派珍藏", icon: "2" },
        { time: "16:00", location: "高尔基公园", desc: "当地人休闲地", icon: "3" },
        { time: "18:00", location: "莫斯科河游船", desc: "夜游莫斯科", icon: "N" }
      ]
    },
    {
      title: "Day 4",
      subtitle: "前往圣彼得堡",
      color: "green",
      schedule: [
        { time: "08:00", location: "莫斯科火车站", desc: "高铁前往圣彼得堡", tip: "4小时车程", icon: "T" },
        { time: "12:30", location: "圣彼得堡抵达", desc: "入住涅瓦大街", icon: "1" },
        { time: "14:00", location: "涅瓦大街", desc: "散步+购物", icon: "2" },
        { time: "16:00", location: "喀山教堂", desc: "东正教宏伟建筑", icon: "3" },
        { time: "18:00", location: "晚餐：俄式大餐", desc: "推荐黑珍珠餐厅", icon: "B" }
      ]
    },
    {
      title: "Day 5",
      subtitle: "冬宫艺术之旅",
      color: "pink",
      schedule: [
        { time: "09:30", location: "冬宫博物馆", desc: "世界四大博物馆", tip: "建议预留4小时", icon: "1" },
        { time: "13:00", location: "园内午餐", desc: "宫廷餐厅体验", icon: "B" },
        { time: "14:30", location: "冬宫广场", desc: "亚历山大柱", icon: "2" },
        { time: "16:00", location: "埃尔米塔日剧院", desc: "皇家剧院参观", icon: "3" }
      ]
    },
    {
      title: "Day 6",
      subtitle: "夏宫与郊区",
      color: "blue",
      schedule: [
        { time: "09:00", location: "彼得夏宫", desc: "俄罗斯凡尔赛", tip: "喷泉表演11点开始", icon: "1" },
        { time: "12:00", location: "上花园午餐", desc: "湖畔餐厅", icon: "B" },
        { time: "13:30", location: "下花园", desc: "喷泉+宫殿", icon: "2" },
        { time: "16:00", location: "返回市区", desc: "游船或巴士", icon: "T" },
        { time: "18:00", location: "马林斯基剧院", desc: "芭蕾舞表演", tip: "需提前订票", icon: "N" }
      ]
    },
    {
      title: "Day 7",
      subtitle: "圣彼得堡精华",
      color: "purple",
      schedule: [
        { time: "09:00", location: "彼得保罗要塞", desc: "城市发源地", icon: "1" },
        { time: "11:00", location: "滴血教堂", desc: "洋葱头艺术", icon: "2" },
        { time: "12:30", location: "午餐：涅瓦河边", desc: "海鲜美食", icon: "B" },
        { time: "14:00", location: "斯莫尔尼宫", desc: "列宁故居", icon: "3" },
        { time: "16:00", location: "尤苏波夫宫", desc: "奢华宫殿", icon: "4" }
      ]
    },
    {
      title: "Day 8",
      subtitle: "飞往贝加尔湖",
      color: "green",
      schedule: [
        { time: "06:00", location: "圣彼得堡机场", desc: "早班飞机前往伊尔库茨克", icon: "S" },
        { time: "12:00", location: "伊尔库茨克", desc: "抵达+午餐", icon: "1" },
        { time: "14:00", location: "前往利斯特维扬卡", desc: "贝加尔湖门户", tip: "约1小时", icon: "T" },
        { time: "16:00", location: "贝加尔湖博物馆", desc: "了解湖底世界", icon: "2" },
        { time: "18:00", location: "湖畔日落", desc: "绝美蓝湖风光", icon: "N" }
      ]
    },
    {
      title: "Day 9",
      subtitle: "贝加尔湖深度",
      color: "pink",
      schedule: [
        { time: "08:00", location: "贝加尔湖冰面", desc: "冬季蓝冰/夏季游船", tip: "6-8月可乘船", icon: "1" },
        { time: "11:00", location: "奥尔洪岛", desc: "最大岛屿+萨满石", icon: "2" },
        { time: "13:00", location: "午餐：渔村", desc: "奥姆利鱼料理", icon: "B" },
        { time: "15:00", location: "萨满岩日落", desc: "最佳观赏点", icon: "3" }
      ]
    },
    {
      title: "Day 10",
      subtitle: "返程回国",
      color: "blue",
      schedule: [
        { time: "09:00", location: "返回伊尔库茨克", desc: "市区观光", icon: "T" },
        { time: "11:00", location: "喀山圣母教堂", desc: "最美东正教堂", icon: "1" },
        { time: "12:30", location: "午餐：市区", desc: "最后俄餐", icon: "B" },
        { time: "14:00", location: "机场返程", desc: "返回中国", icon: "E" }
      ]
    }
  ],
  tips: {
    transport: "莫斯科-圣彼得堡高铁4小时，伊尔库茨克需转机，境内段建议提前购票",
    transport2: "贝加尔湖冬季可看蓝冰（1-3月），夏季可游船（6-8月）",
    accommodation: "莫斯科推荐特维尔大街/红场周边，圣彼得堡推荐涅瓦大街，贝加尔湖住利斯特维扬卡",
    accommodation2: "建议提前1个月预订，旺季价格上浮30%"
  }
};

const colors = {
  pink: { bg: "#FFB6C1", main: "#FF69B4", text: "#FF69B4" },
  blue: { bg: "#87CEFA", main: "#4169E1", text: "#4169E1" },
  purple: { bg: "#DDA0DD", main: "#9370DB", text: "#9370DB" },
  green: { bg: "#98FB98", main: "#228B22", text: "#228B22" }
};

function generateMiyazakiStyle(data) {
  let svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1200" viewBox="0 0 1600 1200">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#87CEEB"/>
      <stop offset="40%" style="stop-color:#B0E0E6"/>
      <stop offset="100%" style="stop-color:#FFFAF0"/>
    </linearGradient>
    <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#90EE90"/>
      <stop offset="100%" style="stop-color:#228B22"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-opacity="0.3"/>
    </filter>
    <style>
      .title { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 42px; font-weight: bold; }
      .day-title { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 20px; font-weight: bold; fill: #fff; }
      .time { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 13px; fill: #FF6B6B; font-weight: bold; }
      .location { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 15px; font-weight: bold; fill: #2F4F4F; }
      .desc { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 12px; fill: #696969; }
      .tip { font-family: 'SimHei', 'Heiti SC', sans-serif; font-size: 11px; fill: #8B4513; font-style: italic; }
    </style>
  </defs>
  
  <rect width="1600" height="1200" fill="url(#sky)"/>
  
  <ellipse cx="150" cy="80" rx="80" ry="40" fill="#fff" opacity="0.8"/>
  <ellipse cx="220" cy="70" rx="60" ry="30" fill="#fff" opacity="0.8"/>
  <ellipse cx="1200" cy="130" rx="90" ry="45" fill="#fff" opacity="0.7"/>
  <ellipse cx="1280" cy="115" rx="60" ry="30" fill="#fff" opacity="0.7"/>
  <ellipse cx="800" cy="60" rx="100" ry="50" fill="#fff" opacity="0.6"/>
  
  <ellipse cx="0" cy="1200" rx="500" ry="250" fill="url(#grass)" opacity="0.8"/>
  <ellipse cx="1600" cy="1200" rx="600" ry="280" fill="url(#grass)" opacity="0.7"/>
  
  <path d="M400 100 Q410 90 420 100 Q430 90 440 100" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  <path d="M1100 80 Q1110 70 1120 80 Q1130 70 1140 80" stroke="#2F4F4F" stroke-width="2" fill="none"/>
  
  <text x="120" y="150" fill="#FFD700" font-size="18">✦</text>
  <text x="1480" y="160" fill="#FFD700" font-size="18">✦</text>
  
  <rect x="40" y="170" width="1520" height="980" fill="#fff" rx="20" opacity="0.95" filter="url(#shadow)"/>
  
  <text x="800" y="100" text-anchor="middle" class="title" fill="#2F4F4F">${data.destination}10日游 · 宫崎骏风格时间规划</text>
  <text x="800" y="140" text-anchor="middle" font-size="20" fill="#696969">穿越欧亚 · 极地蓝湖之旅</text>

  <circle cx="80" cy="200" r="8" fill="#FF69B4"/>
  <circle cx="95" cy="210" r="6" fill="#FFB6C1"/>
  <circle cx="65" cy="215" r="5" fill="#FF69B4"/>
  <circle cx="1520" cy="200" r="8" fill="#87CEFA"/>
  <circle cx="1535" cy="210" r="6" fill="#B0E0E6"/>`;

  const dayWidth = 145;
  const dayHeight = 800;
  const startX = 50;
  const dayY = 230;
  const cols = 5;
  const gap = 10;

  data.days.forEach((day, dayIndex) => {
    const c = colors[day.color];
    const col = dayIndex % cols;
    const row = Math.floor(dayIndex / cols);
    const x = startX + col * (dayWidth + gap);
    const y = dayY + row * 30;
    const lineX = x + 30;
    
    const maxItems = day.schedule.length;
    const cardHeight = Math.max(dayHeight, 80 + maxItems * 75);
    
    svg += `
  <rect x="${x}" y="${y}" width="${dayWidth}" height="${cardHeight}" fill="${c.bg}" rx="12" filter="url(#shadow)"/>
  <rect x="${x}" y="${y}" width="${dayWidth}" height="55" fill="${c.main}" rx="12"/>
  <rect x="${x}" y="${y + 38}" width="${dayWidth}" height="17" fill="${c.main}"/>
  <text x="${x + dayWidth/2}" y="${y + 32}" text-anchor="middle" class="day-title">${day.title}</text>
  <text x="${x + dayWidth/2}" y="${y + 50}" text-anchor="middle" font-size="12" fill="#fff">${day.subtitle}</text>
  
  <line x1="${lineX}" y1="${y + 75}" x2="${lineX}" y2="${y + cardHeight - 20}" stroke="#fff" stroke-width="3" stroke-dasharray="8,4"/>`;

    day.schedule.forEach((item, i) => {
      const itemY = y + 90 + i * 75;
      const isMeal = ["B", "S", "Z", "E", "T"].includes(item.icon);
      const bgColor = isMeal ? "#FFD700" : "#fff";
      
      svg += `
  <circle cx="${lineX}" cy="${itemY}" r="20" fill="${bgColor}" filter="url(#shadow)"/>
  <text x="${lineX}" y="${itemY + 4}" text-anchor="middle" font-size="9" fill="${c.text}" font-weight="bold">${item.icon}</text>
  <text x="${lineX + 30}" y="${itemY - 5}" class="time">${item.time}</text>
  <text x="${lineX + 30}" y="${itemY + 10}" class="location">${item.location}</text>
  <text x="${lineX + 30}" y="${itemY + 28}" class="desc">${item.desc}</text>`;
      
      if (item.tip) {
        svg += `
  <text x="${lineX + 30}" y="${itemY + 46}" class="tip">${item.tip}</text>`;
      }
    });
  });

  svg += `
  <rect x="60" y="1060" width="1480" height="100" fill="#FFFAF0" rx="12" stroke="#DEB887" stroke-width="2"/>
  <text x="100" y="1095" class="location" fill="#228B22">✦ 交通小贴士</text>
  <text x="100" y="1118" class="desc">${data.tips.transport}</text>
  <text x="100" y="1140" class="tip">${data.tips.transport2}</text>
  <text x="800" y="1095" class="location" fill="#FF69B4">✦ 住宿推荐</text>
  <text x="800" y="1118" class="desc">${data.tips.accommodation}</text>
  <text x="800" y="1140" class="tip">${data.tips.accommodation2}</text>
  
  <text x="800" y="1185" text-anchor="middle" fill="#696969" font-size="14">最佳出行季节：夏季6-8月 / 冬季12-2月（蓝冰+极光）</text>
</svg>`;

  return svg;
}

if (require.main === module) {
  const svg = generateMiyazakiStyle(itinerary);
  const svgPath = path.join(process.cwd(), 'russia-travel.svg');
  const pngPath = path.join(process.cwd(), 'russia-travel-map.png');
  
  fs.writeFileSync(svgPath, svg);
  
  sharp(svgPath)
    .png()
    .toFile(pngPath)
    .then(() => console.log('宫崎骏风格行程图已导出:', pngPath))
    .catch(console.error);
}

module.exports = { generateMiyazakiStyle, itinerary };