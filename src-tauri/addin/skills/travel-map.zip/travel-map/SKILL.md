---
name: travel-map
description: 生成精美的旅行规划图片，包含地点+时间+景点推荐。当用户要求画旅行规划图、生成旅游行程图、设计行程时间表、制作旅游攻略图、画旅游地图等时使用此skill。支持两种展现形式：1) 时间轴行程图 2) 地图路线图。支持多种视觉风格如宫崎骏风格、活泼风格等。
---

# 旅行地图生成器

## 概述

此skill用于生成精美的旅行规划图片，包含每日的地点、时间安排、景点推荐和实用提示。使用SVG+sharp方案在Node.js中生成图片。

## 支持的图片类型

### 1. 时间轴行程图
- 每日按时间顺序排列景点
- 包含具体时间和活动安排
- 适合详细规划参考

### 2. 地图路线图
- 在地图上展示景点位置
- 标注景点间的路线连接
- 适合了解景点分布和路线规划

## 视觉风格

- **宫崎骏风格**: 梦幻渐变天空、绿色草地、云朵飞鸟装饰
- **活泼风格**: 明亮配色、圆角卡片、多彩主题

## 工作流

1. 搜索目的地热门景点信息
2. 选择图片类型（时间轴/地图）
3. 设计行程路线
4. 生成SVG并转换为PNG

## 工作流

1. 搜索目的地热门景点信息
2. 设计行程路线（每日安排）
3. 生成SVG时间轴图
4. 使用sharp转换为PNG

## 实现方案

### 依赖安装

```bash
npm install sharp
```

### 基础导出脚本

```javascript
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

function generateTravelMap(data, outputPath) {
  // data包含: 目的地名称、每日行程、景点推荐等
  // 生成SVG字符串
  const svg = generateSvg(data);
  // 写入临时文件
  fs.writeFileSync('temp.svg', svg);
  // 转换为PNG
  return sharp('temp.svg').png().toFile(outputPath);
}
```

### 宫崎骏风格示例

参见 `scripts/chongqing-miyazaki.js` - 重庆3日游行程图

关键设计元素:
- 渐变天空背景 (淡蓝到白色)
- 绿色草地装饰
- 每日使用不同主题色 (粉/蓝/紫)
- 云朵、飞鸟、星星等装饰
- 圆角卡片 + 阴影效果
- 清晰的时间轴布局

## 每日行程结构

```javascript
const itinerary = {
  destination: "重庆",
  days: [
    {
      title: "Day 1 渝中经典",
      color: "pink",
      schedule: [
        { time: "09:00", location: "重庆站/机场", desc: "轻轨1号线直达" },
        { time: "09:30", location: "鹅岭栈桥", desc: "460米悬空飘带桥" },
        // ...
      ]
    },
    // ...
  ],
  tips: {
    transport: "交通提示...",
    accommodation: "住宿推荐..."
  }
};
```

## 生成的图片特点

- 地点+时间双轴布局
- 每小时/每时段一个景点
- 包含景点描述和实用提示
- 底部交通住宿信息
- 支持多种视觉风格

## 相关资源

- 时间轴行程图: scripts/timeline-style.js (宫崎骏风格示例)
- 地图路线图: scripts/map-style.js
- 基础导出函数: scripts/export-excalidraw.js