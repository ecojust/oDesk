---
name: song-movie-generater
description: 使用 Manim 和 FFmpeg 根据歌词时间轴生成卡拉OK风格的动画视频。
---

# Manim 歌词视频生成

根据歌词时间轴文件自动生成同步的卡拉OK动画视频。

## 注意事项

- **small.mp4**: 用户需要手动准备 PIP 视频（300x300），放到项目根目录
- **output/**: 存放中间文件，可通过 `rm -rf output` 清理
- **list/**: 最终输出文件夹，包含 no_pip 和 with_pip 两个子文件夹

## 流程概述

整个流程分为三步：

1. **Step 1: 歌曲视频生成** - 基于歌词、歌曲、封面底图生成同步卡拉OK视频
2. **Step 2: 后处理** - 对生成的歌曲视频添加 PIP（画中画）效果
3. **Step 3: 描述文件生成** - 根据歌词内容生成歌曲简介和标签

# 前提条件：必须先检查并安装必要的依赖库（manim, ffmpeg）。

# 输入文件（自动读取）：

- lyric.txt: 歌词时间轴文件
- music.mp3: 背景音乐文件
- thumb.png: 背景底图（可选）
- small.mp4: 用户提供的 PIP 视频（300x300，需手动准备）
- config.json: 配置

# 配置 (config.json)：

```json
{
  "name": "output",
  "lyric_file": "lyric.txt",
  "music_file": "music.mp3",
  "offset": 0.0,
  "thumb": "thumb.png",
  "pip": {
    "name": "small.mp4",
    "size": {
      "width": 300,
      "height": 300
    },
    "position": {
      "x": 0,
      "y": 0
    }
  }
}
```

## 运行流程

### Step 1: 生成歌曲视频

```bash
python3 scripts/lyric_pipeline.py
```

输出：`{name}.mp4`（如中国人.mp4）

### Step 2: 后处理（PIP）

```bash
python3 scripts/post_process.py
```

输出：`{name}_pip.mp4`（如中国人_pip.mp4）

### Step 3: 生成描述文件

```bash
python3 scripts/gen_description.py
```

输出：`description.txt`（歌曲简介和标签）

## 默认行为

脚本自动从配置文件读取：

- **输出文件名**: `config.["manim-video-voiceover"]["name"]` (默认: `output`)
- **歌词文件**: `config.["manim-video-voiceover"]["lyric_file"]` (默认: `lyric.txt`)
- **音乐文件**: `config.["manim-video-voiceover"]["music_file"]` (默认: `music.mp3`)
- **offset**: `config.["manim-video-voiceover"]["offset"]` (默认: `0.0`)

无需用户指定参数，直接运行：

```bash
python3 scripts/lyric_pipeline.py
```

## lyric.txt 格式

每一行：`[MM:SS.mmm] 歌词文本`

```
[00:23.760] 五千年的风和雨啊 藏了多少梦
[00:28.860] 黄色的脸黑色的眼 不变是笑容
[00:35.290] 八千里山川河岳 像是一首歌
[00:40.820] 不论你来自何方 将去向何处
[00:46.060]
[00:46.980] 一样的泪 一样的痛
```

## 重要规则

### 切片时间严格按时间轴

- **duration = 下一个时间点 - 当前时间点**
- 最后一个切片：`max(0.5, music_dur - 最后歌词开始时间 - 3.0)`（留3秒缓冲）
- 开头自动生成空白视频 (0 到 adjusted_first，adjusted_first = first_start + offset)
- 结尾按音乐时长自动填充空白

### Manim 渲染参数

- 使用 `-qh` 只渲染不打开预览
- 分辨率 1920x1080，60fps

## 开发过程中的问题与解决方案

### 1. FFmpeg 合并路径问题

**问题**: 使用相对路径 `'output/final/intro.mp4'` 导致 concat 失败

```
Error opening input file: No such file or directory
```

**解决**: 使用绝对路径

```python
base = os.path.abspath('.')
with open('output/final/list.txt', 'w') as f:
    f.write(f"file '{base}/output/final/intro.mp4'\n")
```

### 2. 视频合并后时长为0

**问题**: 使用 `-shortest` 参数导致视频被音频截断

```
Output duration (0.00s) != music duration (232.70s)
```

**解决**:

- 不使用 `-shortest` 合并视频片段
- 先合并视频和空白，再用 `-shortest` 合并音乐

```python
# 先扩展视频
subprocess.run(['ffmpeg', '-y', '-i', 'output_lyric.mp4', '-i', 'blank.mp4',
               '-filter_complex', '[0:v][1:v]concat=n=2:v=1[outv]',
               '-map', '[outv]', '-c:v', 'libx264', 'temp_extended.mp4'])
# 再合并音乐
subprocess.run(['ffmpeg', '-y', '-i', 'temp_extended.mp4', '-i', music_file,
               '-c:v', 'copy', '-c:a', 'aac', '-shortest', output_name])
```

### 3. atempo速度调整导致问题

**问题**: 使用 `atempo` 调整音频速度后，`-shortest` 参数会截断视频

**解决**: 不要对歌词TTS音频进行速度调整，让视频按原始时间轴显示即可

### 4. ffprobe返回空值

**问题**: `result.stdout.strip()` 为空时报错 `ValueError: could not convert string to float: ''`

**解决**: 添加默认值

```python
final_dur = float(result.stdout.strip() or 0)
```

### 5. concat filter_complex 失败

**问题**: 直接使用 `-c concat` 合并不同分辨率视频失败

**解决**: 保持所有视频分辨率一致，使用 `-c copy` 或转换编码

### 6. concat需要2个输入文件

**问题**: 合并多个视频时需要有多个 `-i` 参数

**解决**: 用 `-filter_complex` 替代简单的 `-c concat`

## 前提条件

**虚拟环境**：`~/venv`

```bash
# 检查依赖
~/venv/bin/python3 -c "import manim" 2>/dev/null
which ffmpeg
```

## 输出文件

脚本生成以下输出文件，存放在 `list` 文件夹：

1. **list/no_pip/{name}.mp4**: 带背景音乐的完整视频（无PIP版本）
2. **list/with_pip/{name}_pip.mp4**: 带PIP的完整视频（有PIP版本）
3. **output/lyric.mp4**: 中间文件（歌词视频，不含音乐）
4. **description.txt**: 歌曲简介和标签

## offset 参数

用于解决 lyric.mp4 与 music.mp3 音画不同步问题：

- **正 offset**: 增加 intro 时长（adjusted_first = first_start + offset）
- **负 offset**: 减少 intro 时长（裁剪开头）

offset 直接计入 intro.py 的 wait 时间，无需额外 blank 文件。

```json
{
  "manim-video-voiceover": {
    "offset": 1.0
  }
}
```

## 输出规格

- 视频格式：MP4 (H.264)
- 分辨率：1920x1080
- 帧率：60fps
- 音频：AAC 44.1kHz stereo

## thumb 参数

添加背景底图：

```json
{
  "thumb": "thumb.png"
}
```

底图通过 Manim 的 `ImageMobject` 添加，使用 `self.add(bg)` 而非 `self.play(FadeIn(bg))`，确保底图在文字下方。

文字默认靠底部显示：

```python
t = Text("{text}", font_size=48, color=WHITE, width=14).move_to(DOWN * 2.5)
```

## steps 字段

自动记录生成步骤到 config.json：

```json
{
  "steps": [
    {"step": "parse_lyric", "entries": 31, "first_start": 23.76, "music_dur": 232.70},
    {"step": "render_intro", "duration": 23.76, "has_thumb": true},
    {"step": "render_seg0", "text": "...", "duration": 5.10, "has_thumb": true},
    {"step": "merge_segments", "count": 32},
    {"step": "add_blank", "gap": 3.27},
    {"step": "merge_music", "method": "concat_blank"},
    {"step": "final_output", "file": "output.mp4", "duration": 232.67}
  ]
}
```

### 7. FFmpeg concat 时序计算错误 ( timescales 不一致)

**问题**: Manim 输出的视频 timescale 与其他视频不同（90k vs 15360），导致 concat 后视频时长计算错误。

```
# Manim 原始输出
time_base=1/90000, duration=3.25s

# 转换后
time_base=1/15360, duration=23.75s
```

使用 `-c copy` 保持原 timescale，导致最终视频时长 22分钟+ 而非预期的 4分钟。

**解决**: 所有切片统一使用 `-c:v libx264 -preset ultrafast -pix_fmt yuv420p` 重新编码，确保 timescale 一致。

```python
# 错误做法 - 保持原 timescale
subprocess.run(['ffmpeg', '-y', '-i', manim_out, '-c:v', 'copy', 
                '-video_track_timescale', '15360', out_file])

# 正确做法 - 重新编码统一 timescale
subprocess.run(['ffmpeg', '-y', '-i', manim_out, '-c:v', 'libx264', 
                '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', out_file])
```

同样适用于 blank 视频和 concat 合并步骤。

### 8. 结尾 Blank 不需要动画

**问题**: 最后填充的 blank 视频是最后一个歌词切片的延续，不需要文字动画。

**解决**: Blank 视频只使用 `self.wait(gap)`，如果有 thumb 底图也用 `self.add(bg)` 而非 `self.play(FadeIn(bg))`。

## 注意事项

### 1. 配置文件格式

config.json 顶层字段直接配置，不需要嵌套：

```json
{
  "name": "output",
  "lyric_file": "lyric.txt",
  "music_file": "music.mp3",
  "offset": 1.0,
  "thumb": "thumb.png"
}
```

### 2. 虚拟环境路径

当前脚本使用硬编码路径 `/Users/juzisang/venv/bin/python3`，如需修改请编辑 `lyric_pipeline.py` 开头：

```python
PY = '/Users/juzisang/venv/bin/python3'
```

### 3. Manim 缓存

每次运行使用 `--flush_cache` 强制重新渲染，避免缓存导致切片时长不正确。

### 4. 临时文件

Manim 会在 `media/videos/` 目录生成大量临时视频文件，可手动清理：

```bash
rm -rf media/videos/
```

### 5. 输出文件清理

脚本会清理中间文件 `lyric_raw.mp4`、`lyric_extended.mp4`，但保留 `output/video/` 和 `output/final/` 切片目录。

### 6. 自动清理

lyric_pipeline.py 每次运行会自动清空 `output/video` 和 `output/final` 文件夹。

## 后处理脚本 (post_process.py)

独立的 PIP 后处理脚本，用于将小视频叠加到主视频左上角。

### 配置参数

通过 config.json 中的 `pip` 字段配置：

```json
{
  "pip": {
    "name": "small.mp4",
    "size": {
      "width": 300,
      "height": 300
    },
    "position": {
      "x": 0,
      "y": 0
    }
  }
}
```

- **name**: PIP 视频文件名
- **size.width/height**: 缩放后的宽高
- **position.x/y**: 相对于左上角的像素位置

### 使用方式

```bash
python3 scripts/post_process.py
```

### 输出

生成 `{name}_pip.mp4` 文件，其中 PIP 视频被缩放并叠加到主视频左上角。

## 描述文件生成

根据歌词内容自动生成歌曲描述文件 `description.txt`，包含简介和标签。

### 生成脚本 (gen_description.py)

```bash
python3 scripts/gen_description.py
```

### description.txt 格式

```markdown
# 歌曲简介

[根据歌词内容生成的歌曲介绍]

# 标签

[标签1], [标签2], ...
```

### 生成规则

1. **简介**: 基于歌词内容，分析歌曲的主题、情感、意象，写成一段介绍文字
2. **标签**: 根据歌曲类型、风格、主题提取相关标签（5-10个）
