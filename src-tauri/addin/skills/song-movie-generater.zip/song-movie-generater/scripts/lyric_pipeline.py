#!/usr/bin/env python3
import re
import os
import json
import shutil
import subprocess
from pathlib import Path

PY = '/Users/juzisang/venv/bin/python3'

def parse_lyric_file(filepath):
    entries = []
    lines = open(filepath, 'r', encoding='utf-8').readlines()
    for line in lines:
        match = re.match(r'\[(\d+):(\d+)\.(\d+)\]\s*(.*)', line)
        if match:
            m, s, ms = int(match.group(1)), int(match.group(2)), int(match.group(3))
            start = m*60 + s + ms/1000
            text = match.group(4).strip()
            entries.append({'start': start, 'text': text})
    return entries

def load_config():
    config_path = Path('config.json')
    if config_path.exists():
        with open(config_path) as f:
            return json.load(f)
    return {}

def update_steps(steps):
    config_path = Path('config.json')
    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
        config['steps'] = steps
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

def clean_output():
    import shutil
    for d in ['output']:
        if os.path.exists(d):
            shutil.rmtree(d)
    for f in ['lyric_raw.mp4', 'lyric_extended.mp4', 'lyric.mp4']:
        if os.path.exists(f):
            os.remove(f)

def main():
    clean_output()
    config = load_config()
    lyric_file = config.get('lyric_file', 'lyric.txt')
    music_file = config.get('music_file', 'music.mp3')
    output_name = config.get('name', 'output.mp4')
    offset = config.get('offset', 0.0)
    thumb_file = config.get('thumb', None)
    mix_file = config.get('mix', None)
    
    if mix_file and not os.path.isabs(mix_file):
        mix_path = Path('mixes') / f'{mix_file}.mov'
        if mix_path.exists():
            mix_file = str(mix_path)
        elif not os.path.exists(mix_file):
            mix_file = None
    
    if mix_file:
        print(f'Mix: {mix_file}')
    if not output_name.endswith('.mp4'):
        output_name += '.mp4'
    
    if not os.path.exists(lyric_file):
        print(f'Error: {lyric_file} not found')
        return
    
    entries = parse_lyric_file(lyric_file)
    if not entries:
        print('Error: No lyric entries')
        return
    
    first_start = entries[0]['start']
    adjusted_first = max(0, first_start + offset)
    music_dur = 0
    if os.path.exists(music_file):
        result = subprocess.run(['ffprobe', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', music_file], capture_output=True, text=True)
        music_dur = float(result.stdout.strip() or 0)
    
    print(f'Lyrics: {len(entries)} lines, first at {first_start:.2f}s')
    if music_dur:
        print(f'Music: {music_dur:.2f}s')
    print(f'Offset: {offset:.2f}s')
    if thumb_file:
        print(f'Thumb: {thumb_file}')
    
    steps = [{'step': 'parse_lyric', 'entries': len(entries), 'first_start': first_start, 'music_dur': music_dur}]
    update_steps(steps)
    
    os.makedirs('output/video', exist_ok=True)
    os.makedirs('output/final', exist_ok=True)
    
    def make_scene_code(duration, text, thumb=None):
        thumb_path = os.path.abspath(thumb).replace('\\', '\\\\') if thumb else None
        if text:
            if thumb_path:
                return f'''from manim import *

config.background_color = BLACK

class Seg(Scene):
    def construct(self):
        bg = ImageMobject(r"{thumb_path}").scale_to_fit_height(config.frame_height).move_to(ORIGIN)
        self.add(bg)
        t = Text("{text}", font_size=48, color=WHITE, width=14).move_to(DOWN * 2.5)
        self.play(Write(t), run_time=min(1.5, {duration}*0.5))
        self.wait(max(0.5, {duration}-1.5))
'''
            else:
                return f'''from manim import *

class Seg(Scene):
    def construct(self):
        t = Text("{text}", font_size=48, color=WHITE, width=14).move_to(DOWN * 2.5)
        self.play(Write(t), run_time=min(1.5, {duration}*0.5))
        self.wait(max(0.5, {duration}-1.5))
'''
        else:
            if thumb_path:
                return f'''from manim import *

config.background_color = BLACK

class Seg(Scene):
    def construct(self):
        bg = ImageMobject(r"{thumb_path}").scale_to_fit_height(config.frame_height).move_to(ORIGIN)
        self.add(bg)
        self.wait({duration})
'''
            else:
                return f'''from manim import *

class Seg(Scene):
    def construct(self):
        self.wait({duration})
'''
    
    if adjusted_first > 0:
        print(f'Intro: 0-{adjusted_first:.2f}s')
        if thumb_file:
            thumb_path = os.path.abspath(thumb_file).replace('\\', '\\\\')
            intro_code = f'''from manim import *

config.background_color = BLACK

class Intro(Scene):
    def construct(self):
        bg = ImageMobject(r"{thumb_path}").scale_to_fit_height(config.frame_height).move_to(ORIGIN)
        self.add(bg)
        self.wait({adjusted_first})
'''
        else:
            intro_code = f'from manim import *\n\nclass Intro(Scene):\n    def construct(self):\n        self.wait({adjusted_first})\n'
        with open('output/video/intro.py', 'w') as f:
            f.write(intro_code)
        subprocess.run([PY, '-m', 'manim', 'render', '-qh', '--flush_cache', 'output/video/intro.py', 'Intro'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        manim_out = 'media/videos/intro/1080p60/Intro.mp4'
        if os.path.exists(manim_out):
            subprocess.run(['ffmpeg', '-y', '-i', manim_out, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', 'output/final/intro.mp4'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        steps.append({'step': 'render_intro', 'duration': adjusted_first, 'has_thumb': bool(thumb_file)})
    
    for i, e in enumerate(entries):
        start, text = e['start'], e['text']
        if i < len(entries)-1:
            duration = entries[i+1]['start'] - start
        else:
            duration = max(0.5, music_dur - start - 3.0)
        
        py_file = f'output/video/seg{i}.py'
        out_file = f'output/final/seg{i}.mp4'
        
        content = make_scene_code(duration, text, thumb_file)
        
        with open(py_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        subprocess.run([PY, '-m', 'manim', 'render', '-qh', '--flush_cache', py_file, 'Seg'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        manim_out = f'media/videos/seg{i}/1080p60/Seg.mp4'
        if os.path.exists(manim_out):
            subprocess.run(['ffmpeg', '-y', '-i', manim_out, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', out_file], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        steps.append({'step': f'render_seg{i}', 'text': text[:20] if text else '', 'duration': duration, 'has_thumb': bool(thumb_file)})
        print(f'seg{i}: {duration:.2f}s')
    
    print('Merging...')
    with open('output/final/list.txt', 'w') as f:
        p = os.path.abspath('.')
        if first_start > 0:
            f.write(f"file '{p}/output/final/intro.mp4'\n")
        for i in range(len(entries)):
            f.write(f"file '{p}/output/final/seg{i}.mp4'\n")
    
    subprocess.run(['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', 'output/final/list.txt', '-c', 'copy', 'lyric_raw.mp4'], capture_output=True)
    steps.append({'step': 'merge_segments', 'count': len(entries) + (1 if first_start > 0 else 0)})
    
    if offset != 0:
        print(f'Offset applied to intro: {offset:.2f}s')
        steps.append({'step': 'apply_offset', 'offset': offset})
    
    os.replace('lyric_raw.mp4', 'lyric.mp4')
    
    if music_dur > 0:
        r = subprocess.run(['ffprobe', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', 'lyric.mp4'], capture_output=True, text=True)
        lyric_dur = float(r.stdout.strip() or 0)
        
        if music_dur > lyric_dur:
            gap = music_dur - lyric_dur
            print(f'Blank: {gap:.2f}s')
            steps.append({'step': 'add_blank', 'gap': gap})
            
            if thumb_file:
                thumb_path = os.path.abspath(thumb_file).replace('\\', '\\\\')
                blank_code = f'''from manim import *

config.background_color = BLACK

class Blank(Scene):
    def construct(self):
        bg = ImageMobject(r"{thumb_path}").scale_to_fit_height(config.frame_height).move_to(ORIGIN)
        self.add(bg)
        self.wait({gap})
'''
            else:
                blank_code = f'from manim import *\n\nclass Blank(Scene):\n    def construct(self):\n        self.wait({gap})\n'
            
            with open('output/video/blank.py', 'w') as f:
                f.write(blank_code)
            subprocess.run([PY, '-m', 'manim', 'render', '-qh', 'output/video/blank.py', 'Blank'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            blank_out = 'media/videos/blank/1080p60/Blank.mp4'
            result = subprocess.run(['ffmpeg', '-y', '-i', blank_out, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', 'output/final/blank.mp4'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            base = os.path.abspath('.')
            with open('output/final/list_extend.txt', 'w') as f:
                f.write(f"file '{base}/lyric.mp4'\n")
                f.write(f"file '{base}/output/final/blank.mp4'\n")
            
            result = subprocess.run(['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', 'output/final/list_extend.txt', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', 'lyric_extended.mp4'], capture_output=True, text=True)
            print(f'concat result: {result.returncode}')
            
            subprocess.run(['ffmpeg', '-y', '-i', 'lyric_extended.mp4', '-i', music_file, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-shortest', output_name], capture_output=True)
            steps.append({'step': 'merge_music', 'method': 'concat_blank'})
        else:
            subprocess.run(['ffmpeg', '-y', '-i', 'lyric.mp4', '-i', music_file, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-shortest', output_name], capture_output=True)
            steps.append({'step': 'merge_music', 'method': 'direct'})
    else:
        subprocess.run(['ffmpeg', '-y', '-i', 'lyric.mp4', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', output_name], capture_output=True)
        steps.append({'step': 'export_video', 'no_audio': True})
    
    if mix_file:
        print(f'Applying mix: {mix_file}')
        steps.append({'step': 'apply_mix', 'file': mix_file})
        result = subprocess.run(['ffprobe', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', output_name], capture_output=True, text=True)
        mix_dur = float(result.stdout.strip() or 0)
        
        result = subprocess.run(['ffmpeg', '-y', '-stream_loop', '-1', '-i', mix_file, '-t', str(mix_dur), '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuva420p', 'temp_mix.mp4'], capture_output=True, text=True)
        print(f'mix loop result: {result.returncode}')
        if result.returncode != 0:
            print(f'mix loop error: {result.stderr}')
        
        if os.path.exists('temp_mix.mp4'):
            result = subprocess.run(['ffmpeg', '-y', '-i', output_name, '-i', 'temp_mix.mp4', '-filter_complex', '[1:v]format=rgba,colorchannelmixer=aa=0.5[fg];[0:v][fg]overlay=0:0', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', 'temp_final.mp4'], capture_output=True, text=True)
            print(f'overlay result: {result.returncode}')
            if result.returncode != 0:
                print(f'overlay error: {result.stderr[:500]}')
            if os.path.exists('temp_final.mp4'):
                os.replace('temp_final.mp4', output_name)
                os.remove('temp_mix.mp4')
        steps.append({'step': 'mix_applied', 'duration': mix_dur})
    
    for f in ['lyric_raw.mp4', 'lyric_extended.mp4']:
        if os.path.exists(f):
            os.remove(f)
    
    if os.path.exists('lyric.mp4'):
        Path('output').mkdir(exist_ok=True)
        shutil.move('lyric.mp4', 'output/lyric.mp4')
    
    if os.path.exists(output_name):
        result = subprocess.run(['ffprobe', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', output_name], capture_output=True, text=True)
        final_dur = float(result.stdout.strip() or 0)
        steps.append({'step': 'final_output', 'file': output_name, 'duration': final_dur})

        list_dir = Path('list')
        no_pip_dir = list_dir / 'no_pip'
        no_pip_dir.mkdir(parents=True, exist_ok=True)
        dest = no_pip_dir / output_name
        if os.path.exists(output_name):
            shutil.copy2(output_name, dest)
            print(f'Copied to list/no_pip/{output_name}')
            steps.append({'step': 'saved_to_list', 'file': str(dest)})

        update_steps(steps)

if __name__ == '__main__':
    main()