from manim import *
import json
import os

song_name = "中国人"
if os.path.exists("/Users/juzisang/Library/Application Support/oDesk/workspaces/test/config.json"):
    with open("/Users/juzisang/Library/Application Support/oDesk/workspaces/test/config.json") as f:
        cfg = json.load(f)
        song_name = cfg.get("name", song_name)

config.pixel_height = 300
config.pixel_width = 300
config.frame_rate = 60

class Vinyl(Scene):
    def construct(self):
        config.background_color = "#1a1a2e"

        title = Text(song_name, font_size=40, color=WHITE)
        title.to_edge(DOWN, buff=0.5)
        self.add(title)

        play_btn = Circle(radius=0.5, color=WHITE, fill_opacity=1)
        play_btn.set_fill(BLUE)
        play_btn.move_to(UP * 0.3)
        self.add(play_btn)

        tri = Polygon([-0.2, 0.25, 0], [0.2, 0.35, 0], [-0.2, -0.25, 0])
        tri.set_fill(WHITE)
        tri.move_to(UP * 0.3 + LEFT * 0.05)
        self.add(tri)

        note = Text("🎵", font_size=80)
        note.next_to(title, UP, buff=0.2)
        self.add(note)

        bars = VGroup()
        for i in range(5):
            bar = Rectangle(width=0.08, height=0.4, color=BLUE_E)
            bar.move_to((-0.2 + i * 0.1) * RIGHT + DOWN * 0.8)
            bars.add(bar)
        self.add(bars)

        self.play(bars[0].animate.set_height(0.6), run_time=0.2)
        self.play(bars[1].animate.set_height(0.3), run_time=0.2)
        self.play(bars[2].animate.set_height(0.5), run_time=0.2)
        self.play(bars[3].animate.set_height(0.4), run_time=0.2)
        self.play(bars[4].animate.set_height(0.2), run_time=0.2)

        self.wait(9)