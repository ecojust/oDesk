#!/usr/bin/env python3
import json
import os
from pathlib import Path

def parse_lyric():
    lyrics = []
    with open('lyric.txt') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if ']' in line:
                parts = line.split(']', 1)
                if len(parts) == 2:
                    text = parts[1].strip()
                    if text:
                        lyrics.append(text)
    return lyrics

def generate_description(lyrics):
    all_text = ' '.join(lyrics)

    name = "中国人"
    if Path('config.json').exists():
        with open('config.json') as f:
            cfg = json.load(f)
            name = cfg.get('name', name)

    all_join = ' '.join(lyrics)
    theme = "爱情"
    if "中国人" in all_text or "祖国" in all_text or "民族" in all_text:
        theme = "爱国主义情怀"
    elif "暗里着迷" in all_join or "暗里爱你" in all_join:
        theme = "暗恋单恋"
    elif "暗" in all_text and "爱" in all_text:
        theme = "暗恋单恋"
    elif "梦" in all_text and ("千" in all_text or "追" in all_text):
        theme = "追逐梦想"
    elif "乡" in all_text:
        theme = "思乡之情"
    elif "道别" in all_text or "别离" in all_text:
        theme = "离别思念"

    if theme == "爱国主义情怀":
        intro = f"""《{name}》是一首充满爱国主义情怀的经典华语歌曲，以恢弘大气的旋律和真挚深沉的歌词，表达了中华儿女对祖国的热爱与自豪。

歌曲以"{lyrics[0]}"开篇，描绘了中华民族悠久的历史文化。"""

        if "一样" in all_text:
            intro += "歌词强调了民族团结的力量。"
        if "手牵" in all_text:
            intro += "彰显了民族团结、共同奋进的精神。"
    elif theme == "暗恋单恋":
        intro = f"""《{name}》是一首经典华语抒情歌曲，以低沉温柔的旋律和细腻真挚的歌词，描绘了暗恋者内心深处的情感纠结。

歌曲以"{lyrics[0]}"开篇，表达了爱慕者徘徊在心仪对象身边的复杂心情。"""
        
        if "寂寞" in all_text or "无尽" in all_text:
            intro += "歌词中'寂寞难耐'、'无尽叹谓'道出了单恋的苦涩与无奈。"
        if "暗里" in all_text or "暗" in all_text:
            intro += "'唯在暗里爱你'、'暗里着迷'点明了这场不为人知的暗恋主题。"
        if "梦" in all_text:
            intro += "在梦境内若有似无的吻，进一步渲染了这种得不到的情感。"
        
        intro += f"\n\n这首歌唱出了无数人心中那些无法说出口的爱意，是暗恋者的内心独白。"
    else:
        intro = f"""《{name}》是一首经典华语歌曲。

歌曲以"{lyrics[0]}"开篇。"""

    if theme == "爱国主义情怀":
        intro += f"\n\n这首歌不仅是對中华文明的赞歌，更是激励中华儿女团结奋进、昂首向前的精神号角。"

    tags = ["华语歌", "经典老歌", "正能量"]
    if theme == "爱国主义情怀":
        tags.extend(["爱国歌曲", "民族团结", "祖国赞歌", "主旋律", "红色歌曲"])
    elif theme == "暗恋单恋":
        tags.extend(["暗恋情歌", "单恋", "抒情", "伤感"])
    elif theme == "离别思念":
        tags.extend(["离别", "伤感", "抒情"])
    tags.extend(["中国风", "中文歌曲"])

    return intro, tags

def main():
    lyrics = parse_lyric()
    intro, tags = generate_description(lyrics)

    with open('description.txt', 'w', encoding='utf-8') as f:
        f.write("# 歌曲简介\n\n")
        f.write(intro)
        f.write("\n\n# 标签\n\n")
        f.write(", ".join(tags))

    print(f"Generated description.txt with {len(lyrics)} lines")

if __name__ == '__main__':
    main()