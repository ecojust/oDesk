#!/usr/bin/env python3
import os
import shutil
import subprocess
import json
from pathlib import Path

def main():
    config = {}
    if Path('config.json').exists():
        with open('config.json') as f:
            config = json.load(f)

    main_video = config.get('name', '中国人') + '.mp4'
    output = config.get('name', '中国人') + '_pip.mp4'

    pip_config = config.get('pip')
    if not pip_config:
        print('No pip config found')
        return

    pip_video = pip_config.get('name', 'small.mp4')
    pip_width = pip_config.get('size', {}).get('width', 300)
    pip_height = pip_config.get('size', {}).get('height', 300)
    pip_x = pip_config.get('position', {}).get('x', 10)
    pip_y = pip_config.get('position', {}).get('y', 10)

    if not main_video.endswith('.mp4'):
        main_video += '.mp4'
    if not pip_video.endswith('.mp4'):
        pip_video += '.mp4'
    if not output.endswith('.mp4'):
        output += '.mp4'

    if not os.path.exists(main_video):
        print(f'Error: {main_video} not found')
        return

    if not os.path.exists(pip_video):
        print(f'Error: {pip_video} not found')
        return

    result = subprocess.run([
        'ffprobe', '-v', 'error', '-show_entries', 'stream=width,height',
        '-of', 'csv=p=0', pip_video
    ], capture_output=True, text=True)
    lines = result.stdout.strip().split('\n')
    w, h = 320, 180
    for line in lines:
        if line:
            parts = line.split(',')
            if len(parts) == 2:
                w, h = int(parts[0]), int(parts[1])
                break

    print(f'Main: {main_video}')
    print(f'PIP: {pip_video} ({pip_width}x{pip_height}) @ ({pip_x},{pip_y})')
    print(f'Output: {output}')

    subprocess.run([
        'ffmpeg', '-y', '-i', main_video, '-i', pip_video,
        '-filter_complex', f'[1:v]scale={pip_width}:{pip_height}[pip];[0:v][pip]overlay={pip_x}:{pip_y}',
        '-c:a', 'copy', output
    ])

    result = subprocess.run([
        'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1', output
    ], capture_output=True, text=True)
    dur = result.stdout.strip()
    print(f'Duration: {dur}s')

    if os.path.exists(output):
        list_dir = Path('list')
        with_pip_dir = list_dir / 'with_pip'
        with_pip_dir.mkdir(parents=True, exist_ok=True)
        dest = with_pip_dir / output
        shutil.copy2(output, dest)
        print(f'Copied to list/with_pip/{output}')

if __name__ == '__main__':
    main()