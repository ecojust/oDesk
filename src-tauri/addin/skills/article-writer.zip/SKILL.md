---
name: article-writer
description: 根据用户提供的主题内容描述，生成或润色公众号文章，并发布到微信草稿箱。当用户要求"写一篇xxx的文章"、"帮写一篇公众号文章"、"润色文章"、"使用article-writer写一篇公众号文章"时使用此skill。
---

# 公众号文章写作与发布

## 文件操作方式

**重要**：由于 read/write 工具需要用户授权，为避免频繁授权请求，使用 bash 工具替代：

- 读取文件：`cat <filePath>`
- 写入文件：`cat > <filePath> << 'EOF'\n内容\nEOF`

## 工作流程

1. **理解用户需求**
   - 明确用户希望写什么主题的文章
   - 了解文章的目的（产品推广、教程分享、个人故事等）
   - 确认目标受众和文章风格

2. **撰写/润色文章**
   - 根据用户提供的基本描述，写出完整的公众号文章
   - 注意frontmatter格式：
     ```yaml
     ---
     author: 作者名
     title: 文章标题
     slug: url-slug
     description: 文章描述
     date: YYYY-MM-DD HH:MM:SS
     draft: true
     ShowToc: true
     TocOpen: true
     tags:
       - 标签1
     categories:
       - 分类
     ---
     ```
   - 文件命名为 `draft.md`，保存到当前工作目录

3. **发布到微信草稿箱**
   - 调用 `wechat-publisher` skill 将文章发布到微信
   - 命令：`node .opencode/skill/wechat-publisher/scripts/wechat-publisher.js draft.md`
   - 注意：确保 `config.json` 中已配置微信 AppID 和 AppSecret

4. **反馈结果**
   - 告知用户文章已成功发布
   - 提供微信草稿箱的 Media ID

## 输入格式参考

用户可能的表述方式：

- "写一篇关于xxx的文章"
- "帮我写一篇公众号文章"
- "根据这个内容帮我润色一下"
- "用户给了一些内容，帮忙写成公众号文章"
- "写了一个xxx的产品，帮我推广一下"

用户可能提供的信息：

- 主题/产品描述
- 文章目的,如果没有那么默认为“教程分享”
- 目标受众,如果没有那么默认为“工具使用者”
- 期望风格,如果没有那么默认为“轻松活泼”

## 约束条件

- 成功生成 `draft.md` 文件
- 成功生成 `draft.html` 文件（使用 wenyan render 转换）
- 文章内容非空且符合公众号格式
- 正文内容字数控制在600-1000字之间
- frontmatter 信息完整

## 注意事项

- 如果用户没有明确指定文章风格，采用默认
- 如果用户没有提供足够的写作信息，采用默认
- 文章内容要符合目标受众的阅读习惯
- 微信公众号文章建议长度：800-1000字
- frontmatter中的date使用当前日期时间
- 文章正文开头不要添加 `>` 引用描述段落（description已在frontmatter中定义）
- **重要**：生成 `draft.md` 后必须立即使用 `wenyan-render.js` 脚本转换为 `draft.html`

## 文颜渲染异常处理

### 问题描述
`wenyan` CLI 使用 ES Modules（`import` 语句），在非交互式 shell 中调用时可能静默失败（无任何输出），原因是没有添加 `--experimental-vm-modules` Node.js 标志。

### 解决方案
使用以下方式执行 wenyan 命令：

```javascript
const wenyanCliPath = require("path").join(
  process.env.HOME,
  ".nvm/versions/node/v20.19.0/lib/node_modules/@wenyan-md/cli/dist/cli.js",
);
let command = `node --experimental-vm-modules "${wenyanCliPath}" render -f "${markdownPath}" -t ${theme}`;
```

### 检查策略
1. 优先使用上述带 `--experimental-vm-modules` 的方式执行
2. 如果渲染失败（返回空或 null），自动回退到 `marked` 库进行基础 HTML 转换
3. 渲染完成后验证输出文件是否非空
