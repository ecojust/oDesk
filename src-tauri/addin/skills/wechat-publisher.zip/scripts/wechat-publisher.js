#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const { URL } = require("url");
const crypto = require("crypto");
const { execSync } = require("child_process");
const os = require("os");
const sharp = require("sharp");

const API_BASE_URL = "https://api.weixin.qq.com";
const TOKEN_CACHE_FILE = ".token_cache.json";
const WENYAN_THEMES = [
  "default",
  "orangeheart",
  "rainbow",
  "lapis",
  "pie",
  "maize",
  "purple",
  "phycat",
];

let config = null;

function loadConfigFile() {
  if (config) return config;
  const configPaths = [
    process.cwd() + "/config.json",
    path.join(__dirname, "config.json"),
    path.join(path.dirname(__dirname), "config.json"),
    path.join(__dirname, "../config.json"),
  ];
  for (const configPath of configPaths) {
    if (fs.existsSync(configPath)) {
      try {
        config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        return config;
      } catch (e) {
        console.error(
          `Warning: 配置文件解析失败 - ${configPath}: ${e.message}`,
        );
      }
    }
  }
  console.error("Error: 未找到配置文件 config.json");
  process.exit(1);
}

function getCredentials() {
  const cfg = loadConfigFile();
  const appid = cfg.wechat?.appid;
  const appsecret = cfg.wechat?.appsecret;
  if (!appid || !appsecret) {
    console.error("Error: 微信凭证未配置");
    process.exit(1);
  }
  return [appid, appsecret];
}

function getTokenCachePath() {
  return path.join(path.dirname(__filename), TOKEN_CACHE_FILE);
}

function loadCachedToken() {
  const cachePath = getTokenCachePath();
  if (!fs.existsSync(cachePath)) return null;
  try {
    const data = JSON.parse(fs.readFileSync(cachePath, "utf-8"));
    if (data.expire_time > Date.now() / 1000 + 300) return data;
  } catch (e) {}
  return null;
}

function saveTokenCache(accessToken, expiresIn) {
  const cachePath = getTokenCachePath();
  fs.writeFileSync(
    cachePath,
    JSON.stringify(
      {
        access_token: accessToken,
        expire_time: Date.now() / 1000 + expiresIn,
        created_at: new Date().toLocaleString("zh-CN"),
      },
      null,
      2,
    ),
    "utf-8",
  );
}

function httpRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === "https:" ? https : http;
    const req = client.request(
      {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
        path: parsedUrl.pathname + parsedUrl.search,
        method: options.method || "GET",
        headers: options.headers || {},
        timeout: options.timeout || 30000,
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          if (res.statusCode >= 400) {
            const err = new Error(`HTTP ${res.statusCode}`);
            err.code = res.statusCode;
            reject(err);
            return;
          }
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve(data);
          }
        });
      },
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Request timeout"));
    });
    if (options.body) req.write(options.body);
    req.end();
  });
}

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const client = url.startsWith("https") ? https : http;
    client
      .get(url, (res) => {
        if (
          res.statusCode >= 300 &&
          res.statusCode < 400 &&
          res.headers.location
        ) {
          file.close();
          downloadFile(res.headers.location, destPath)
            .then(resolve)
            .catch(reject);
          return;
        }
        res.pipe(file);
        file.on("finish", () => {
          file.close();
          resolve();
        });
      })
      .on("error", (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });
  });
}

async function generateCoverImage(title, destPath) {
  const prompt = `${title}, minimalist flat design, clean background, suitable for article cover, no text`;
  const encodedPrompt = encodeURIComponent(prompt);
  const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=600&height=800&nologo=true&safe=true`;
  const tempPath = path.join(os.tmpdir(), `temp_cover_${Date.now()}.png`);
  try {
    await downloadFile(imageUrl, tempPath);
    await sharp(tempPath).png().toFile(destPath);
  } catch (e) {
    console.log("Pollinations 服务不可用，使用 SVG 封面...");
    const fontSize = Math.max(24, Math.min(48, 60 - title.length * 1.5));
    const svg = `<svg width="600" height="800" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#1a1a2e"/>
          <stop offset="100%" style="stop-color:#16213e"/>
        </linearGradient>
      </defs>
      <rect width="600" height="800" fill="url(#bg)"/>
      <text x="50%" y="45%" text-anchor="middle" dominant-baseline="middle" 
            font-family="system-ui, -apple-system, sans-serif" font-size="${fontSize}px" 
            font-weight="bold" fill="#ffffff">
        ${title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}
      </text>
      <text x="50%" y="55%" text-anchor="middle" dominant-baseline="middle" 
            font-family="system-ui, -apple-system, sans-serif" font-size="16px" 
            fill="#888888">微信公众号文章</text>
    </svg>`;
    await sharp(Buffer.from(svg)).png().toFile(destPath);
  } finally {
    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
  }
}

async function getAccessToken() {
  const cached = loadCachedToken();
  if (cached) {
    console.log("✓ 使用缓存的 access_token");
    return cached.access_token;
  }
  const [appid, appsecret] = getCredentials();
  try {
    const data = await httpRequest(
      `${API_BASE_URL}/cgi-bin/token?grant_type=client_credential&appid=${appid}&secret=${appsecret}`,
    );
    if (data.errcode && data.errcode !== 0) {
      console.error(`Error: 获取 access_token 失败: ${data.errmsg}`);
      if (data.errcode === 40164) console.error("提示: IP 未在白名单中");
      process.exit(1);
    }
    saveTokenCache(data.access_token, data.expires_in || 7200);
    console.log(
      `✓ 成功获取 access_token (有效期 ${Math.floor((data.expires_in || 7200) / 60)} 分钟)`,
    );
    return data.access_token;
  } catch (e) {
    console.error(`Error: 网络错误 - ${e.message}`);
    process.exit(1);
  }
}

function createMultipartFormdata(filePath) {
  const boundary = `----WebKitFormBoundary${crypto.randomBytes(8).toString("hex")}`;
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
  };
  const mimeType = mimeTypes[ext] || "image/jpeg";
  const fileData = fs.readFileSync(filePath);
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\n`),
    Buffer.from(
      `Content-Disposition: form-data; name="media"; filename="${path.basename(filePath)}"\r\n`,
    ),
    Buffer.from(`Content-Type: ${mimeType}\r\n\r\n`),
    fileData,
    Buffer.from(`\r\n--${boundary}--\r\n`),
  ]);
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

async function uploadImage(filePath, accessToken) {
  if (!fs.existsSync(filePath)) {
    console.error(`Error: 文件不存在 - ${filePath}`);
    process.exit(1);
  }
  const url = `${API_BASE_URL}/cgi-bin/media/uploadimg?access_token=${accessToken}`;
  const { body, contentType } = createMultipartFormdata(filePath);
  try {
    const data = await httpRequest(url, {
      method: "POST",
      headers: { "Content-Type": contentType, "Content-Length": body.length },
      body,
      timeout: 60000,
    });
    if (data.errcode) {
      console.error(`Error: 图片上传失败 - ${data.errmsg}`);
      process.exit(1);
    }
    console.log(`✓ 图片上传成功: ${path.basename(filePath)}`);
    return data.url;
  } catch (e) {
    console.error(`Error: HTTP ${e.code || ""} - ${e.message}`);
    process.exit(1);
  }
}

async function uploadThumbMaterial(filePath, accessToken) {
  if (!fs.existsSync(filePath)) {
    console.error(`Error: 封面文件不存在 - ${filePath}`);
    process.exit(1);
  }
  const url = `${API_BASE_URL}/cgi-bin/material/add_material?access_token=${accessToken}&type=thumb`;
  const { body, contentType } = createMultipartFormdata(filePath);
  try {
    const data = await httpRequest(url, {
      method: "POST",
      headers: { "Content-Type": contentType, "Content-Length": body.length },
      body,
      timeout: 60000,
    });
    if (data.errcode) {
      console.error(`Error: 封面图片上传失败 - ${data.errmsg}`);
      process.exit(1);
    }
    console.log(`✓ 封面图片上传成功: ${path.basename(filePath)}`);
    return data.media_id;
  } catch (e) {
    console.error(`Error: HTTP ${e.code || ""} - ${e.message}`);
    process.exit(1);
  }
}

function findImagesInMarkdown(content, basePath) {
  const images = [];
  const pattern = /!\[([^\]]*)\]\(([^)]+)\)/g;
  let match;
  while ((match = pattern.exec(content)) !== null) {
    const imgPath = match[2];
    if (
      imgPath.startsWith("http://") ||
      imgPath.startsWith("https://") ||
      imgPath.startsWith("data:")
    ) {
      images.push([imgPath, imgPath, false]);
      continue;
    }
    const absPath = path.isAbsolute(imgPath)
      ? imgPath
      : path.join(basePath, imgPath);
    images.push([imgPath, absPath, fs.existsSync(absPath)]);
  }
  return images;
}

async function processMarkdownImages(content, basePath, accessToken) {
  const images = findImagesInMarkdown(content, basePath);
  const localImages = images
    .filter(([, , isLocal]) => isLocal)
    .map(([orig, absPath]) => [orig, absPath]);
  if (localImages.length === 0) {
    console.log("ℹ 没有本地图片需要上传");
    return content;
  }
  console.log(`\n正在上传 ${localImages.length} 张本地图片...`);
  const urlMapping = {};
  for (let i = 0; i < localImages.length; i++) {
    const [origPath, absPath] = localImages[i];
    process.stdout.write(`  [${i + 1}/${localImages.length}] `);
    urlMapping[origPath] = await uploadImage(absPath, accessToken);
  }
  let result = content;
  for (const [origPath, wechatUrl] of Object.entries(urlMapping)) {
    const escapedPath = origPath.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    result = result.replace(
      new RegExp(`(!\\[[^\\]]*\\]\\()${escapedPath}(\\))`, "g"),
      `$1${wechatUrl}$2`,
    );
  }
  console.log(`✓ 所有图片已上传并替换为微信URL\n`);
  return result;
}

function parseMarkdownFile(filePath) {
  const content = fs.readFileSync(filePath, "utf-8");
  let title = "Untitled",
    frontmatterContent = "";
  const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
  if (frontmatterMatch) {
    frontmatterContent = frontmatterMatch[1];
    const titleMatch = frontmatterContent.match(/^title:\s*(.+)$/m);
    if (titleMatch) {
      title = titleMatch[1].replace(/^["']|["']$/g, "").trim();
    }
  }
  const afterFrontmatter = frontmatterMatch
    ? content.slice(content.indexOf("---", 3) + 3)
    : content;
  const lines = afterFrontmatter.trim().split("\n");
  let contentStart = 0;
  if (title === "Untitled") {
    for (let i = 0; i < lines.length; i++) {
      const stripped = lines[i].trim();
      if (!stripped) continue;
      const match = stripped.match(/^(#{1,6})\s+(.+)$/);
      if (match) {
        title = match[2].trim();
        contentStart = i + 1;
        break;
      }
    }
  }
  const contentLines = lines.slice(contentStart);
  const markdownContent = contentLines.join("\n").trim();
  let coverImage = null;
  const imgMatch = markdownContent.match(/!\[([^\]]*)\]\(([^)]+)\)/);
  if (imgMatch) coverImage = imgMatch[2];
  let summary = null;
  for (const line of contentLines) {
    const stripped = line.trim();
    if (
      stripped &&
      !stripped.startsWith("#") &&
      !stripped.startsWith("!") &&
      !stripped.startsWith(">") &&
      !stripped.startsWith("-") &&
      !stripped.startsWith("*") &&
      !stripped.startsWith("`") &&
      !stripped.startsWith("|")
    ) {
      summary = stripped.substring(0, 120);
      break;
    }
  }
  return {
    title: title.substring(0, 64),
    content: markdownContent,
    summary,
    cover_image: coverImage,
    source_path: filePath,
  };
}

async function createDraft(
  title,
  content,
  accessToken,
  thumbMediaId = null,
  author = "",
  digest = "",
) {
  const url = `${API_BASE_URL}/cgi-bin/draft/add?access_token=${accessToken}`;
  const article = {
    title,
    content,
    content_source_url: "",
    need_open_comment: 0,
    only_fans_can_comment: 0,
  };
  if (author) article.author = author;
  if (digest) article.digest = digest;
  if (thumbMediaId) article.thumb_media_id = thumbMediaId;
  const payload = { articles: [article] };
  try {
    const data = await httpRequest(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(JSON.stringify(payload)),
      },
      body: JSON.stringify(payload),
      timeout: 120000,
    });
    if (data.errcode && data.errcode !== 0) {
      console.error(`Error: 创建草稿失败 - ${data.errmsg}`);
      process.exit(1);
    }
    return data;
  } catch (e) {
    console.error(`Error: HTTP ${e.code || ""} - ${e.message}`);
    process.exit(1);
  }
}

function loadHtmlContent(markdownPath) {
  const htmlPath = markdownPath.replace(/\.md$/, ".html");
  if (fs.existsSync(htmlPath)) {
    return fs.readFileSync(htmlPath, "utf-8");
  }
  return null;
}

function checkAndInstallWenyan() {
  try {
    execSync("wenyan --version", { stdio: "pipe" });
    return true;
  } catch (e) {
    console.log("ℹ 文颜未安装，正在安装...");
    try {
      execSync("npm install -g @wenyan-md/cli", { stdio: "inherit" });
      console.log("✓ 文颜安装成功");
      return true;
    } catch (e) {
      console.error("Warning: 文颜安装失败");
      return false;
    }
  }
}

function validateWenyanTheme(theme) {
  if (WENYAN_THEMES.includes(theme)) {
    return theme;
  }
  console.log(`ℹ 主题 "${theme}" 不存在，使用 default 主题`);
  return "default";
}

function shouldUseCustomCss() {
  const cfg = loadConfigFile();
  return cfg?.wenyanCustomCss === true;
}

function formatWithWenyan(markdownPath, theme = "default") {
  if (!checkAndInstallWenyan()) {
    console.log("ℹ 跳过文颜排版");
    return null;
  }
  try {
    console.log(`正在使用文颜排版 (主题: ${theme})...`);
    let command = 'wenyan render -f "' + markdownPath + '" -t ' + theme;
    const defaultCssPath = path.join(__dirname, `${theme}.css`);
    if (shouldUseCustomCss() && fs.existsSync(defaultCssPath)) {
      command += ' -c "' + defaultCssPath + '"';
    }
    const result = execSync(command, { encoding: "utf-8" });
    console.log("✓ 文颜排版完成");
    return result;
  } catch (e) {
    console.log("ℹ 文颜排版失败，跳过此步骤");
    return null;
  }
}

async function main() {
  const args = process.argv.slice(2);
  let markdownPath = null;
  if (args.length > 0) {
    if (args[0] === "-m" || args[0] === "--markdown") markdownPath = args[1];
    else if (args[0].endsWith(".md")) markdownPath = args[0];
  }
  if (!markdownPath) {
    console.log(
      `微信公众号发布工具\n用法: node wechat-publisher.js <markdown-file>`,
    );
    process.exit(1);
  }
  if (!fs.existsSync(markdownPath)) {
    console.error(`Error: 文件不存在 - ${markdownPath}`);
    process.exit(1);
  }

  console.log("=".repeat(50));
  console.log("发布文章到微信草稿箱");
  console.log("=".repeat(50));

  const token = await getAccessToken();
  console.log(`\n解析文件: ${markdownPath}`);

  const article = parseMarkdownFile(markdownPath);
  console.log(`  标题: ${article.title}`);
  console.log(
    `  摘要: ${article.summary ? article.summary.substring(0, 50) + "..." : "(无)"}`,
  );

  const baseDir = path.dirname(markdownPath);
  await processMarkdownImages(article.content, baseDir, token);

  let htmlContent = loadHtmlContent(markdownPath);
  if (htmlContent) {
    console.log(
      `✓ 读取已生成的 HTML 内容: ${path.basename(markdownPath).replace(".md", ".html")}`,
    );
  } else {
    console.log("ℹ 未找到 HTML 文件，使用文颜生成...");
    const cfg = loadConfigFile();
    const wenyanTheme = validateWenyanTheme(cfg.wenyanTheme || "default");
    const wenyanOutput = formatWithWenyan(markdownPath, wenyanTheme);
    if (wenyanOutput) {
      const startTagMatch = wenyanOutput.match(
        /<section[^>]*id="wenyan"[^>]*>/,
      );
      const lastEndTag = wenyanOutput.lastIndexOf("</section>");
      if (startTagMatch && lastEndTag > 0) {
        const contentStart = startTagMatch.index + startTagMatch[0].length;
        htmlContent = wenyanOutput.substring(contentStart, lastEndTag);
      } else {
        htmlContent = wenyanOutput.replace(/<\/?section[^>]*>/g, "");
      }
      const htmlFilePath = path.join(
        baseDir,
        path.basename(markdownPath, ".md") + ".html",
      );
      fs.writeFileSync(htmlFilePath, htmlContent, "utf-8");
      console.log(`✓ HTML 内容已保存到: ${path.basename(htmlFilePath)}`);
    } else {
      htmlContent = article.content;
    }
  }

  let thumbMediaId = null;
  const coverImage = article.cover_image;
  const defaultCoverPath = path.join(
    path.dirname(__filename),
    "default_cover.jpg",
  );

  if (
    coverImage &&
    !coverImage.startsWith("http://") &&
    !coverImage.startsWith("https://")
  ) {
    const coverPath = path.join(baseDir, coverImage);
    if (fs.existsSync(coverPath)) {
      console.log("\n上传封面图片...");
      thumbMediaId = await uploadThumbMaterial(coverPath, token);
    }
  }

  if (!thumbMediaId) {
    console.log("\n使用 sharp 生成标题封面图...");
    const tempCoverPath = path.join(os.tmpdir(), `cover_${Date.now()}.png`);
    try {
      await generateCoverImage(article.title, tempCoverPath);
      thumbMediaId = await uploadThumbMaterial(tempCoverPath, token);
      fs.unlinkSync(tempCoverPath);
    } catch (e) {
      console.error(`生成封面失败: ${e.message}，尝试使用默认封面...`);
      if (fs.existsSync(defaultCoverPath)) {
        thumbMediaId = await uploadThumbMaterial(defaultCoverPath, token);
      }
    }
  }

  console.log("正在创建草稿...");
  const result = await createDraft(
    article.title,
    htmlContent,
    token,
    thumbMediaId,
    "",
    article.summary || "",
  );

  console.log("\n" + "=".repeat(50));
  console.log("✓ 发布成功！");
  console.log("=".repeat(50));
  console.log(`  Media ID: ${result.media_id || "N/A"}`);
  console.log("\n请登录微信公众平台查看草稿箱。");
}

main();
