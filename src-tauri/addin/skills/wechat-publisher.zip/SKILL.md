---
name: wechat-publisher
description: 微信公众号 Markdown 文章发布工作流，包含图片上传、草稿创建。HTML 文件由 topic-searcher 使用文颜生成
---

# WeChat Publisher

微信公众号 Markdown 文章发布工作流。

## 工作流程

1. 读取 `config.json` 配置（微信凭证）
2. 获取 Access Token（自动缓存）
3. 读取 Markdown 同级目录下的 `draft.html` 文件（如不存在则报错）
4. 上传本地图片到微信素材库
5. 上传封面图片到永久素材库（如未设置封面则使用默认封面）
6. 创建微信草稿

## 文件结构

```
wechat-publisher/
├── wechat-publisher.js  # 发布脚本
└── default_cover.jpg    # 默认封面图片（当文章无封面时使用）
```

## config.json 格式

```json
{
  "wechat": {
    "appid": "你的AppID",
    "appsecret": "你的AppSecret"
  }
}
```

## 使用方法

```bash
node wechat-publisher.js <markdown-file>
```

## 前置要求

1. IP 已加入微信公众号后台白名单
2. 微信 AppID 和 AppSecret 已配置
3. Markdown 文件对应的 `draft.html` 已存在（推荐由 topic-searcher 生成）
4. 如 HTML 文件不存在，将自动使用文颜生成（需配置 `wenyanTheme`）

## 功能特性

- 优先读取 Markdown 同级目录下的 HTML 文件
- HTML 文件不存在时自动使用文颜排版生成
- 自动缓存 Access Token
- 支持本地图片上传到微信素材库
- 支持默认封面图片（当文章无封面时使用 `default_cover.jpg`）
- 列表自动转换为段落格式（微信移动端兼容）
