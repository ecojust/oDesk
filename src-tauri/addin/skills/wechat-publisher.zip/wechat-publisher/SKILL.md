---
name: wechat-publisher
description: 微信公众号 Markdown 文章发布工作流，包含文颜排版、图片上传、草稿创建
---

# WeChat Publisher

微信公众号 Markdown 文章发布工作流。

## 工作流程

1. 读取 `config.json` 配置（微信凭证）
2. 获取 Access Token（自动缓存）
3. 检查并自动安装文颜 CLI（如未安装）
4. 调用 `wenyan render` 排版 Markdown
5. 上传本地图片到微信素材库
6. 上传封面图片到永久素材库（如未设置封面则使用默认封面）
7. 调用 bm.md API 渲染精美 HTML（如失败则使用本地后备转换）
8. 创建微信草稿

## 文件结构

```
wechat-publisher/
├── wechat-publisher.js  # 发布脚本
└── default_cover.jpg    # 默认封面图片（当文章无封面时使用）
```

## config.json 格式

```json
{
  "wechat": {
    "appid": "你的AppID",
    "appsecret": "你的AppSecret"
  },
  "wenyanTheme": "default"
}
```

## 可用主题

文颜内置以下主题（`wenyanTheme` 配置项）：

| 主题名        | 描述                          |
| ------------- | ----------------------------- |
| `default`     | 简洁经典，适合长文阅读        |
| `orangeheart` | 温暖橙色，充满活力与优雅      |
| `rainbow`     | 色彩丰富，布局干净            |
| `lapis`       | 清新淡雅，冷调蓝色            |
| `pie`         | 现代锐利，参考 sspai.com      |
| `maize`       | 柔和玉米色调，清晰明亮        |
| `purple`      | 简约精致，紫色点缀            |
| `phycat`      | 物理猫-薄荷，薄荷绿，结构清晰 |

> 如果配置的主题不在列表中，将自动使用 `default` 主题

## 使用方法

```bash
node wechat-publisher.js <markdown-file>
```

## 前置要求

1. IP 已加入微信公众号后台白名单
2. 微信 AppID 和 AppSecret 已配置
3. 文颜 CLI 会自动安装（如未安装）

## 功能特性

- 自动检查并安装文颜 CLI
- 自动缓存 Access Token
- 支持本地图片上传到微信素材库
- 支持默认封面图片（当文章无封面时使用 `default_cover.jpg`）
- bm.md 渲染失败时自动使用本地后备转换
- 列表自动转换为段落格式（微信移动端兼容）
