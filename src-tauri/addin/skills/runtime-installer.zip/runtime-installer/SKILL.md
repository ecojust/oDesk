---
name: runtime-installer
description: |
  自动检测并安装 Node.js 和 Python 运行时环境。当出现以下情况时必须使用本技能：
  (1) 用户运行 node/npm/python3/pip3 命令时提示 "command not found" 或 "未安装"
  (2) 项目安装依赖或运行脚本时因缺少 Node.js/Python 而失败
  (3) 用户明确要求安装 Node.js 或 Python 运行环境
  (4) 新项目 setup/init 过程中检测到缺少运行时环境
  (5) CI/CD 配置或开发环境初始化时需要安装基础运行时

  支持 Windows 和 macOS 两大平台。
  macOS 使用 Homebrew 安装（无 sudo），Windows 从官方渠道下载安装包。
  不适用于 Linux 系统。
---

# Runtime Installer

自动检测当前系统是否已安装 Node.js 和 Python 3，对缺失的运行时自动安装。macOS 用 Homebrew，Windows 从官方渠道下载安装包。

## 使用流程

### 1. 检测已安装的运行时（跳过已安装的）

> **重要：必须先检测，只安装缺失的部分。已安装的运行时直接跳过，不会重新安装。**

检测系统中是否已存在所需的运行时：

```bash
# 检查 Node.js
command -v node && node --version || echo "Node.js not found"
command -v npm && npm --version || echo "npm not found"

# 检查 Python 3
command -v python3 && python3 --version || echo "Python 3 not found"
command -v pip3 && pip3 --version || echo "pip3 not found"
```

**检测结果处理逻辑：**

- `node --version` 正常输出 → Node.js 已安装，**跳过**安装步骤
- `node: command not found` → 需要安装 Node.js
- `python3 --version` 正常输出 → Python 已安装，**跳过**安装步骤
- `python3: command not found` → 需要安装 Python 3
- 如果两者都已安装，直接结束，无需执行安装脚本

### 2. 确定操作系统

```bash
# macOS
uname -s  # 返回 Darwin

# Windows
# 使用 $env:OS 或 (Get-CimInstance Win32_OperatingSystem).Caption
```

### 3. 安装缺失的运行时

根据操作系统选择对应的脚本执行：

| 平台    | 脚本                  | 说明                                                                         |
| ------- | --------------------- | ---------------------------------------------------------------------------- |
| macOS   | `scripts/install.sh`  | 通过 Homebrew 安装（自动安装 Homebrew，无需 sudo）                           |
| Windows | `scripts/install.ps1` | Node.js 用 nvm-windows，Python 用官方安装包（InstallAllUsers=0，无需管理员） |

> 脚本内部会再次检测已安装的运行时，确保只安装缺失的部分。

#### macOS

```bash
bash scripts/install.sh
```

#### Windows

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\install.ps1
```

### 4. 验证安装

每个运行时安装完成后，脚本会立即执行版本检测命令验证安装成功：

```
--- Verifying Node.js installation ---
  v22.14.0
[INFO] Node.js verification: OK
  v11.2.0
[INFO] npm verification: OK

--- Verifying Python installation ---
  Python 3.13.2
[INFO] Python 3 verification: OK
  pip 25.1.2 from ... (python 3.13)
[INFO] pip3 verification: OK
```

全部安装完成后，还会输出最终汇总：

```
[INFO] === Final Verification ===
[INFO] Running version checks...

  node v22.14.0
  npm v11.2.0
  Python 3.13.2
  pip 25.1.2 from ... (python 3.13)

[INFO] If anything shows NOT FOUND, please restart your terminal.
```

也可以手动验证：

```bash
# macOS
node --version
npm --version
python3 --version
pip3 --version

# Windows
node --version
npm --version
python --version
pip --version
```

## 注意事项

- **macOS**: 通过 Homebrew 安装，无需 sudo（如未安装 Homebrew 会自动安装）
- **Windows**: Node.js 通过 nvm-windows（用户级）安装，Python 用 InstallAllUsers=0 安装到当前用户，均无需管理员权限
- Node.js 安装最新的 LTS（长期支持）版本
- Python 安装最新的稳定版本（3.x）
- 安装完成后可能需要**重新打开终端**才能生效
- 如果 `PATH` 未自动更新，可能需要手动将运行时路径添加到环境变量中
- 脚本会自动跳过已安装的运行时，只安装缺失的部分

## 常见问题

### 安装后 `node` 命令找不到

重新打开终端窗口，或执行 `source ~/.zshrc`（macOS） / 重新打开 PowerShell（Windows）。

### 缺少管理员权限

- macOS: Homebrew 不需要管理员权限（安装到 `/opt/homebrew` 或 `/usr/local`）
- Windows: nvm-windows 和 Python 用户级安装均无需管理员权限

### 网络问题导致下载失败

脚本会自动重试。如果持续失败，可以手动安装：

- macOS: `brew install node python`
- Windows: 从 https://nodejs.org/en/download/ 和 https://www.python.org/downloads/ 下载安装包
