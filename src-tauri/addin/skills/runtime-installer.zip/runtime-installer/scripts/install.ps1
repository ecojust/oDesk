param(
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Install-NvmWindows {
    Write-Info "Installing nvm-windows..."

    $tmpDir = "$env:TEMP\opencode-runtime"
    New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

    try {
        $latestUrl = "https://api.github.com/repos/coreybutler/nvm-windows/releases/latest"
        $release = Invoke-RestMethod -Uri $latestUrl -TimeoutSec 30
        $asset = $release.assets | Where-Object { $_.name -like "nvm-setup.zip" } | Select-Object -First 1

        if (-not $asset) {
            Write-Error "Could not find nvm-windows download asset."
            return $false
        }

        $zipPath = "$tmpDir\nvm-setup.zip"
        Write-Info "Downloading nvm-windows from $($asset.browser_download_url)..."
        Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zipPath -TimeoutSec 120

        Expand-Archive -Path $zipPath -DestinationPath "$tmpDir\nvm" -Force

        $setupExe = Get-ChildItem "$tmpDir\nvm" -Filter "nvm-setup.exe" -Recurse | Select-Object -First 1
        if (-not $setupExe) {
            Write-Error "nvm-setup.exe not found in archive."
            return $false
        }

        Write-Info "Installing nvm-windows silently..."
        Start-Process $setupExe.FullName -ArgumentList "/S" -Wait -NoNewWindow

        Start-Sleep -Seconds 3

        $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
        Write-Info "nvm-windows installed."
        return $true
    }
    catch {
        Write-Error "nvm-windows installation failed: $_"
        Write-Error "Install manually from: https://github.com/coreybutler/nvm-windows/releases"
        return $false
    }
    finally {
        Remove-Item -Path $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Install-NodeJS {
    Write-Info "Node.js not found. Installing via nvm-windows..."

    $hasNvm = Get-Command nvm -ErrorAction SilentlyContinue
    if (-not $hasNvm) {
        $installed = Install-NvmWindows
        if (-not $installed) { return }
    }

    try {
        Write-Info "Installing latest Node.js LTS via nvm..."
        $nvmPath = "$env:APPDATA\nvm"
        if (Test-Path "$nvmPath\nvm.exe") {
            & "$nvmPath\nvm.exe" install lts 2>&1 | Out-Null
            & "$nvmPath\nvm.exe" use lts 2>&1 | Out-Null
        } else {
            nvm install lts 2>&1 | Out-Null
            nvm use lts 2>&1 | Out-Null
        }

        $nodePath = "$nvmPath\v*"
        $latestNodeDir = Get-ChildItem "$nvmPath" -Directory | Where-Object { $_.Name -match '^\d+\.\d+\.\d+' } | Sort-Object Name -Descending | Select-Object -First 1
        if ($latestNodeDir) {
            $env:Path = "$($latestNodeDir.FullName);$env:Path"
        }

        Write-Host ""
        Write-Info "--- Verifying Node.js installation ---"
        if (Get-Command node -ErrorAction SilentlyContinue) {
            $nodeVer = node --version
            Write-Host "  $nodeVer"
            Write-Info "Node.js verification: OK"
        } else {
            Write-Error "Node.js verification FAILED. Try restarting terminal."
        }
        if (Get-Command npm -ErrorAction SilentlyContinue) {
            $npmVer = npm --version
            Write-Host "  $npmVer"
            Write-Info "npm verification: OK"
        } else {
            Write-Error "npm verification FAILED."
        }
    }
    catch {
        Write-Error "Node.js installation failed: $_"
    }
}

function Install-Python {
    Write-Info "Python not found. Installing latest stable (user-level, no admin)..."

    $tmpDir = "$env:TEMP\opencode-runtime"
    New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

    try {
        Write-Info "Fetching latest Python version..."
        $downloadPage = Invoke-WebRequest -Uri "https://www.python.org/downloads/" -TimeoutSec 30
        $versionMatch = [regex]::Match($downloadPage.Content, 'python-3\.\d+\.\d+-amd64\.exe')
        if (-not $versionMatch.Success) {
            throw "Could not determine latest Python version."
        }
        $version = [regex]::Match($versionMatch.Value, '3\.\d+\.\d+').Value

        $exeFile = "$tmpDir\python.exe"
        $exeUrl = "https://www.python.org/ftp/python/$version/python-$version-amd64.exe"
        Write-Info "Downloading Python $version..."
        Invoke-WebRequest -Uri $exeUrl -OutFile $exeFile -TimeoutSec 300

        Write-Info "Installing Python for current user (no admin needed)..."
        $installDir = "$env:LOCALAPPDATA\Programs\Python\Python$($version -replace '\.', '')"
        $installArgs = "/quiet InstallAllUsers=0 PrependPath=1 TargetDir=`"$installDir`""
        Start-Process $exeFile -ArgumentList $installArgs -Wait -NoNewWindow

        $env:Path = "$installDir;$installDir\Scripts;$env:Path"

        Write-Host ""
        Write-Info "--- Verifying Python installation ---"
        if (Get-Command python -ErrorAction SilentlyContinue) {
            $pyVer = python --version
            Write-Host "  $pyVer"
            Write-Info "Python verification: OK"
        } else {
            Write-Error "Python verification FAILED. Try restarting terminal."
        }
        if (Get-Command pip -ErrorAction SilentlyContinue) {
            $pipVer = pip --version
            Write-Host "  $pipVer"
            Write-Info "pip verification: OK"
        } else {
            Write-Error "pip verification FAILED."
        }
    }
    catch {
        Write-Error "Python installation failed: $_"
        Write-Error "Install manually from: https://www.python.org/downloads/"
    }
    finally {
        Remove-Item -Path $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Main {
    Write-Info "=== Runtime Installer (Windows - No Admin) ==="

    $nodeInstalled = $false
    $pythonInstalled = $false

    if (Get-Command node -ErrorAction SilentlyContinue) {
        Write-Info "Node.js already installed: $(node --version)"
        $nodeInstalled = $true
    }

    if (Get-Command python -ErrorAction SilentlyContinue) {
        $pyVer = python --version 2>&1
        Write-Info "Python already installed: $pyVer"
        $pythonInstalled = $true
    }

    if ($nodeInstalled -and $pythonInstalled) {
        Write-Info "All required runtimes are already installed!"
        return
    }

    if (-not $nodeInstalled) {
        Install-NodeJS
    }

    if (-not $pythonInstalled) {
        Install-Python
    }

    Write-Host ""
    Write-Info "=== Final Verification ==="
    Write-Info "Running version checks..."
    Write-Host ""
    if (Get-Command node -ErrorAction SilentlyContinue) {
        Write-Host "  node $(node --version)"
    } else {
        Write-Error "  node NOT FOUND"
    }
    if (Get-Command npm -ErrorAction SilentlyContinue) {
        Write-Host "  npm v$(npm --version)"
    } else {
        Write-Error "  npm NOT FOUND"
    }
    if (Get-Command python -ErrorAction SilentlyContinue) {
        Write-Host "  $(python --version)"
    } else {
        Write-Error "  python NOT FOUND"
    }
    if (Get-Command pip -ErrorAction SilentlyContinue) {
        Write-Host "  $(pip --version)"
    } else {
        Write-Error "  pip NOT FOUND"
    }
    Write-Host ""
    Write-Info "If anything shows NOT FOUND, please restart your terminal."
}

Main
