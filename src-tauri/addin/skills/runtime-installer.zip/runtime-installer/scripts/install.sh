#!/bin/bash
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { printf "${GREEN}[INFO]${NC} %s\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC} %s\n" "$*"; }
error() { printf "${RED}[ERROR]${NC} %s\n" "$*"; }

ensure_homebrew() {
    if ! command -v brew &>/dev/null; then
        info "Homebrew not found. Installing Homebrew..."
        NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

        local homebrew_prefix
        if [[ "$(uname -m)" == "arm64" ]]; then
            homebrew_prefix="/opt/homebrew"
        else
            homebrew_prefix="/usr/local"
        fi

        eval "$(${homebrew_prefix}/bin/brew shellenv)"
        info "Homebrew installed"
    else
        info "Homebrew already installed"
    fi
}

install_node() {
    info "Node.js not found. Installing via Homebrew..."
    brew install node

    echo ""
    info "--- Verifying Node.js installation ---"
    if command -v node &>/dev/null; then
        node --version
        info "Node.js verification: OK"
    else
        error "Node.js verification FAILED. Try restarting terminal."
    fi
    if command -v npm &>/dev/null; then
        npm --version
        info "npm verification: OK"
    else
        error "npm verification FAILED."
    fi
}

install_python() {
    info "Python 3 not found. Installing via Homebrew..."
    brew install python

    echo ""
    info "--- Verifying Python installation ---"
    if command -v python3 &>/dev/null; then
        python3 --version
        info "Python 3 verification: OK"
    else
        error "Python 3 verification FAILED. Try restarting terminal."
    fi
    if command -v pip3 &>/dev/null; then
        pip3 --version
        info "pip3 verification: OK"
    else
        error "pip3 verification FAILED."
    fi
}

main() {
    info "=== Runtime Installer (macOS) ==="

    if [ "$(uname -s)" != "Darwin" ]; then
        error "This script is for macOS only."
        exit 1
    fi

    local node_installed=false
    local python_installed=false

    if command -v node &>/dev/null; then
        info "Node.js already installed: $(node --version)"
        node_installed=true
    fi

    if command -v python3 &>/dev/null; then
        info "Python 3 already installed: $(python3 --version)"
        python_installed=true
    fi

    if $node_installed && $python_installed; then
        info "All required runtimes are already installed!"
        exit 0
    fi

    ensure_homebrew

    if ! $node_installed; then
        install_node
    fi

    if ! $python_installed; then
        install_python
    fi

    echo ""
    info "=== Final Verification ==="
    info "Running version checks..."
    echo ""
    if command -v node &>/dev/null; then
        echo "  node $(node --version)"
    else
        error "  node NOT FOUND"
    fi
    if command -v npm &>/dev/null; then
        echo "  npm v$(npm --version)"
    else
        error "  npm NOT FOUND"
    fi
    if command -v python3 &>/dev/null; then
        python3 --version | sed 's/^/  /'
    else
        error "  python3 NOT FOUND"
    fi
    if command -v pip3 &>/dev/null; then
        pip3 --version | sed 's/^/  /'
    else
        error "  pip3 NOT FOUND"
    fi
    echo ""
    info "If anything shows NOT FOUND, please restart your terminal."
}

main "$@"
