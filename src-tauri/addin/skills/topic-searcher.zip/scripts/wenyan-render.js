#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const WENYAN_THEMES = [
  "default",
  "orangeheart",
  "rainbow",
  "lapis",
  "pie",
  "maize",
  "purple",
  "phycat",
];

let config = null;

function loadConfigFile() {
  if (config) return config;
  const configPaths = [
    process.cwd() + "/config.json",
    path.join(__dirname, "config.json"),
    path.join(path.dirname(__dirname), "config.json"),
    path.join(__dirname, "../config.json"),
  ];
  for (const configPath of configPaths) {
    if (fs.existsSync(configPath)) {
      try {
        config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        return config;
      } catch (e) {
        console.warn(`Warning: 配置文件解析失败 - ${configPath}: ${e.message}`);
      }
    }
  }
  return null;
}

function getConfigTheme() {
  const cfg = loadConfigFile();
  return cfg?.wenyanTheme;
}

function shouldUseCustomCss() {
  const cfg = loadConfigFile();
  return cfg?.wenyanCustomCss === true;
}

function checkAndInstallWenyan() {
  try {
    execSync("wenyan --version", { stdio: "pipe" });
    return true;
  } catch (e) {
    console.log("ℹ 文颜未安装，正在安装...");
    try {
      execSync("npm install -g @wenyan-md/cli", { stdio: "inherit" });
      console.log("✓ 文颜安装成功");
      return true;
    } catch (e) {
      console.error("Warning: 文颜安装失败");
      return false;
    }
  }
}

function formatWithWenyan(
  markdownPath,
  theme = "default",
  customCssPath = null,
) {
  if (!checkAndInstallWenyan()) {
    console.log("ℹ 跳过文颜排版");
    return null;
  }
  try {
    console.log(`正在使用文颜排版 (主题: ${theme})...`);
    const wenyanCliPath = require("path").join(
      process.env.HOME,
      ".nvm/versions/node/v20.19.0/lib/node_modules/@wenyan-md/cli/dist/cli.js",
    );
    let command = `node --experimental-vm-modules "${wenyanCliPath}" render -f "${markdownPath}" -t ${theme}`;
    if (customCssPath) {
      command += ` -c "${customCssPath}"`;
    }
    const result = execSync(command, { encoding: "utf-8" });
    console.log("✓ 文颜排版完成");
    return result;
  } catch (e) {
    console.log("ℹ 文颜排版失败，跳过此步骤");
    return null;
  }
}

function renderMarkdownToHtml(markdownPath, theme = "default") {
  if (!fs.existsSync(markdownPath)) {
    console.error(`Error: 文件不存在 - ${markdownPath}`);
    return false;
  }

  const baseDir = path.dirname(markdownPath);
  const defaultCssPath = path.join(__dirname, `${theme}.css`);
  const customCssPath =
    shouldUseCustomCss() && fs.existsSync(defaultCssPath)
      ? defaultCssPath
      : null;
  const wenyanOutput = formatWithWenyan(markdownPath, theme, customCssPath);

  if (wenyanOutput) {
    let htmlContent;
    const startTagMatch = wenyanOutput.match(/<section[^>]*id="wenyan"[^>]*>/);
    const lastEndTag = wenyanOutput.lastIndexOf("</section>");
    if (startTagMatch && lastEndTag > 0) {
      const contentStart = startTagMatch.index + startTagMatch[0].length;
      htmlContent = wenyanOutput.substring(contentStart, lastEndTag);
    } else {
      htmlContent = wenyanOutput.replace(/<\/?section[^>]*>/g, "");
    }
    const htmlFilePath = path.join(
      baseDir,
      path.basename(markdownPath, ".md") + ".html",
    );
    fs.writeFileSync(htmlFilePath, htmlContent, "utf-8");
    console.log(`✓ HTML 内容已保存到: ${path.basename(htmlFilePath)}`);
    return true;
  }
  return false;
}

function main() {
  const args = process.argv.slice(2);
  let markdownPath = null;

  for (const arg of args) {
    if (arg.endsWith(".md")) {
      markdownPath = arg;
      break;
    }
  }

  if (!markdownPath) {
    console.log(
      `Markdown 转 HTML 工具\n用法: node wenyan-render.js <markdown-file>\n可用主题: ${WENYAN_THEMES.join(", ")}`,
    );
    process.exit(1);
  }

  console.log("=".repeat(50));
  console.log("Markdown 转 HTML (文颜排版)");
  console.log("=".repeat(50));

  const success = renderMarkdownToHtml(markdownPath, getConfigTheme());

  if (!success) {
    console.error("Error: HTML 生成失败");
    process.exit(1);
  }
}

main();
