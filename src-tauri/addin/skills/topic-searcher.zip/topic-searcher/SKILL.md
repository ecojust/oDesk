---
name: topic-searcher
description: 根据用户指定的主题搜索相关新闻/故事，并按照指定格式生成文档。当用户要求"搜索xxx"或"帮我搜索xxx"时使用此skill。
---

# 主题搜索与文档生成

## 工作流程

1. **理解用户需求**
   - 确认用户指定的主题
   - 确认输出文档的格式要求（参考demo.md格式）

2. **搜索相关资讯**
   - 使用 `websearch` 工具搜索主题相关内容
   - 关键词组合：主题名 + 相关词（如"故事"、"新闻"、"亲身经历"等）
   - 搜索结果以10条为宜

3. **筛选与整合**
   - 筛选与主题高度相关的内容
   - 整理成统一的文档主题

4. **生成文档**
   - 按照demo.md的格式创建Markdown文档
   - 文件命名为 `draft.md`
   - 内容包括：frontmatter（标题、作者、日期等）+ 正文

5. **转换为HTML**
   - 生成 `draft.md` 后，立即使用文颜转换为HTML
   - 使用脚本路径：`scripts/wenyan-render.js`
   - 命令格式：`node <skill-path>/scripts/wenyan-render.js <filePath>/draft.md`
   - 主题从 `config.json` 的 `wenyanTheme` 配置读取
   - 验证HTML文件是否生成成功

6. **验证执行成功**
   - 使用 `bash` 工具执行 `ls -la draft.md draft.html` 验证文件是否成功生成
   - 如果文件不存在或为空，提示用户并重新生成

## 约束条件

- 成功生成 `draft.md` 文件
- 成功生成 `draft.html` 文件（使用 wenyan render 转换）
- 文件内容非空且符合格式要求
- 正文内容字数控制在600-1000字之间

## 输入格式参考

用户可能的表述方式：

- "帮我搜索xxx"
- "搜索xxx相关内容"
- "搜索xxx的故事"
- "用户给出一个主题，请搜索相关新闻或者故事，然后按照demo.md的格式记录成文档"

## 输出格式

参考 `demo.md` 格式：

```markdown
---
author: 作者名
title: 文章标题
slug: url-slug
description: 文章描述
date: YYYY-MM-DD HH:MM:SS
draft: false
ShowToc: true
TocOpen: true
tags:
  - 标签1
categories:
  - 分类
---

# 正文内容
```

## 文件结构

```
topic-searcher/
├── SKILL.md           # 技能说明文档
├── demo.md            # 输出格式参考
└── scripts/
    ├── wenyan-render.js  # 文颜转换脚本
    └── config.json       # 配置文件（wenyanTheme）
```

## config.json 配置

```json
{
  "wenyanTheme": "default"
}
```

可用主题：default, orangeheart, rainbow, lapis, pie, maize, purple, phycat

## 注意事项

- 所有搜索结果必须在同一主题下，确保内容统一性
- 生成的markdown文件，各个section之间不需要有多余的空行
- 文件保存路径为当前工作目录的 `draft.md`
- frontmatter中的date使用当前日期时间
- 文章正文开头不要添加 `>` 引用描述段落（description已在frontmatter中定义）
- **重要**：生成 `draft.md` 后必须立即使用 `wenyan-render.js` 脚本转换为 `draft.html`
