---
name: topic-searcher
description: 根据用户指定的主题搜索相关新闻/故事，并按照指定格式生成文档。当用户要求"搜索xxx"或"帮我搜索xxx"时使用此skill。
---

# 主题搜索与文档生成

## 工作流程

1. **理解用户需求**
   - 确认用户指定的主题
   - 确认输出文档的格式要求（参考demo.md格式）

2. **搜索相关资讯**
   - 使用 `websearch` 工具搜索主题相关内容
   - 关键词组合：主题名 + 相关词（如"故事"、"新闻"、"亲身经历"等）
   - 搜索结果以10条为宜

3. **筛选与整合**
   - 筛选与主题高度相关的内容
   - 整理成统一的文档主题

4. **生成文档**
   - 按照demo.md的格式创建Markdown文档
   - 文件命名为 `search.md`
   - 内容包括：frontmatter（标题、作者、日期等）+ 正文

5. **验证执行成功**
   - 使用 `bash` 工具执行 `ls -la search.md` 验证文件是否成功生成
   - 如果文件不存在或为空，提示用户并重新生成

## 约束条件

- 成功生成 `search.md` 文件
- 文件内容非空且符合格式要求
- 正文内容字数控制在600-1000字之间

## 输入格式参考

用户可能的表述方式：

- "帮我搜索xxx"
- "搜索xxx相关内容"
- "搜索xxx的故事"
- "用户给出一个主题，请搜索相关新闻或者故事，然后按照demo.md的格式记录成文档"

## 输出格式

参考 `demo.md` 格式：

```markdown
---
author: 作者名
title: 文章标题
slug: url-slug
description: 文章描述
date: YYYY-MM-DD HH:MM:SS
draft: false
ShowToc: true
TocOpen: true
tags:
  - 标签1
categories:
  - 分类
---

# 正文内容
```

## 注意事项

- 所有搜索结果必须在同一主题下，确保内容统一性
- 生成的markdown文件，各个section之间不需要有多余的空行
- 文件保存路径为当前工作目录的 `search.md`
- frontmatter中的date使用当前日期时间
- 文章正文开头不要添加 `>` 引用描述段落（description已在frontmatter中定义）
