---
name: recipe-steps-diagram
description: |
  用Canvas绘制菜品步骤示意图。当用户要求绘制菜品做法图、烹饪步骤图、流程图、食谱图示时使用此skill。支持川菜、粤菜、鲁菜等各类中式菜品。

  触发场景示例：
  - "绘制红烧肉的步骤图"
  - "用canvas画一个菜谱流程图"
  - "生成糖醋排骨的做法步骤图片"
  - "画一个简笔画风格的食谱图"
  - "用canvas输出菜品烹饪流程"
---

# 菜品步骤示意图绘制Skill

## 核心设计原则

1. **突出食材图形** - 文字应小巧简洁，食材图形要大且有特色
2. **圆形卡片布局** - 步骤以圆形卡片顺时针排列
3. **吉卜力手绘风格** - 用Canvas绘制吉卜力动画风格的食材图形：
   - 柔和温暖的色调（pastel）
   - 圆润友好的线条
   - 水彩质感
   - 简约但迷人的视觉效果
4. **色彩丰富** - 每个步骤使用不同颜色区分，背景使用温暖色调
5. **简洁清晰** - 不要多余的箭头、虚线等装饰元素
6. **步骤细致** - 搜索详细做法，根据菜品特性划分更多步骤
7. **材料显示** - 需要显示主料和辅料
8. **重新设计** - 如果用户提供的菜品已经设计过了，那么需要重新设计，并且不要覆盖之前的结果

## 技术实现

### 依赖

```bash
npm install canvas
```

### 代码模板

```javascript
const { createCanvas } = require("canvas");
const fs = require("fs");
const path = require("path");

const size = 800;
const canvas = createCanvas(size, size);
const ctx = canvas.getContext("2d");

const centerX = size / 2;
const centerY = size / 2 + 50; // 向下偏移，避免遮挡标题
const radius = 250;
const iconRadius = 85;

// 步骤数据 - 根据菜品自定义
const steps = [
  { num: "1", title: "步骤1", bg: "#颜色", draw: drawFunc1 },
  { num: "2", title: "步骤2", bg: "#颜色", draw: drawFunc2 },
  { num: "3", title: "步骤3", bg: "#颜色", draw: drawFunc3 },
  { num: "4", title: "步骤4", bg: "#颜色", draw: drawFunc4 },
  { num: "5", title: "步骤5", bg: "#颜色", draw: drawFunc5 },
];

// ========== 背景绘制 ==========
const bgGrad = ctx.createLinearGradient(0, 0, 0, size);
bgGrad.addColorStop(0, "#FDF2E9");
bgGrad.addColorStop(1, "#FDEBD0");
ctx.fillStyle = bgGrad;
ctx.fillRect(0, 0, size, size);

// ========== 标题栏 ==========
const headerGrad = ctx.createLinearGradient(0, 0, 0, 100);
headerGrad.addColorStop(0, "#E74C3C");
headerGrad.addColorStop(1, "#C0392B");
ctx.fillStyle = headerGrad;
ctx.fillRect(0, 0, size, 100);

ctx.font = 'bold 48px "PingFang SC", "Microsoft YaHei", sans-serif';
ctx.fillStyle = "#FFFFFF";
ctx.textAlign = "center";
ctx.textBaseline = "middle";
ctx.fillText("菜品名称", size / 2, 50);

// ========== 步骤绘制 ==========
steps.forEach((step, i) => {
  const angle = (i * 2 * Math.PI) / steps.length - Math.PI / 2;
  const x = centerX + radius * Math.cos(angle);
  const y = centerY + radius * Math.sin(angle);

  // 简化圆形背景 - 淡色光晕，突出内容
  ctx.fillStyle = step.bg;
  ctx.globalAlpha = 0.15;
  ctx.beginPath();
  ctx.arc(x, y, iconRadius + 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  // 食材图形 - 大而突出
  step.draw(x, y - 10, 75);

  // 序号 + 标题
  ctx.font = 'bold 14px "PingFang SC", sans-serif';
  ctx.fillStyle = step.bg;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(step.num + ".", x, y + 50);

  ctx.font = 'bold 16px "PingFang SC", sans-serif';
  ctx.fillText(step.title, x, y + 70);
});

// ========== 输出 ==========
const buffer = canvas.toBuffer("image/png");
fs.writeFileSync(path.join(__dirname, "输出文件名.png"), buffer);
```

## 食材图形绘制规范

### 核心原则

- 吉卜力手绘风格：柔和 pastel 色调、圆润线条、水彩质感
- 运用渐变增加柔和感
- 添加柔和高光
- 颜色要温暖舒适，符合动画风格

### 吉卜力风格配色参考

| 元素   | 浅色    | 深色    | 用途     |
| ------ | ------- | ------- | -------- |
| 青椒   | #A8E6CF | #56AB91 | 蔬菜     |
| 猪肉   | #FFB7B2 | #E57A76 | 肉类     |
| 糖     | #FFF5BA | #F0D475 | 调料     |
| 锅     | #B8C5D6 | #8A9AAF | 烹饪     |
| 背景   | #FFF8E7 | #FFE4C4 | 温暖米色 |
| 标题栏 | #FF9AA2 | #E87F87 | 柔和粉红 |

### 吉卜力风格食材绘制示例

#### 青椒

```javascript
function drawGreenPepper(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 圆润果形轮廓
  ctx.strokeStyle = "#3D8B6E";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-5, -38);
  ctx.quadraticCurveTo(18, -15, 8, 18);
  ctx.quadraticCurveTo(-8, 38, -28, 25);
  ctx.quadraticCurveTo(-38, 5, -22, -28);
  ctx.quadraticCurveTo(-12, -36, -5, -38);
  ctx.closePath();

  // 柔和渐变填充
  const grad = ctx.createRadialGradient(-8, -12, 0, 0, 0, 45);
  grad.addColorStop(0, "#C1E8D6");
  grad.addColorStop(0.6, "#A8E6CF");
  grad.addColorStop(1, "#56AB91");
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.stroke();

  // 柔和高光
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.beginPath();
  ctx.ellipse(-15, -12, 8, 14, -0.3, 0, Math.PI * 2);
  ctx.fill();

  // 果柄
  ctx.strokeStyle = "#5D8A74";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-8, -38);
  ctx.lineTo(-12, -28);
  ctx.stroke();

  ctx.restore();
}
```

#### 猪肉

```javascript
function drawPork(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 圆润肉块轮廓
  ctx.strokeStyle = "#D46A64";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, 2, 32, 20, -0.15, 0, Math.PI * 2);

  // 柔和渐变填充
  const grad = ctx.createRadialGradient(-5, -3, 0, 0, 0, 35);
  grad.addColorStop(0, "#FFD1CE");
  grad.addColorStop(0.7, "#FFB7B2");
  grad.addColorStop(1, "#E57A76");
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.stroke();

  // 柔和高光
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.beginPath();
  ctx.ellipse(-12, -5, 8, 5, -0.2, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}
```

#### 锅

```javascript
function drawWok(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 锅体
  const potGrad = ctx.createLinearGradient(0, -18, 0, 28);
  potGrad.addColorStop(0, "#D4DAE4");
  potGrad.addColorStop(1, "#B8C5D6");
  ctx.fillStyle = potGrad;
  ctx.strokeStyle = "#8A9AAF";
  ctx.lineWidth = 3;

  // 锅身
  ctx.beginPath();
  ctx.ellipse(0, 26, 52, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-52, 26);
  ctx.lineTo(-46, -15);
  ctx.quadraticCurveTo(0, -28, 46, -15);
  ctx.lineTo(52, 26);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // 锅中食材
  ctx.fillStyle = "#FFE082";
  ctx.beginPath();
  ctx.ellipse(0, 0, 36, 24, 0, 0, Math.PI * 2);
  ctx.fill();

  // 蒸汽
  ctx.strokeStyle = "rgba(255,255,255,0.6)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-8, -12);
  ctx.quadraticCurveTo(-12, -28, -5, -35);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(3, -8);
  ctx.quadraticCurveTo(0, -22, 6, -30);
  ctx.stroke();

  ctx.restore();
}
```

### 常用食材绘制模式

#### 肉类（五花肉/排骨）

```javascript
function drawMeat(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 肉块主体 - 渐变填充
  const grad = ctx.createRadialGradient(-10, -10, 0, 0, 0, 50);
  grad.addColorStop(0, "#颜色浅");
  grad.addColorStop(1, "#颜色深");
  ctx.fillStyle = grad;
  ctx.strokeStyle = "#描边色";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.roundRect(-40, -30, 80, 60, 10);
  ctx.fill();
  ctx.stroke();

  // 肥肉纹理
  ctx.fillStyle = "#肥肉色";
  ctx.beginPath();
  ctx.ellipse(-15, 0, 18, 15, -0.2, 0, Math.PI * 2);
  ctx.fill();

  // 高光
  ctx.fillStyle = "rgba(255,255,255,0.4)";
  ctx.beginPath();
  ctx.ellipse(-20, -8, 8, 5, -0.3, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}
```

#### 糖/调料

```javascript
function drawSugar(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 渐变圆形
  const grad = ctx.createRadialGradient(-10, -10, 0, 0, 0, 40);
  grad.addColorStop(0, "#浅金黄");
  grad.addColorStop(1, "#深金黄");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(0, 0, 38, 0, Math.PI * 2);
  ctx.fill();

  // 文字标识
  ctx.fillStyle = "#深色";
  ctx.font = "bold 22px sans-serif";
  ctx.fillText("糖", 0, 3);

  ctx.restore();
}
```

#### 锅/炖煮

```javascript
function drawPot(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 锅体 - 深色渐变
  const potGrad = ctx.createLinearGradient(0, -20, 0, 30);
  potGrad.addColorStop(0, "#深灰");
  potGrad.addColorStop(1, "#更深的灰");
  ctx.fillStyle = potGrad;
  ctx.strokeStyle = "#轮廓色";
  ctx.lineWidth = 5;

  // 锅身
  ctx.beginPath();
  ctx.ellipse(0, 28, 52, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-52, 28);
  ctx.lineTo(-45, -15);
  ctx.quadraticCurveTo(0, -28, 45, -15);
  ctx.lineTo(52, 28);
  ctx.closePath();
  ctx.fill();

  // 锅中汤汁 - 红色
  ctx.fillStyle = "#红烧色";
  ctx.beginPath();
  ctx.ellipse(0, 5, 38, 25, 0, 0, Math.PI * 2);
  ctx.fill();

  // 蒸汽
  ctx.strokeStyle = "#浅色";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-10, -10);
  ctx.quadraticCurveTo(-15, -30, -8, -40);
  ctx.stroke();

  ctx.restore();
}
```

## 颜色配置参考

### 根据菜品类型调整色调

| 菜品类型  | 背景浅色 | 背景深色 | 标题栏浅色 | 标题栏深色 | 主色调特点 |
| --------- | -------- | -------- | ---------- | ---------- | ---------- |
| 青椒肉丝  | #FFF8E7  | #FFE4C4  | #FF9AA2    | #E87F87    | 清新绿色系 |
| 红烧肉    | #FDF2E9  | #FDEBD0  | #E74C3C    | #C0392B    | 浓郁红色系 |
| 糖醋排骨  | #FFF5E6  | #FFE8CC  | #F39C12    | #D68910    | 酸甜橙黄系 |
| 清炒时蔬  | #F0F8E8  | #E8F5D6  | #A8D8B8    | #7DC9A1    | 清爽绿色系 |
| 海鲜类    | #E8F4F8  | #D6EAF8  | #5DADE2    | #3498DB    | 海洋蓝色系 |
| 炒饭/主食 | #FFFEF0  | #FFF8DC  | #F7DC6F    | #F4D03F    | 温暖金黄系 |

### 食材配色（吉卜力风格）

| 元素   | 浅色    | 深色    | 用途     |
| ------ | ------- | ------- | -------- |
| 青椒   | #A8E6CF | #56AB91 | 蔬菜     |
| 猪肉   | #FFB7B2 | #E57A76 | 肉类     |
| 牛肉   | #D7BDE2 | #AF7AC5 | 肉类     |
| 糖     | #FFF5BA | #F0D475 | 调料     |
| 锅     | #B8C5D6 | #8A9AAF | 烹饪     |
| 背景   | #FFF8E7 | #FFE4C4 | 温暖米色 |
| 标题栏 | #FF9AA2 | #E87F87 | 柔和粉红 |

## 步骤颜色分配

每个步骤应使用不同颜色，建议按顺序使用：

1. #E74C3C (红色)
2. #F39C12 (橙黄)
3. #9B59B6 (紫色)
4. #3498DB (蓝色)
5. #27AE60 (绿色)
6. #D4AC0D (金色)
7. #E67E22 (橙色)
8. #16A085 (青绿)

## 食材图形绘制示例

### 写实青椒

```javascript
function drawGreenPepper(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  // 不规则果形轮廓
  ctx.strokeStyle = "#1A5D3A";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-5, -40);
  ctx.quadraticCurveTo(15, -20, 5, 15);
  ctx.quadraticCurveTo(-10, 35, -25, 25);
  ctx.quadraticCurveTo(-35, 0, -20, -30);
  ctx.quadraticCurveTo(-10, -38, -5, -40);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // 立体渐变填充
  const grad = ctx.createRadialGradient(-10, -15, 0, 0, 0, 50);
  grad.addColorStop(0, "#58D68D");
  grad.addColorStop(0.5, "#2ECC71");
  grad.addColorStop(1, "#1E8449");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(-5, -40);
  ctx.quadraticCurveTo(15, -20, 5, 15);
  ctx.quadraticCurveTo(-10, 35, -25, 25);
  ctx.quadraticCurveTo(-35, 0, -20, -30);
  ctx.quadraticCurveTo(-10, -38, -5, -40);
  ctx.closePath();
  ctx.fill();

  // 果籽细节
  ctx.fillStyle = "#F9E79F";
  ctx.beginPath();
  ctx.ellipse(-8, 10, 12, 8, 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(0, -5, 10, 6, -0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-15, -20, 8, 5, 0.1, 0, Math.PI * 2);
  ctx.fill();

  // 叶脉纹理
  ctx.fillStyle = "#F5F5F5";
  ctx.beginPath();
  ctx.moveTo(-15, 5);
  ctx.lineTo(-12, 25);
  ctx.strokeStyle = "#D5D8DC";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-10, 0);
  ctx.lineTo(-8, 20);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-5, -10);
  ctx.lineTo(-3, 10);
  ctx.stroke();

  // 凹痕纹理
  ctx.strokeStyle = "#1E8449";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-10, -38);
  ctx.lineTo(-15, -25);
  ctx.lineTo(-20, 5);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-5, -30);
  ctx.lineTo(5, -10);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -20);
  ctx.lineTo(8, 0);
  ctx.stroke();

  // 高光
  ctx.fillStyle = "rgba(255,255,255,0.4)";
  ctx.beginPath();
  ctx.ellipse(-18, -15, 6, 12, -0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-10, 5, 4, 8, -0.2, 0, Math.PI * 2);
  ctx.fill();

  // 果柄和果萼
  ctx.fillStyle = "#5D6D7E";
  ctx.beginPath();
  ctx.moveTo(-10, -42);
  ctx.lineTo(-6, -38);
  ctx.lineTo(-8, -32);
  ctx.lineTo(-12, -35);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}
```

### 蒜瓣

```javascript
function drawGarlic(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  for (let i = 0; i < 3; i++) {
    const gx = (i - 1) * 18;
    const grad = ctx.createLinearGradient(gx - 10, 0, gx + 10, 0);
    grad.addColorStop(0, "#FDFEFE");
    grad.addColorStop(0.5, "#FEF9E7");
    grad.addColorStop(1, "#F5EEF8");
    ctx.fillStyle = grad;
    ctx.strokeStyle = "#D7BDE2";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(gx, 0, 12, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 蒜蒂
    ctx.strokeStyle = "#A569BD";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(gx, -18);
    ctx.lineTo(gx, -35);
    ctx.stroke();
  }

  ctx.restore();
}
```

### 生抽酱油瓶

```javascript
function drawSoySauce(x, y, s) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s / 100, s / 100);

  const grad = ctx.createLinearGradient(-25, 0, 25, 0);
  grad.addColorStop(0, "#5D4037");
  grad.addColorStop(0.5, "#795548");
  grad.addColorStop(1, "#4E342E");
  ctx.fillStyle = grad;
  ctx.strokeStyle = "#3E2723";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(-25, -35, 50, 70, 5);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#8D6E63";
  ctx.beginPath();
  ctx.roundRect(-20, -30, 40, 10, 2);
  ctx.fill();

  ctx.fillStyle = "#3E2723";
  ctx.font = "bold 10px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("生抽", 0, -23);

  // 高光
  ctx.fillStyle = "rgba(255,255,255,0.3)";
  ctx.beginPath();
  ctx.ellipse(-12, -10, 4, 15, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}
```

## 常见问题解决

**问题：标题被遮挡**
解决：将centerY向下偏移50-60像素

**问题：图形与文字重叠**
解决：减小图形尺寸(scale值改为60-70)，调整y坐标(改为y - 10)

**问题：食材不够写实**
解决：添加渐变、高光、阴影；使用radialGradient增加立体感
