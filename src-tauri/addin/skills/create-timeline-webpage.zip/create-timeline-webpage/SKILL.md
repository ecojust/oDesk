---
name: create-timeline-webpage
description: 从唐宋文学编年地图(cnkgraph.com)等网站抓取诗人词人的生平数据，生成精美的可视化时间线网页，并支持一键导出高清PNG图片。当用户需要了解某位诗人（如李白、杜甫、苏轼等）的生平经历，或需要生成诗人的编年史网页时使用此技能。
---

# Create Timeline Webpage

从唐宋文学编年地图等网站采集诗人词人生平数据，创建可视化时间线网页。

## 工作流

### 1. 数据采集

使用 `WebFetch` 工具从唐宋文学编年地图获取诗人数据：

```bash
# 获取诗人列表页
webfetch https://cnkgraph.com/People --format markdown

# 获取具体诗人生平数据
webfetch https://cnkgraph.com/People/唐（含五代十国）/李白/15188 --format markdown

# 获取诗人行迹地图
webfetch https://cnkgraph.com/Map/PoetLife?author=李白 --format markdown
```

解析返回的数据，提取关键信息点，按时间顺序组织。

**重要：** 同时采集该诗人在各时期创作的代表诗词作品，在时间线对应节点展示。

### 2. 创建 HTML 网页

在当前工作目录创建 `timeline.html` 文件，包含：

**必需部分：**

- 响应式布局（max-width + 移动端适配）
- 时间线 CSS 样式（居中轴线 + 交替卡片）
- 分章节展示内容
- 渐变色主题

**基础模板结构：**

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>标题</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;600;700&display=swap"
      rel="stylesheet"
    />
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      body {
        font-family: "Noto Serif SC", serif;
        background: linear-gradient(135deg, #1a1a2e, #16213e);
        min-height: 100vh;
        color: #e8e8e8;
      }
      .container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 20px;
      }
      header {
        text-align: center;
        padding: 60px 20px;
      }
      h1 {
        font-size: 3rem;
        background: linear-gradient(135deg, #ffd700, #ff6b6b);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .timeline-container {
        position: relative;
        padding: 40px 0;
      }
      .timeline-line {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        width: 3px;
        height: 100%;
        background: linear-gradient(180deg, #ffd700, #ff6b6b);
      }
      .timeline-item {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        position: relative;
        margin-bottom: 30px;
      }
      .timeline-dot {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        width: 16px;
        height: 16px;
        background: linear-gradient(135deg, #ffd700, #ff6b6b);
        border-radius: 50%;
        border: 3px solid #1a1a2e;
        z-index: 10;
      }
      .timeline-content {
        width: 42%;
        padding: 20px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 15px;
        border: 1px solid rgba(255, 255, 255, 0.1);
      }
      .timeline-item:nth-child(odd) .timeline-content {
        margin-right: auto;
        text-align: right;
      }
      .timeline-item:nth-child(even) .timeline-content {
        margin-left: auto;
      }
      .timeline-year {
        font-size: 1.5rem;
        background: linear-gradient(135deg, #ffd700, #ff6b6b);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .timeline-title {
        font-size: 1.1rem;
        color: #fff;
        margin-bottom: 8px;
      }
      .timeline-desc {
        font-size: 0.95rem;
        color: #b0b0b0;
        line-height: 1.6;
      }
      .timeline-poem {
        margin-top: 12px;
        padding: 12px;
        background: rgba(255, 215, 0, 0.1);
        border-radius: 8px;
        border-left: 3px solid #ffd700;
      }
      .timeline-poem-title {
        font-size: 1rem;
        color: #ffd700;
        font-weight: bold;
        margin-bottom: 6px;
      }
      .timeline-poem-line {
        font-size: 0.9rem;
        color: #e0e0e0;
        font-style: italic;
        line-height: 1.5;
      }
      @media (max-width: 768px) {
        .timeline-line,
        .timeline-dot {
          left: 20px;
        }
        .timeline-content {
          width: calc(100% - 50px) !important;
          margin-left: 50px !important;
          text-align: left !important;
        }
      }
    </style>
  </head>
  <body>
    <div class="container">
      <!-- 内容 -->
    </div>
  </body>
</html>
```

### 4. 添加诗词展示

在每个时间节点添加诗词内容，使用 `.timeline-poem` 元素：

```html
<div class="timeline-item">
  <div class="timeline-dot"></div>
  <div class="timeline-content">
    <div class="timeline-year">756年</div>
    <div class="timeline-title">被俘长安</div>
    <div class="timeline-desc">投奔灵武途中被叛军俘虏，押至长安。</div>
    <div class="timeline-poem">
      <div class="timeline-poem-title">《春望》</div>
      <div class="timeline-poem-line">
        国破山河在，城春草木深。<br />感时花溅泪，恨别鸟惊心。
      </div>
    </div>
  </div>
</div>
```

### 5. 二次校验（非常重要）

在完成 HTML 文件后，必须对诗词内容进行二次校验，确保准确性：

**校验清单：**

- [ ] 诗题名称是否正确（如《赠李白》vs《与李十二白同寻范十隐居》）
- [ ] 诗句文字是否正确（特别是古今异体字、通假字）
- [ ] 标点符号是否正确
- [ ] 作者归属是否正确
- [ ] 创作年份是否与生平对应

**校验方法：**
使用 `WebSearch` 工具搜索每首诗词的原文进行比对，特别注意：

- 常见别字：如"候景"应为"侯景"、"叩柴荆"应为"扣柴荆"
- 诗题准确性：确保使用完整的诗题名称
- 诗句完整性：检查是否有遗漏或错误拼接

**示例校验：**

```bash
# 校验杜甫《春望》
websearch "杜甫 春望 原文"

# 校验诗题
websearch "杜甫 与李十二白同寻范十隐居 原文"
```

### 6. 交付

1. 保存 HTML 文件
2. html名称以用户的需求诗歌作者命名

## 文件结构

```
skill/
├── SKILL.md
└── assets/
    └── timeline-template.html  # 可选：使用模板作为起点
```
