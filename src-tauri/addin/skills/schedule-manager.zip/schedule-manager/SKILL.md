---
name: schedule-manager
description: 员工排班管理系统,根据用户提供的人员，月份，班次生成符合规则的排班表
---

# Schedule Manager

员工排班管理系统。用于生成符合以下规则的排班方案：

- 10-30名员工轮班
- 支持任意数量班次（需自定义班次名称）
- 每周休息规则：7天休息2天，不足7天按 d/7\*2 四舍五入计算
- 最后一个班次后不能接第一个班次（如16点班后不接7点班）
- 每个班次至少1人
- 迭代生成直到满足所有约束

## 使用方法

运行排班脚本：

```bash
node scripts/generate-excel.js
```

## 用户输入参数

在脚本开头修改配置：

```javascript
const employees = Array.from({ length: 25 }, (_, i) => `员工${i + 1}`);

const SHIFTS = {
  SHIFT1: "7点班",
  SHIFT2: "10点班",
  SHIFT3: "14点班",
  SHIFT4: "16点班",
};

const SHIFT_TYPES = Object.values(SHIFTS);
const DAYS = 30; // 月天数
const MONTH = 4; // 月份
const MAX_ITERATIONS = 2000;
```

### 配置说明

- `employees`: 员工列表（可自定义名称）
- `SHIFTS`: 班次配置，键名任意，值为显示名称
- `DAYS`: 月天数（如4月30天，2月28/29天）
- `MONTH`: 月份数字
- `MAX_ITERATIONS`: 最大迭代次数

### 约束规则

1. **晚班后不接早班**: 默认最后定义的班次（如16点班）后，第二天不能接第一个班次（如7点班）
2. **每个班次至少1人**: 每天每个班次必须有至少1人值班
3. **周休息规则**: 每周休息天数 = round(工作天数/7 \* 2)

## 输出内容

- Excel文件：排班表、员工统计、周规则检查
- HTML预览文件：彩色示意图（各班次用不同颜色区分）
- 文件名格式：`排班表_{月份}_{人数}_{班次}点班.xlsx/html`
- 文件存放目录：当前工作区根目录
