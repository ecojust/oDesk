const puppeteer = require('puppeteer-core');

const CHROME_PATH = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';

async function launchBrowser(options = {}) {
  return puppeteer.launch({
    executablePath: CHROME_PATH,
    headless: options.headless ?? true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
}

async function searchSongs(searchKeyword, options = {}) {
  const browser = options.browser || await launchBrowser({ headless: options.headless });
  const shouldCloseBrowser = !options.browser;
  const page = options.page || await browser.newPage();
  const shouldClosePage = !options.page;

  try {
    return await searchSongsWithPage(page, searchKeyword, options);
  } finally {
    if (shouldClosePage) {
      await page.close().catch(() => {});
    }
    if (shouldCloseBrowser) {
      await browser.close();
    }
  }
}

async function searchSongsWithPage(page, searchKeyword, options = {}) {
  const limit = options.limit || 5;
  const encodedKeyword = encodeURIComponent(searchKeyword);
  const searchUrl = `https://www.gequbao.net/s/${encodedKeyword}`;

  await page.goto(searchUrl, { waitUntil: 'networkidle2', timeout: options.timeout || 30000 });

  const results = await page.$$eval('a[href]', (links, resultLimit) => {
    const normalize = text => (text || '').replace(/\s+/g, ' ').trim();
    const seen = new Set();

    return links
      .map(link => {
        const url = link.href;
        if (!url || !url.includes('search_music')) return null;

        const parsedUrl = new URL(url);
        const songId = parsedUrl.searchParams.get('song_id') || '';
        const queryTitle = parsedUrl.searchParams.get('title') || '';
        const singer = parsedUrl.searchParams.get('singer') || '';

        const container = link.closest('tr, li, article, section, .row, .item, .list-group-item, .media, div');
        const linkTitle = normalize(link.innerText || link.textContent);
        const title = queryTitle && singer ? `${queryTitle} - ${singer}` : linkTitle;
        const summary = normalize(container ? container.innerText : title);

        return {
          source: 'gequbao',
          songId,
          songTitle: queryTitle || linkTitle,
          singer,
          title,
          summary,
          url
        };
      })
      .filter(Boolean)
      .filter(result => {
        if (seen.has(result.url)) return false;
        seen.add(result.url);
        return true;
      })
      .slice(0, resultLimit);
  }, limit);

  return results.map((result, index) => ({
    index: index + 1,
    ...result
  }));
}

module.exports = {
  launchBrowser,
  searchSongs,
  searchSongsWithPage
};
