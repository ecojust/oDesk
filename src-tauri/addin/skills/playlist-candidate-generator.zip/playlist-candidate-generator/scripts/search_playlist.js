const fs = require('fs');
const { launchBrowser, searchSongsWithPage } = require('./gequbao_search.js');

const PLAYLIST_PATH = 'playlist_songs.json';
const SEARCH_LIMIT = Number.parseInt(process.argv[2] || '5', 10);

function buildSearchKeywords(song) {
  return [
    [song.title, song.artist].filter(Boolean).join(' '),
    song.title
  ].filter((keyword, index, keywords) => keyword && keywords.indexOf(keyword) === index);
}

function normalizeForMatch(value) {
  return (value || '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '');
}

function parseResultTitle(title) {
  const parts = (title || '').split(' - ');
  if (parts.length < 2) {
    return {
      title: title || '',
      artist: ''
    };
  }

  return {
    title: parts.slice(0, -1).join(' - '),
    artist: parts[parts.length - 1]
  };
}

function scoreResult(song, result) {
  const expectedTitle = normalizeForMatch(song.title);
  const expectedArtist = normalizeForMatch(song.artist);
  const fallbackParsed = parseResultTitle(result.title);
  const parsed = {
    title: result.songTitle || fallbackParsed.title,
    artist: result.singer || fallbackParsed.artist
  };
  const resultTitle = normalizeForMatch(parsed.title);
  const resultArtist = normalizeForMatch(parsed.artist);
  const resultText = normalizeForMatch(`${result.title} ${result.summary}`);
  let score = 0;

  if (resultTitle === expectedTitle) score += 300;
  else if (resultTitle.includes(expectedTitle)) score += 200;
  else if (resultText.includes(expectedTitle)) score += 120;

  if (expectedArtist && resultArtist === expectedArtist) score += 100;
  else if (expectedArtist && resultArtist.includes(expectedArtist)) score += 80;
  else if (expectedArtist && resultText.includes(expectedArtist)) score += 50;

  return score;
}

function mergeResults(song, resultsByKeyword, limit) {
  const seen = new Set();

  return resultsByKeyword
    .flat()
    .filter(result => {
      const dedupeKey = result.songId || `${result.songTitle || result.title}|${result.singer || result.summary}`;
      if (seen.has(dedupeKey)) return false;
      seen.add(dedupeKey);
      return true;
    })
    .map((result, originalIndex) => ({
      ...result,
      matchScore: scoreResult(song, result),
      originalIndex
    }))
    .sort((a, b) => b.matchScore - a.matchScore || a.originalIndex - b.originalIndex)
    .slice(0, limit)
    .map(({ originalIndex, ...result }, index) => ({
      ...result,
      index: index + 1
    }));
}

async function main() {
  if (!fs.existsSync(PLAYLIST_PATH)) {
    console.error(`错误: 未找到 ${PLAYLIST_PATH} 文件`);
    process.exit(1);
  }

  const songs = JSON.parse(fs.readFileSync(PLAYLIST_PATH, 'utf8'));
  if (!Array.isArray(songs) || songs.length === 0) {
    console.error('错误: playlist_songs.json 中没有歌曲数据');
    process.exit(1);
  }

  console.log(`开始为 ${songs.length} 首歌曲搜索候选结果，每首最多 ${SEARCH_LIMIT} 条。\n`);

  const browser = await launchBrowser({ headless: true });
  const page = await browser.newPage();

  try {
    for (let i = 0; i < songs.length; i++) {
      const song = songs[i];
      const keywords = buildSearchKeywords(song);
      console.log(`[${i + 1}/${songs.length}] 搜索: ${keywords.join(' / ')}`);

      song.searchKeyword = keywords[0];
      song.searchKeywords = keywords;
      song.searchSource = 'gequbao';
      song.searchUpdatedAt = new Date().toISOString();

      try {
        const resultsByKeyword = [];
        for (const keyword of keywords) {
          const results = await searchSongsWithPage(page, keyword, { limit: SEARCH_LIMIT });
          resultsByKeyword.push(results.map(result => ({
            ...result,
            searchKeyword: keyword
          })));
          await new Promise(resolve => setTimeout(resolve, 800));
        }

        song.searchResults = mergeResults(song, resultsByKeyword, SEARCH_LIMIT);
        delete song.searchError;
        console.log(`  找到 ${song.searchResults.length} 条候选`);
      } catch (error) {
        song.searchResults = [];
        song.searchError = error.message;
        console.error(`  搜索失败: ${error.message}`);
      }

      fs.writeFileSync(PLAYLIST_PATH, JSON.stringify(songs, null, 2) + '\n', 'utf8');
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
  } finally {
    await page.close().catch(() => {});
    await browser.close();
  }

  console.log(`\n搜索完成，结果已合并到 ${PLAYLIST_PATH}`);
}

main().catch(error => {
  console.error('错误:', error.message);
  process.exit(1);
});
