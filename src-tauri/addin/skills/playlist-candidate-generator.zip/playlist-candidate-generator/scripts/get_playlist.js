const https = require('https');
const fs = require('fs');

function getPlaylist(playlistId) {
  return new Promise((resolve, reject) => {
    const url = `https://music.163.com/api/v6/playlist/detail?id=${playlistId}`;

    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'Referer': 'https://music.163.com/'
      }
    };

    https.get(url, options, res => {
      let data = '';
      res.on('data', chunk => {
        data += chunk;
      });
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.code === 200 && result.playlist && result.playlist.tracks) {
            const songs = result.playlist.tracks.map((track, index) => ({
              index: index + 1,
              title: track.name,
              artist: track.ar ? track.ar.map(a => a.name).join(', ') : '未知',
              id: track.id,
              album: track.al ? track.al.name : '未知'
            }));
            resolve(songs);
          } else {
            reject(new Error('获取歌单失败: ' + (result.message || '未知错误')));
          }
        } catch (error) {
          reject(error);
        }
      });
    }).on('error', reject);
  });
}

const playlistId = process.argv[2];

if (!playlistId) {
  console.error('错误: 请提供歌单ID');
  console.log('使用方法: node get_playlist.js <歌单ID>');
  console.log('示例: node get_playlist.js 10164673774');
  process.exit(1);
}

console.log(`正在获取歌单 ${playlistId} 的歌曲列表...\n`);

getPlaylist(playlistId)
  .then(songs => {
    console.log(`歌单共有 ${songs.length} 首歌曲:\n`);
    songs.forEach(song => {
      console.log(`${song.index}. ${song.title} - ${song.artist}`);
    });

    fs.writeFileSync('playlist_songs.json', JSON.stringify(songs, null, 2) + '\n', 'utf8');
    console.log('\n歌曲列表已保存到 playlist_songs.json');
  })
  .catch(error => {
    console.error('错误:', error.message);
    process.exit(1);
  });
