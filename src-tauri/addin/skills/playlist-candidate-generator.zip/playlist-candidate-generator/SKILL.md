---
name: playlist-candidate-generator
description: 为网易云音乐歌单生成可选择的歌曲下载候选。用户要求获取歌单、生成歌曲候选、搜索 playlist_songs 的 searchResults、先不要下载歌曲、让用户选择下载哪一首时，必须使用此 skill。此 skill 只获取歌单和搜索候选，写入 playlist_songs.json，不下载 MP3 或歌词。
---

# 网易云歌单候选生成工具

从网易云音乐歌单获取歌曲列表，然后为每首歌在歌曲宝搜索候选版本，合并写入 `playlist_songs.json` 的 `searchResults`。这个 skill 只负责生成候选，不下载歌曲。

## 依赖安装

首次使用需要在项目根目录安装依赖：

```bash
npm install puppeteer-core
```

需要 Google Chrome 浏览器：

```text
/Applications/Google Chrome.app
```

## 使用流程

### 1. 获取歌单歌曲列表

```bash
node .opencode/skill/playlist-candidate-generator/scripts/get_playlist.js <歌单ID>
```

示例：

```bash
node .opencode/skill/playlist-candidate-generator/scripts/get_playlist.js 10164673774
```

输出：

- 在终端显示歌单所有歌曲
- 生成 `playlist_songs.json`

### 2. 生成歌曲候选

```bash
node .opencode/skill/playlist-candidate-generator/scripts/search_playlist.js
```

可选参数：

- `每首歌候选数`：默认 5，例如：

```bash
node .opencode/skill/playlist-candidate-generator/scripts/search_playlist.js 8
```

输出：

- 为每首歌增加 `searchKeyword`、`searchKeywords`、`searchSource`、`searchUpdatedAt`、`searchResults`
- 每个候选包含 `songId`、`songTitle`、`singer`、`title`、`summary`、`url`、`matchScore`
- 不会下载 MP3 或歌词

## 用户选择格式

生成候选后，让用户在 `playlist_songs.json` 中为想下载的候选添加：

```json
"download": true
```

示例：

```json
{
  "index": 1,
  "source": "gequbao",
  "songId": "560262209",
  "songTitle": "明月高悬不照我",
  "singer": "树离suliii_",
  "title": "明月高悬不照我 - 树离suliii_",
  "url": "https://www.gequbao.net/search_music?...",
  "matchScore": 400,
  "download": true
}
```

## 后续下载

如果用户要求下载已选择的歌曲，切换使用 `playlist-downloader` skill。下载 skill 只会处理 `searchResults[].download === true` 的候选。

## 文件结构

```text
.opencode/skill/playlist-candidate-generator/
├── SKILL.md
├── package.json
└── scripts/
    ├── get_playlist.js
    ├── search_playlist.js
    └── gequbao_search.js
```
