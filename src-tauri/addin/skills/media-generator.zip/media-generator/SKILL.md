---
name: media-generator
description: Generate TTS voice narration and cover images, then combine into video. Use this skill when user wants to generate video content with voiceover, like poem recitation, story narration, or any multimedia content.
---

# Media Generator

Generate cover images, TTS voice narration, and combine into video.

## Project Structure

```
workspace/
├── config.json            # Configuration (title, text, voice, thumb)
├── content.txt            # Long text content to narrate
├── thumb.png              # User-provided background image (optional)
├── output/
│   └── video.mp4         # Final video
│
└── .opencode/skill/media-generator/
    ├── SKILL.md
    ├── scripts/
    │   ├── main-multi-frame.js  # Main generation script
    │   ├── ttsGenerator.js       # TTS generation
    │   ├── imageGenerator.js    # Image generation
    │   └── videoGenerator.js    # Video generation
    └── package.json
```

## Workflow

1. **Read config.json** from workspace root
2. **Read content.txt** from workspace root
3. **Create output/segments directory** (keep existing files)
4. **Split text by 句号 (。)、感叹号 (！)、问号 (？)**
5. **Check for existing segments** - skip if `.mp4` exists
6. **Generate intro segment** (title read)
7. **Generate N content segments** (one per sentence)
8. **Concatenate** intro + all content segments into final video

## Segment-by-Segment Generation

Each sentence is processed independently to generate a complete video segment:

```
For each sentence:
  1. Generate TTS audio (*.m4a)
  2. Generate image frame (*_frame.png)
  3. Combine into MP4 segment (*.mp4)
```

This approach:
- **Preserves all intermediate files** for progress tracking
- **Incremental generation** - skips existing `.mp4` files
- **Provides easy debugging** (inspect each segment)

## Dependencies

- **sharp**: Image processing
- **edge-tts-universal**: Text-to-speech (cross-platform Node.js)
- **fluent-ffmpeg**: Video/audio processing

## Usage

```bash
node scripts/main-multi-frame.js
```

### CLI overrides

```bash
node scripts/main-multi-frame.js --title="标题" --voice="zh-CN-XiaoxiaoNeural" --thumb="thumb.png"
```

### Arguments

| Argument  | Description                |
| --------- | -------------------------- |
| `--title` | Cover image / video title  |
| `--voice` | Voice name                 |
| `--thumb` | Background image path      |

## Configuration (config.json)

```json
{
  "title": "标题",
  "voice": "zh-CN-XiaoxiaoNeural",
  "thumb": "thumb.png"
}
```

| Field   | Description                |
| -------- | -------------------------- |
| `title`  | Cover image / video title  |
| `voice`  | Voice name                 |
| `thumb`  | Background image (optional)|
| `progress` | Progress object (auto-updated) |

## Content (content.txt)

Long text content, one or more sentences separated by 句号 (。):

```
人这一辈子，要学会做好三件事。第一件，照顾好自己的身体。第二件，善待自己的心。第三件，做自己想做的事。
```

## Available Voices

### Chinese
- `zh-CN-XiaoxiaoNeural` (女声，推荐)
- `zh-CN-YunxiNeural` (男声)
- `zh-CN-YunyangNeural` (男声)

### English
- `en-US-JennyNeural` (女声)
- `en-US-GuyNeural` (男声)

## Output

```
output/
├── video.mp4                   # Final merged video
├── concat.txt                  # FFmpeg concat list
├── frames/                     # Image frames (PNG)
│   ├── intro_frame.png
│   └── sentence_xxxx_frame.png
├── audio/                      # TTS audio files (M4A)
│   ├── intro.m4a
│   └── sentence_xxxx.m4a
└── videos/                     # Video segments (MP4)
    ├── intro.mp4
    └── sentence_xxxx.mp4
```

### Progress Tracking
All intermediate files are preserved in separate folders:
- Check `audio/*.m4a` for TTS generation progress
- Check `frames/*_frame.png` for image generation progress
- Check `videos/*.mp4` for video segment generation progress
- Check `config.json` progress field for real-time status

### Real-time Progress in config.json
During generation, progress is automatically updated in `config.json`:

```json
{
  "title": "湖南农民运动考察报告（一）",
  "voice": "zh-CN-XiaoxiaoNeural",
  "thumb": "thumb.png",
  "progress": {
    "current": 15,
    "total": 29,
    "percentage": 52,
    "status": "processing",
    "lastUpdated": "2026-04-09T03:35:00.000Z"
  }
}
```

| Field | Description |
| ------|-------------|
| `current` | Number of segments completed |
| `total` | Total number of segments (intro + sentences) |
| `percentage` | Progress percentage |
| `status` | `starting`, `processing`, or `completed` |
| `lastUpdated` | ISO timestamp of last update |

## Examples

### 人生哲理口播
```bash
node scripts/main-multi-frame.js --title="人生三件事" --voice="zh-CN-YunxiNeural"
```

### 诗句朗读
```bash
node scripts/main-multi-frame.js --title="静夜思" --voice="zh-CN-XiaoxiaoNeural"
```

## Key Features

### 1. Sentence Splitting
Splits text by:
- 句号 (。)
- 感叹号 (！)
- 问号 (？)

### 2. Per-Sentence Video Generation
- Each sentence generates:
  - TTS audio file
  - Image frame
  - MP4 video segment
- Intro segment reads the title

### 3. Style Detection
Detects visual style based on content keywords:
- **moonlight**: 月、夜、思、故乡
- **grassland**: 草、离离、原、野火、春风
- **mountain**: 山、水、江、河
- **life**: 身体、健康、心、烦恼、人生
- **poetry**: 唐、宋、诗、词
- **maoxian**: 毛选、毛泽东、革命、阶级、无产阶级、资产阶级、帝国主义、军阀、共产党、国民党、农民、工人、地主
- **default**: other content (forced to maoxian)

### 4. Audio-Visual Sync
- Each segment's video duration matches its audio duration
- Segments concatenated in order

### 5. Incremental Generation
- If video segment (`.mp4`) exists, skip entire generation
- Only regenerate missing files
- Allows resuming after interruption

### 6. Text Wrapping
- Splits text by punctuation (，。！？；、：)
- No truncation - all content displayed
- Font size dynamically adjusted per line based on character count:
  - ≤10 chars: 100%
  - ≤15 chars: 85%
  - ≤20 chars: 70%
  - ≤30 chars: 60%
  - ≤40 chars: 50%
  - >40 chars: 40%

### 7. Maoxian Style (Default for Long-form Content)
For content like 毛泽东选集, revolutionary articles:
- **Background**: Deep red gradient (#8B0000)
- **Icon**: Golden hammer and sickle (🔨⚔️) centered at top
- **Text**: Gold color (#FFD700)
- Applied to all segments when no specific style matches (forced maoxian)
- Concurrent processing based on CPU cores
- Default: `Math.max(2, Math.min(cpuCores, 8))`
- Batch processing for stability

### 8. User Background Image
- If `thumb` field is provided in config.json or CLI, use user-provided image as background
- Background image is scaled to cover 1080x1920 using `cover` fit mode
- Text overlay is composited on top of the background
- Text color is gold (#FFD700) for visibility

### 9. Cross-Platform
- No OS-specific commands
- Uses Node.js libraries: edge-tts-universal, fluent-ffmpeg, sharp

## User Background Image

When a user provides their own background image (`thumb` field), the generator:

1. **Resizes** the image to 1080x1920 using `cover` mode (center crop)
2. **Composites** the text overlay on top
3. **Text** is rendered in gold (#FFD700) for visibility against most backgrounds

The background image can be in any format supported by sharp (PNG, JPG, WEBP, etc.).

### Thumb Path Format

The `thumb` field supports both:
- **Relative path**: `thumb.png` (relative to workspace root)
- **Absolute path**: `/Users/juzisang/workspace/thumb.png`

## Important Notes

### Input Priority
1. CLI arguments (--title, --text, --voice, --thumb)
2. config.json fields
3. content.txt (for text)
4. Default values

### Video Resolution
- 1080 x 1920 (vertical/portrait)

### Performance
- Uses `-tune stillimage` for faster image-to-video encoding
- Parallel generation: 8 concurrent tasks
- Tested with 104 sentences (~14 min video, ~3 min generation time)
