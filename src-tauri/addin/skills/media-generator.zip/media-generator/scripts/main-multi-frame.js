import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.join(__dirname, '../../../..');

const configPath = path.join(rootDir, 'config.json');
const contentPath = path.join(rootDir, 'content.txt');

function updateProgress(current, total, status) {
  const progressData = {
    current,
    total,
    percentage: Math.round((current / total) * 100),
    status,
    lastUpdated: new Date().toISOString()
  };
  const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  config.progress = progressData;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

const config = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, 'utf-8')) : {};
let textFromFile = '';
if (fs.existsSync(contentPath)) {
  textFromFile = fs.readFileSync(contentPath, 'utf-8').trim();
}

const cliArgs = {};
for (const arg of process.argv.slice(2)) {
  if (arg.startsWith('--')) {
    const [key, value] = arg.slice(2).split('=');
    cliArgs[key] = value;
  }
}

const title = cliArgs.title || config.title;
const text = cliArgs.text || textFromFile || config.text;
const voice = cliArgs.voice || config.voice || 'zh-CN-XiaoxiaoNeural';
const userThumb = cliArgs.thumb || config.thumb || null;
const showText = cliArgs.showtext ?? config.showtext ?? true;
const textColor = cliArgs.textcolor || config.textcolor || '#FFD700';
let userBackground = null;
if (userThumb) {
  if (path.isAbsolute(userThumb)) {
    userBackground = userThumb;
  } else {
    userBackground = path.join(rootDir, userThumb);
  }
}

function splitSentences(text) {
  const sentences = [];
  let currentSentence = '';
  
  for (const char of text) {
    currentSentence += char;
    if (char === '。' || char === '！' || char === '？') {
      const trimmed = currentSentence.trim();
      if (trimmed && trimmed.length > 1) {
        sentences.push(trimmed);
      }
      currentSentence = '';
    }
  }
  
  const trimmed = currentSentence.trim();
  if (trimmed && trimmed.length > 1) {
    sentences.push(trimmed);
  }
  
  return sentences;
}

function detectPoemStyle(title, text) {
  const combined = (title + text).toLowerCase();
  
  if (combined.includes('月') || combined.includes('夜') || combined.includes('思') || combined.includes('故乡')) {
    return 'moonlight';
  }
  if (combined.includes('草') || combined.includes('离离') || combined.includes('原') || combined.includes('野火') || combined.includes('春风')) {
    return 'grassland';
  }
  if (combined.includes('山') || combined.includes('水') || combined.includes('江') || combined.includes('河')) {
    return 'mountain';
  }
  if (combined.includes('身体') || combined.includes('健康') || combined.includes('心') || combined.includes('烦恼') || combined.includes('放下') || combined.includes('人生') || combined.includes('想做的事') || combined.includes('明天')) {
    return 'life';
  }
  if (combined.includes('唐') || combined.includes('宋') || combined.includes('诗') || combined.includes('词')) {
    return 'poetry';
  }
  if (combined.includes('毛选') || combined.includes('毛泽东') || combined.includes('革命') || combined.includes('阶级') || combined.includes('无产阶级') || combined.includes('资产阶级') || combined.includes('帝国主义') || combined.includes('军阀') || combined.includes('共产党') || combined.includes('国民党') || combined.includes('农民') || combined.includes('工人') || combined.includes('地主')) {
    return 'maoxian';
  }
  return 'default';
}

async function getAudioDuration(audioPath) {
  try {
    const { stdout } = await execAsync(`ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`);
    return parseFloat(stdout.trim());
  } catch (err) {
    return 10;
  }
}

async function main() {
  const startTime = Date.now();
  
  const TTSGenerator = (await import('./ttsGenerator.js')).default;
  const ImageGenerator = (await import('./imageGenerator.js')).default;
  const VideoGenerator = (await import('./videoGenerator.js')).default;

  const outputDir = path.join(rootDir, 'output');
  const framesDir = path.join(outputDir, 'frames');
  const audioDir = path.join(outputDir, 'audio');
  const videosDir = path.join(outputDir, 'videos');
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  [framesDir, audioDir, videosDir].forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });

  const ttsGen = new TTSGenerator({ outputDir });
  const imageGen = new ImageGenerator({ outputDir });
  const videoGen = new VideoGenerator({ outputDir });

  try {
    console.log(`\n📖 Generating: "${title}"\n`);
    
    const sentences = splitSentences(text);
    console.log(`📝 Total sentences: ${sentences.length}\n`);
    
    const totalSegments = sentences.length + 1;
    updateProgress(0, totalSegments, 'starting');
    
    let poemStyle = detectPoemStyle(title, text);
    if (poemStyle === 'default') {
      poemStyle = 'maoxian';
    }
    
    function fileExists(p) {
      return fs.existsSync(p);
    }
    
    console.log(`🎬 Generating intro segment...`);
    const introAudioPath = fileExists(path.join(audioDir, 'intro.m4a'))
      ? path.join(audioDir, 'intro.m4a')
      : await ttsGen.generate(title, { voice, outputPath: path.join(audioDir, 'intro.m4a') });
    const introImagePath = fileExists(path.join(framesDir, 'intro_frame.png'))
      ? path.join(framesDir, 'intro_frame.png')
      : await imageGen.generatePoemFrame({
          title: title,
          text: title,
          author: '',
          poemStyle: poemStyle,
          style: 'title',
          frameIndex: 0,
          width: 1080,
          height: 1920,
          outputPath: path.join(framesDir, 'intro_frame.png'),
          userBackground,
          showText,
          textColor
        });
    const introSegmentPath = fileExists(path.join(videosDir, 'intro.mp4'))
      ? path.join(videosDir, 'intro.mp4')
      : await videoGen.generate(introImagePath, introAudioPath, path.join(videosDir, 'intro.mp4'));
    console.log(`  ✔ Intro segment: ${path.basename(introSegmentPath)}\n`);
    
    const segmentPaths = [introSegmentPath];
    
    console.log(`🎬 Generating ${sentences.length} content segments...`);
    
    const os = await import('os');
    const MAX_CONCURRENCY = 2;
    let completed = 0;
    const results = new Array(sentences.length).fill(null);
    
    const processSentence = async (i) => {
      const sentence = sentences[i];
      const idx = String(i).padStart(4, '0');
      const audioPath = path.join(audioDir, `sentence_${idx}.m4a`);
      const imagePath = path.join(framesDir, `sentence_${idx}_frame.png`);
      const videoPath = path.join(videosDir, `sentence_${idx}.mp4`);
      
      if (fileExists(videoPath)) {
        results[i] = videoPath;
        return;
      }
      
      const sentenceAudioPath = fileExists(audioPath)
        ? audioPath
        : await ttsGen.generate(sentence, { voice, outputPath: audioPath });
      const sentenceImagePath = fileExists(imagePath)
        ? imagePath
        : await imageGen.generatePoemFrame({
            title: title,
            text: sentence,
            author: '',
            poemStyle: poemStyle,
            style: 'default',
            frameIndex: i,
            width: 1080,
            height: 1920,
            outputPath: imagePath,
            userBackground,
            showText,
            textColor
          });
      
      const sentenceSegmentPath = await videoGen.generate(sentenceImagePath, sentenceAudioPath, videoPath);
      results[i] = sentenceSegmentPath;
    };
    
    const runBatch = async (start, end) => {
      await Promise.all(
        Array.from({ length: end - start }, (_, offset) => processSentence(start + offset))
      );
    };
    
    for (let i = 0; i < sentences.length; i += MAX_CONCURRENCY) {
      const batchEnd = Math.min(i + MAX_CONCURRENCY, sentences.length);
      await runBatch(i, batchEnd);
      completed = batchEnd;
      const progress = Math.round((completed / sentences.length) * 100);
      updateProgress(completed + 1, totalSegments, 'processing');
      console.log(`  Progress: ${completed}/${sentences.length} (${progress}%)`);
    }
    
    for (const p of results) {
      if (p) segmentPaths.push(p);
    }
    
    console.log(`\n🔗 Concatenating ${segmentPaths.length} segments...`);
    const concatListPath = path.join(outputDir, 'concat.txt');
    let concatContent = segmentPaths.map(p => `file '${p}'`).join('\n');
    fs.writeFileSync(concatListPath, concatContent);
    
    const finalVideoPath = path.join(outputDir, 'video.mp4');
    
    const ffmpeg = await import('fluent-ffmpeg');
    await new Promise((resolve, reject) => {
      ffmpeg.default()
        .input(concatListPath)
        .inputOptions(['-f', 'concat', '-safe', '0'])
        .outputOptions(['-c:v', 'libx264', '-c:a', 'aac', '-pix_fmt', 'yuv420p'])
        .output(finalVideoPath)
        .on('end', resolve)
        .on('error', reject)
        .run();
    });
    
    console.log(`\n✅ Done!`);
    console.log(`   📄 ${segmentPaths.length} segments`);
    console.log(`   🎬 ${finalVideoPath}`);
    
    updateProgress(totalSegments, totalSegments, 'completed');
    
    const elapsed = Math.round((Date.now() - startTime) / 1000);
    const mins = Math.floor(elapsed / 60);
    const secs = elapsed % 60;
    console.log(`   ⏱️  Time: ${mins}m ${secs}s`);
  } catch (error) {
    console.error(`\n❌ Error: ${error.message}`);
    process.exit(1);
  }
}

main();
