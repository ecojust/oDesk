import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import sharp from 'sharp';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

class ImageGenerator {
  constructor(options = {}) {
    this.outputDir = options.outputDir || path.join(__dirname, '../../output');
    fs.mkdirSync(this.outputDir, { recursive: true });
  }

  async generate(prompt, options = {}) {
    const {
      width = 1080,
      height = 1920,
      backgroundColor = '#1a1a2e',
      textColor = '#ffffff',
      text = prompt,
      outputPath = null,
      animated = true,
    } = options;

    console.log(`- Creating image: "${prompt.substring(0, 30)}..."`);

    const filename = outputPath || `image_${Date.now()}.png`;
    const filepath = path.join(this.outputDir, path.basename(filename));

    if (animated) {
      const frameCount = 60;
      const prefix = `image_${Date.now()}`;
      for (let i = 0; i < frameCount; i++) {
        const framePath = path.join(this.outputDir, `${prefix}_${String(i).padStart(4, '0')}.png`);
        await this.createAnimatedFrame({
          text,
          width,
          height,
          backgroundColor,
          textColor,
          frameIndex: i,
          totalFrames: frameCount,
          outputPath: framePath,
        });
      }
      console.log(`✔ Animated frames saved: ${frameCount} frames`);
      return path.join(this.outputDir, `${prefix}_%04d.png`);
    } else {
      await this.createImage({
        text,
        width,
        height,
        backgroundColor,
        textColor,
        outputPath: filepath,
      });
      console.log(`✔ Image saved: ${filepath}`);
      return filepath;
    }
  }

  async createAnimatedFrame({ text, width, height, backgroundColor, textColor, frameIndex, totalFrames, outputPath }) {
    const isPoem = text.includes('床前') || text.includes('明月') || text.includes('思故乡') || text.includes('蜀道难') || text.includes('青天');
    const t = frameIndex / totalFrames;
    
    const cloudOffset1 = Math.sin(t * Math.PI * 2) * width * 0.1;
    const cloudOffset2 = Math.cos(t * Math.PI * 2) * width * 0.08;
    const moonGlow = 0.8 + Math.sin(t * Math.PI * 4) * 0.2;
    const starOpacity = 0.3 + Math.sin(t * Math.PI * 6 + 1) * 0.3;
    const mountainOffset = Math.sin(t * Math.PI * 0.5) * height * 0.02;
    
    let svg;
    if (isPoem) {
      svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="moonGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" style="stop-color:#fffacd;stop-opacity:${moonGlow}" />
              <stop offset="70%" style="stop-color:#f5f5dc;stop-opacity:${moonGlow * 0.3}" />
              <stop offset="100%" style="stop-color:#f5f5dc;stop-opacity:0" />
            </radialGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          <rect width="100%" height="100%" fill="#0a0a1a"/>
          
          <g opacity="${starOpacity}">
            <circle cx="${width * 0.1}" cy="${height * 0.1}" r="2" fill="#ffffff">
              <animate attributeName="opacity" values="0.3;1;0.3" dur="2s" repeatCount="indefinite"/>
            </circle>
            <circle cx="${width * 0.3}" cy="${height * 0.15}" r="1.5" fill="#ffffff"/>
            <circle cx="${width * 0.8}" cy="${height * 0.08}" r="2" fill="#ffffff"/>
            <circle cx="${width * 0.6}" cy="${height * 0.2}" r="1" fill="#ffffff"/>
            <circle cx="${width * 0.15}" cy="${height * 0.3}" r="1.5" fill="#ffffff"/>
            <circle cx="${width * 0.9}" cy="${height * 0.25}" r="1" fill="#ffffff"/>
            <circle cx="${width * 0.45}" cy="${height * 0.12}" r="1.5" fill="#ffffff"/>
            <circle cx="${width * 0.7}" cy="${height * 0.18}" r="1" fill="#ffffff"/>
          </g>
          
          <ellipse cx="${width * 0.7 + cloudOffset1}" cy="${height * 0.15}" rx="${width * 0.15}" ry="${height * 0.05}" fill="#ffffff" opacity="0.3" filter="url(#glow)"/>
          <ellipse cx="${width * 0.75 + cloudOffset1}" cy="${height * 0.12}" rx="${width * 0.1}" ry="${height * 0.03}" fill="#ffffff" opacity="0.2"/>
          
          <ellipse cx="${width * 0.25 + cloudOffset2}" cy="${height * 0.22}" rx="${width * 0.12}" ry="${height * 0.04}" fill="#ffffff" opacity="0.25"/>
          
          <circle cx="${width * 0.75}" cy="${height * 0.22}" r="${width * 0.12}" fill="url(#moonGlow)"/>
          <circle cx="${width * 0.75}" cy="${height * 0.22}" r="${width * 0.1}" fill="#fffacd" opacity="0.95"/>
          
          <path d="M0,${height * 0.65 + mountainOffset} Q${width * 0.15},${height * 0.55} ${width * 0.25},${height * 0.62} T${width * 0.5},${height * 0.6} T${width * 0.75},${height * 0.63} T${width},${height * 0.58} V${height} H0 Z" fill="#1a1a2e"/>
          <path d="M0,${height * 0.72 + mountainOffset * 0.5} Q${width * 0.2},${height * 0.65} ${width * 0.4},${height * 0.7} T${width * 0.7},${height * 0.68} T${width},${height * 0.65} V${height} H0 Z" fill="#252540"/>
          
          <text x="50%" y="${height * 0.45}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.055}" fill="#f4a460" text-anchor="middle" letter-spacing="4" filter="url(#glow)">蜀道难</text>
          
          <text x="50%" y="${height * 0.95}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.035}" fill="#d4a574" text-anchor="middle" opacity="0.8">【唐】李白</text>
        </svg>
      `;
    } else {
      svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style="stop-color:#87CEEB;stop-opacity:1" />
              <stop offset="50%" style="stop-color:#98FB98;stop-opacity:1" />
              <stop offset="100%" style="stop-color:#228B22;stop-opacity:1" />
            </linearGradient>
          </defs>
          
          <rect width="100%" height="100%" fill="url(#bg)"/>
          
          <ellipse cx="${width * 0.3 + cloudOffset1}" cy="${height * 0.15}" rx="${width * 0.12}" ry="${height * 0.06}" fill="#ffffff" opacity="0.9"/>
          <ellipse cx="${width * 0.75 + cloudOffset2}" cy="${height * 0.1}" rx="${width * 0.1}" ry="${height * 0.05}" fill="#ffffff" opacity="0.8"/>
          
          <path d="M0,${height * 0.6} Q${width * 0.2},${height * 0.55} ${width * 0.3},${height * 0.7} T${width * 0.6},${height * 0.65} T${width},${height * 0.7} V${height} H0 Z" fill="#8B4513" opacity="0.8"/>
          
          <circle cx="${width * 0.15}" cy="${height * 0.75}" r="${width * 0.03}" fill="#8B4513"/>
          <circle cx="${width * 0.25}" cy="${height * 0.72}" r="${width * 0.025}" fill="#A0522D"/>
          
          <ellipse cx="${width * 0.5}" cy="${height * 0.8}" rx="${width * 0.15}" ry="${height * 0.08}" fill="#DAA520" opacity="0.9"/>
          
          <text x="50%" y="${height * 0.45}" font-family="Comic Sans MS, cursive, sans-serif" font-size="${Math.min(width, height) * 0.1}" fill="#ffffff" text-anchor="middle" stroke="#333333" stroke-width="2">${this.escapeXml(text)}</text>
          
          <text x="50%" y="${height * 0.95}" font-family="Comic Sans MS, cursive, sans-serif" font-size="${Math.min(width, height) * 0.035}" fill="#ffffff" text-anchor="middle" opacity="0.9" stroke="#333333" stroke-width="1">动物世界</text>
        </svg>
      `;
    }

    await sharp(Buffer.from(svg)).png().toFile(outputPath);
  }

  async createImage({ text, width, height, backgroundColor, textColor, outputPath }) {
    const isPoem = text.includes('床前') || text.includes('明月') || text.includes('思故乡');
    
    let svg;
    if (isPoem) {
      svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style="stop-color:#1a1a2e;stop-opacity:1" />
              <stop offset="100%" style="stop-color:#16213e;stop-opacity:1" />
            </linearGradient>
          </defs>
          
          <rect width="100%" height="100%" fill="url(#bg)"/>
          
          <circle cx="${width * 0.7}" cy="${height * 0.25}" r="${width * 0.12}" fill="#f5f5dc" opacity="0.9"/>
          <circle cx="${width * 0.68}" cy="${height * 0.23}" r="${width * 0.11}" fill="#fffacd" opacity="0.5"/>
          
          <path d="M${width * 0.3},${height * 0.85} Q${width * 0.35},${height * 0.7} ${width * 0.4},${height * 0.65}" stroke="#333" stroke-width="3" fill="none" opacity="0.3"/>
          <path d="M${width * 0.4},${height * 0.65} Q${width * 0.45},${height * 0.5} ${width * 0.5},${height * 0.45}" stroke="#333" stroke-width="2" fill="none" opacity="0.2"/>
          <path d="M${width * 0.5},${height * 0.45} L${width * 0.55},${height * 0.4}" stroke="#333" stroke-width="2" fill="none" opacity="0.2"/>
          
          <text x="50%" y="${height * 0.35}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.08}" fill="#ffffff" text-anchor="middle" letter-spacing="8">${this.escapeXml(text)}</text>
          
          <text x="50%" y="${height * 0.95}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.04}" fill="#ffffff" text-anchor="middle" opacity="0.6">【唐】李白</text>
        </svg>
      `;
    } else {
      svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style="stop-color:#87CEEB;stop-opacity:1" />
              <stop offset="50%" style="stop-color:#98FB98;stop-opacity:1" />
              <stop offset="100%" style="stop-color:#228B22;stop-opacity:1" />
            </linearGradient>
            <filter id="sketch">
              <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="5" result="noise"/>
              <feDisplacementMap in="SourceGraphic" in2="noise" scale="3" />
            </filter>
            <clipPath id="cloudClip">
              <circle cx="${width * 0.3}" cy="${height * 0.15}" r="${width * 0.08}"/>
              <circle cx="${width * 0.35}" cy="${height * 0.13}" r="${width * 0.1}"/>
              <circle cx="${width * 0.4}" cy="${height * 0.15}" r="${width * 0.07}"/>
            </clipPath>
          </defs>
          
          <rect width="100%" height="100%" fill="url(#bg)"/>
          
          <ellipse cx="${width * 0.3}" cy="${height * 0.15}" rx="${width * 0.12}" ry="${height * 0.06}" fill="#ffffff" opacity="0.9"/>
          <ellipse cx="${width * 0.75}" cy="${height * 0.1}" rx="${width * 0.1}" ry="${height * 0.05}" fill="#ffffff" opacity="0.8"/>
          
          <path d="M0,${height * 0.6} Q${width * 0.2},${height * 0.55} ${width * 0.3},${height * 0.7} T${width * 0.6},${height * 0.65} T${width},${height * 0.7} V${height} H0 Z" fill="#8B4513" opacity="0.8"/>
          
          <circle cx="${width * 0.15}" cy="${height * 0.75}" r="${width * 0.03}" fill="#8B4513"/>
          <circle cx="${width * 0.25}" cy="${height * 0.72}" r="${width * 0.025}" fill="#A0522D"/>
          
          <ellipse cx="${width * 0.5}" cy="${height * 0.8}" rx="${width * 0.15}" ry="${height * 0.08}" fill="#DAA520" opacity="0.9"/>
          
          <circle cx="${width * 0.85}" cy="${height * 0.7}" r="${width * 0.04}" fill="#FF8C00" opacity="0.9"/>
          <circle cx="${width * 0.9}" cy="${height * 0.65}" r="${width * 0.03}" fill="#FFA500" opacity="0.8"/>
          <circle cx="${width * 0.8}" cy="${height * 0.68}" r="${width * 0.025}" fill="#FFD700" opacity="0.7"/>
          
          <g stroke="#ffffff" stroke-width="2" fill="none" opacity="0.3">
            <path d="M${width * 0.1},${height * 0.3} Q${width * 0.15},${height * 0.25} ${width * 0.2},${height * 0.3}"/>
            <path d="M${width * 0.7},${height * 0.4} Q${width * 0.75},${height * 0.35} ${width * 0.8},${height * 0.4}"/>
          </g>
          
          <text x="50%" y="${height * 0.45}" font-family="Comic Sans MS, cursive, sans-serif" font-size="${Math.min(width, height) * 0.1}" fill="#ffffff" text-anchor="middle" stroke="#333333" stroke-width="2" filter="url(#sketch)">${this.escapeXml(text)}</text>
          
          <text x="50%" y="${height * 0.95}" font-family="Comic Sans MS, cursive, sans-serif" font-size="${Math.min(width, height) * 0.035}" fill="#ffffff" text-anchor="middle" opacity="0.9" stroke="#333333" stroke-width="1">动物世界</text>
        </svg>
      `;
    }

    await sharp(Buffer.from(svg)).png().toFile(outputPath);
  }

  async generatePoemFrame(options) {
    const {
      title,
      text,
      author,
      style,
      frameIndex,
      width = 1080,
      height = 1920,
      outputPath,
      userBackground,
      showText = true,
      textColor = '#FFD700',
    } = options;

    console.log(`- Creating poem frame: "${text}"`);

    const filepath = outputPath || path.join(this.outputDir, `poem_frame_${Date.now()}.png`);

    if (userBackground && fs.existsSync(userBackground)) {
      const textSvg = this.createTextOnlySvg({
        title, text, author, style, frameIndex, width, height, poemStyle: style, showText, textColor
      });
      const textPath = path.join(this.outputDir, `temp_text_${Date.now()}.png`);
      await sharp(Buffer.from(textSvg)).png().toFile(textPath);

      try {
        await sharp(userBackground)
          .resize(width, height, { fit: 'cover', position: 'center' })
          .composite([{ input: textPath }])
          .png()
          .toFile(filepath);
      } finally {
        if (fs.existsSync(textPath)) {
          fs.unlinkSync(textPath);
        }
      }
      
      console.log(`  ✔ ${filepath}`);
      return filepath;
    }

    const svg = this.createPoemFrameSvg({
      title, text, author, style, frameIndex, width, height, poemStyle: style, showText, textColor
    });

    await sharp(Buffer.from(svg)).png().toFile(filepath);
    console.log(`  ✔ ${filepath}`);
    return filepath;
  }

  createTextOnlySvg({ title, text, author, style, frameIndex, width, height, poemStyle: passedPoemStyle, showText, textColor }) {
    const defaultTextColor = '#FFD700';
    const actualTextColor = textColor || defaultTextColor;
    const detectedStyle = style?.startsWith('grass') ? 'grassland' : 
                          style?.startsWith('moon') ? 'moonlight' : 
                          style?.startsWith('mountain') ? 'mountain' : 
                          style?.startsWith('life') ? 'life' : 'moonlight';
    const poemStyle = passedPoemStyle || detectedStyle;

    return `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="transparent"/>
      ${style === 'title' ? `
        <text x="50%" y="${height * 0.42}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.08}" fill="${showText ? actualTextColor : 'transparent'}" text-anchor="middle" letter-spacing="6">${showText ? this.escapeXml(title) : ''}</text>
      ` : `
        ${showText ? this.renderWrappedText(text, width * 0.5, height * 0.4, Math.min(width, height) * 0.055, Math.min(width, height) * 0.075, actualTextColor, actualTextColor, 0.5) : ''}
      `}
    </svg>`;
  }

  createPoemFrameSvg({ title, text, author, style, frameIndex, width, height, poemStyle: passedPoemStyle, userBackground, textOnly = false, showText = true, textColor = '#FFD700' }) {
    const detectedStyle = style?.startsWith('grass') ? 'grassland' : 
                          style?.startsWith('moon') ? 'moonlight' : 
                          style?.startsWith('mountain') ? 'mountain' : 
                          style?.startsWith('life') ? 'life' : 'moonlight';
    const poemStyle = passedPoemStyle || detectedStyle;

    const sceneConfigs = {
      moonlight: {
        title: {
          bgGradient: ['#0a0a1a', '#1a1a2e'],
          stars: true,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 1,
          extraText: null,
        },
        scene1: {
          bgGradient: ['#0d1117', '#1a1f2e'],
          stars: true,
          moon: true,
          moonX: 0.5,
          moonY: 0.3,
          mountain: true,
          mountainY: 0.6,
          grass: false,
          tree: false,
          person: false,
          frost: true,
          textOpacity: 0.9,
          extraText: '月光如水',
        },
        scene2: {
          bgGradient: ['#0a0f1a', '#151d2e'],
          stars: true,
          moon: true,
          moonX: 0.6,
          moonY: 0.25,
          mountain: true,
          mountainY: 0.65,
          grass: false,
          tree: false,
          person: false,
          frost: true,
          frostIntensity: 0.6,
          textOpacity: 0.85,
          extraText: '清冷如霜',
        },
        scene3: {
          bgGradient: ['#0f1520', '#1a2535'],
          stars: true,
          moon: true,
          moonX: 0.5,
          moonY: 0.2,
          moonSize: 0.14,
          mountain: true,
          mountainY: 0.7,
          grass: false,
          tree: true,
          person: true,
          personPose: 'looking_up',
          textOpacity: 0.85,
          extraText: '仰望明月',
        },
        scene4: {
          bgGradient: ['#121825', '#1e2840'],
          stars: true,
          moon: true,
          moonX: 0.75,
          moonY: 0.15,
          moonSize: 0.1,
          mountain: true,
          mountainY: 0.75,
          grass: false,
          tree: true,
          person: true,
          personPose: 'looking_down',
          textOpacity: 0.8,
          extraText: '思念故乡',
        },
      },
      grassland: {
        title: {
          bgGradient: ['#1a2f1a', '#2d4a2d'],
          stars: false,
          sun: true,
          sunX: 0.5,
          sunY: 0.15,
          mountain: false,
          grass: true,
          grassY: 0.5,
          tree: false,
          person: false,
          textOpacity: 1,
          extraText: '白居易',
        },
        scene1: {
          bgGradient: ['#2d4a2d', '#3d5c3d'],
          stars: false,
          sun: true,
          sunX: 0.3,
          sunY: 0.2,
          mountain: false,
          grass: true,
          grassY: 0.6,
          grassDensity: 0.8,
          grassHeight: 0.15,
          tree: false,
          person: false,
          textOpacity: 0.9,
          extraText: '草原辽阔',
        },
        scene2: {
          bgGradient: ['#3d3020', '#5c4030'],
          stars: false,
          sun: false,
          fire: true,
          mountain: false,
          grass: true,
          grassY: 0.65,
          grassDensity: 0.5,
          grassColor: '#4a3520',
          tree: false,
          person: false,
          textOpacity: 0.9,
          extraText: '野火燃烧',
        },
        scene3: {
          bgGradient: ['#2d4a2d', '#4a6a4a'],
          stars: false,
          sun: true,
          sunX: 0.7,
          sunY: 0.1,
          wind: true,
          mountain: false,
          grass: true,
          grassY: 0.55,
          grassDensity: 1.0,
          grassColor: '#5a8a4a',
          grassHeight: 0.2,
          tree: false,
          person: false,
          textOpacity: 0.9,
          extraText: '春风又生',
        },
        scene4: {
          bgGradient: ['#3d4a3d', '#5a6a5a'],
          stars: false,
          sun: true,
          sunX: 0.5,
          sunY: 0.25,
          mountain: false,
          grass: true,
          grassY: 0.5,
          grassDensity: 0.9,
          grassColor: '#6a8a5a',
          grassHeight: 0.18,
          tree: true,
          person: true,
          personPose: 'looking_away',
          textOpacity: 0.85,
          extraText: '送别友人',
        },
      },
      life: {
        title: {
          bgGradient: ['#1a2a3a', '#2d4a5a'],
          sun: true,
          sunX: 0.5,
          sunY: 0.15,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 1,
          extraText: null,
        },
        scene1: {
          bgGradient: ['#2a4a3a', '#3d5a4a'],
          sun: true,
          sunX: 0.5,
          sunY: 0.2,
          mountain: false,
          grass: true,
          grassY: 0.8,
          tree: false,
          person: true,
          personPose: 'exercise',
          textOpacity: 0.9,
          extraText: '照顾身体',
        },
        scene2: {
          bgGradient: ['#1a1a3a', '#2d2d4a'],
          stars: true,
          moon: true,
          moonX: 0.7,
          moonY: 0.2,
          mountain: false,
          grass: false,
          tree: false,
          person: true,
          personPose: 'meditate',
          textOpacity: 0.9,
          extraText: '善待内心',
        },
        scene3: {
          bgGradient: ['#2a3a4a', '#3d4d5a'],
          sun: true,
          sunX: 0.5,
          sunY: 0.15,
          mountain: false,
          grass: true,
          grassY: 0.7,
          tree: false,
          person: true,
          personPose: 'walking',
          textOpacity: 0.9,
          extraText: '做想做的事',
        },
        scene4: {
          bgGradient: ['#3a2a1a', '#5a4d2d'],
          sun: true,
          sunX: 0.7,
          sunY: 0.2,
          mountain: false,
          grass: true,
          grassY: 0.75,
          tree: false,
          person: true,
          personPose: 'looking_forward',
          textOpacity: 0.85,
          extraText: '别等明天',
        },
      },
      default: {
        title: {
          bgGradient: ['#1a1a2e', '#2d2d4a'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 1,
          extraText: null,
        },
        scene1: {
          bgGradient: ['#1e2530', '#2a3442'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 0.9,
          extraText: null,
        },
        scene2: {
          bgGradient: ['#1a2230', '#263340'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 0.85,
          extraText: null,
        },
        scene3: {
          bgGradient: ['#1f2835', '#2d3848'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 0.85,
          extraText: null,
        },
        scene4: {
          bgGradient: ['#19202a', '#252d3a'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          textOpacity: 0.8,
          extraText: null,
        },
      },
      maoxian: {
        title: {
          bgGradient: ['#8B0000', '#4a0000'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          hammerSickle: true,
          textOpacity: 1,
          extraText: null,
        },
        scene1: {
          bgGradient: ['#8B0000', '#5a0000'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          hammerSickle: true,
          textOpacity: 0.9,
          extraText: null,
        },
        scene2: {
          bgGradient: ['#7a0000', '#4a0000'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          hammerSickle: true,
          textOpacity: 0.85,
          extraText: null,
        },
        scene3: {
          bgGradient: ['#8B0000', '#550000'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          hammerSickle: true,
          textOpacity: 0.85,
          extraText: null,
        },
        scene4: {
          bgGradient: ['#7a0000', '#500000'],
          stars: false,
          moon: false,
          mountain: false,
          grass: false,
          tree: false,
          person: false,
          hammerSickle: true,
          textOpacity: 0.8,
          extraText: null,
        },
      },
    };

    const styleConfig = sceneConfigs[poemStyle] || sceneConfigs.default;
    const styleKey = style?.replace(/^(moonlight|grassland|mountain|life|maoxian)_/, '') || style || 'title';
    const scene = styleConfig[styleKey] || styleConfig.title;

    const gradientId = `bg_${Date.now()}`;
    const moonGlowId = `moonGlow_${Date.now()}`;
    const sunGlowId = `sunGlow_${Date.now()}`;
    const fireGlowId = `fireGlow_${Date.now()}`;
    const glowFilterId = `glow_${Date.now()}`;

    const bgGradient = scene.bgGradient;
    const starsSvg = this.renderStars(12, frameIndex);
    const mountainPath = this.generateMountainPath(width, height, scene.mountainY || 0.6, frameIndex);
    const grassSvg = this.renderGrass(width, height, scene, frameIndex);
    const sunSvg = this.renderSun(width, height, scene, sunGlowId);
    const fireSvg = this.renderFire(width, height, scene, fireGlowId);

    const isPoetryContent = poemStyle === 'poetry' || poemStyle === 'grassland' || poemStyle === 'moonlight';
    const authorText = (isPoetryContent && author) ? author : '';
    const poemName = poemStyle === 'grassland' ? '赋得古原草送别' : (isPoetryContent ? '静夜思' : '');
    
    const styleColor = poemStyle === 'grassland' || poemStyle === 'poetry' ? '#90EE90' : (poemStyle === 'life' ? '#ffd700' : (poemStyle === 'default' ? '#e8e8e8' : (poemStyle === 'maoxian' ? '#FFD700' : '#f4a460')));
    const subTextColor = poemStyle === 'grassland' || poemStyle === 'poetry' ? '#7CCD7C' : (poemStyle === 'life' ? '#ffa500' : (poemStyle === 'default' ? '#c0c0c0' : (poemStyle === 'maoxian' ? '#FFA500' : '#d4a574')));
    
    const finalTextColor = showText ? (textColor || styleColor) : 'transparent';

    return `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="${gradientId}" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:${bgGradient[0]};stop-opacity:1" />
          <stop offset="100%" style="stop-color:${bgGradient[1]};stop-opacity:1" />
        </linearGradient>
        <radialGradient id="${moonGlowId}" cx="50%" cy="50%" r="50%">
          <stop offset="0%" style="stop-color:#fffacd;stop-opacity:0.9" />
          <stop offset="60%" style="stop-color:#f5f5dc;stop-opacity:0.3" />
          <stop offset="100%" style="stop-color:#f5f5dc;stop-opacity:0" />
        </radialGradient>
        <radialGradient id="${sunGlowId}" cx="50%" cy="50%" r="50%">
          <stop offset="0%" style="stop-color:#FFD700;stop-opacity:1" />
          <stop offset="50%" style="stop-color:#FFA500;stop-opacity:0.5" />
          <stop offset="100%" style="stop-color:#FF8C00;stop-opacity:0" />
        </radialGradient>
        <filter id="${glowFilterId}">
          <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      
      <rect width="100%" height="100%" fill="url(#${gradientId})"/>
      
      ${poemStyle === 'moonlight' ? `
        ${scene.stars ? starsSvg : ''}
        ${scene.moon ? `
          <circle cx="${width * (scene.moonX || 0.7)}" cy="${height * (scene.moonY || 0.22)}" r="${width * (scene.moonSize || 0.12)}" fill="url(#${moonGlowId})" filter="url(#${glowFilterId})"/>
          <circle cx="${width * (scene.moonX || 0.7)}" cy="${height * (scene.moonY || 0.22)}" r="${width * (scene.moonSize || 0.12) * 0.7}" fill="#fffacd" opacity="0.95"/>
        ` : ''}
        ${scene.frost ? `
          <rect x="0" y="${height * 0.5}" width="${width}" height="${height * 0.5}" fill="#e8e8f0" opacity="${scene.frostIntensity || 0.15}"/>
        ` : ''}
        ${scene.mountain ? `
          <path d="${mountainPath}" fill="#1a1a2e" opacity="0.9"/>
          <path d="${this.generateMountainPath(width, height, (scene.mountainY || 0.6) + 0.08, frameIndex)}" fill="#252540" opacity="0.8"/>
        ` : ''}
        ${scene.tree ? `
          <g transform="translate(${width * 0.15}, ${height * 0.45})">
            <path d="M0,0 L0,-${height * 0.3}" stroke="#4a3728" stroke-width="8" fill="none"/>
            <path d="M0,-${height * 0.1} Q${width * 0.1},-${height * 0.15} ${width * 0.15},-${height * 0.08}" stroke="#3d5c3d" stroke-width="4" fill="none"/>
            <path d="M0,-${height * 0.2} Q${width * -0.08},-${height * 0.25} ${width * -0.12},-${height * 0.15}" stroke="#3d5c3d" stroke-width="4" fill="none"/>
            <ellipse cx="0" cy="-${height * 0.32}" rx="${width * 0.08}" ry="${height * 0.06}" fill="#2d4a2d" opacity="0.8"/>
          </g>
        ` : ''}
        ${scene.person ? `
          <g transform="translate(${width * 0.4}, ${height * 0.4})">
            <circle cx="0" cy="-${height * 0.12}" r="${width * 0.03}" fill="#e0c8b0"/>
            <path d="M0,-${height * 0.09} L0,${height * 0.05}" stroke="#8b7355" stroke-width="6" fill="none"/>
            ${scene.personPose === 'looking_up' ? `
              <path d="M0,-${height * 0.09} L-${width * 0.04},-${height * 0.12}" stroke="#8b7355" stroke-width="4" fill="none"/>
              <path d="M0,-${height * 0.09} L${width * 0.04},-${height * 0.12}" stroke="#8b7355" stroke-width="4" fill="none"/>
            ` : `
              <path d="M0,-${height * 0.06} L-${width * 0.03},${height * 0.02}" stroke="#8b7355" stroke-width="4" fill="none"/>
              <path d="M0,-${height * 0.06} L${width * 0.03},${height * 0.02}" stroke="#8b7355" stroke-width="4" fill="none"/>
            `}
            <path d="M0,${height * 0.05} L-${width * 0.03},${height * 0.15}" stroke="#5c4a3d" stroke-width="5" fill="none"/>
            <path d="M0,${height * 0.05} L${width * 0.03},${height * 0.15}" stroke="#5c4a3d" stroke-width="5" fill="none"/>
          </g>
        ` : ''}
      ` : ''}

      ${styleKey === 'title' ? `
        <text x="50%" y="${height * 0.42}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.08}" fill="${finalTextColor}" text-anchor="middle" letter-spacing="6" filter="url(#${glowFilterId})">${showText ? this.escapeXml(title) : ''}</text>
        <text x="50%" y="${height * 0.52}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.04}" fill="${showText ? subTextColor : 'transparent'}" text-anchor="middle" letter-spacing="4" opacity="0.9">${showText && authorText ? this.escapeXml(authorText) : ''}</text>
      ` : `
        ${showText ? this.renderWrappedText(text, width * 0.5, height * 0.4, Math.min(width, height) * 0.055, Math.min(width, height) * 0.075, finalTextColor, finalTextColor, 0.5) : ''}
      `}
      
      ${(poemName && authorText) ? `
        <text x="50%" y="${height * 0.95}" font-family="KaiTi, STKaiti, serif" font-size="${Math.min(width, height) * 0.022}" fill="#888" text-anchor="middle" opacity="0.5">${poemName} · ${authorText}</text>
      ` : ''}
    </svg>`;
  }

  renderStars(count, seed) {
    let stars = '';
    for (let i = 0; i < count; i++) {
      const x = ((i * 137.5 + seed * 50) % 100) / 100;
      const y = ((i * 97.3 + seed * 30) % 60) / 100;
      const r = 1 + (i % 3);
      const opacity = 0.4 + (i % 5) * 0.1;
      stars += `<circle cx="${x * 100}%" cy="${y * 100}%" r="${r}" fill="#ffffff" opacity="${opacity}"/>`;
    }
    return stars;
  }

  generateMountainPath(width, height, baseY, seed) {
    const offset = seed * 20;
    return `M0,${height * baseY} Q${width * 0.15 + offset},${height * (baseY - 0.08)} ${width * 0.25},${height * (baseY - 0.03)} T${width * 0.5},${height * (baseY - 0.05)} T${width * 0.75},${height * (baseY - 0.02)} T${width},${height * (baseY - 0.06)} V${height} H0 Z`;
  }

  escapeXml(text) {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  wrapText(text, maxWidth, fontSize, width) {
    const lines = [];
    const sentences = text.split(/([，。！？；、：\n]+)/);
    let currentLine = '';
    
    for (const segment of sentences) {
      if (/^[，。！？；、：\n]+$/.test(segment)) {
        if (currentLine) {
          lines.push(currentLine);
          currentLine = '';
        }
      } else {
        if (currentLine) {
          currentLine += segment;
        } else {
          currentLine = segment;
        }
      }
    }
    if (currentLine) lines.push(currentLine);
    
    return lines;
  }

  renderWrappedText(text, x, y, fontSize, lineHeight, textColor, strokeColor, strokeWidth) {
    const maxWidth = 850;
    const lines = this.wrapText(text, maxWidth, fontSize, 1080);
    
    const baseFontSize = fontSize;
    
    const getFontSizeForLine = (line) => {
      const chars = line.length;
      if (chars <= 10) return baseFontSize;
      if (chars <= 15) return baseFontSize * 0.85;
      if (chars <= 20) return baseFontSize * 0.7;
      if (chars <= 30) return baseFontSize * 0.6;
      if (chars <= 40) return baseFontSize * 0.5;
      return baseFontSize * 0.4;
    };
    
    const adjustedLineHeight = lineHeight;
    const totalHeight = lines.length * adjustedLineHeight;
    let startY = y - (totalHeight / 2) + adjustedLineHeight / 2;
    
    return lines.map((line, i) => {
      const lineFontSize = getFontSizeForLine(line);
      return `<text x="${x}" y="${startY + i * adjustedLineHeight}" 
            font-family="KaiTi, STKaiti, serif" 
            font-size="${lineFontSize}" 
            fill="${textColor}" 
            text-anchor="middle"
            ${strokeColor ? `stroke="${strokeColor}" stroke-width="${strokeWidth}"` : ''}>${this.escapeXml(line)}</text>`;
    }).join('');
  }

  renderGrass(width, height, scene, frameIndex) {
    if (!scene.grass) return '';
    
    const grassY = height * (scene.grassY || 0.55);
    const grassHeight = height * (scene.grassHeight || 0.2);
    const grassColor = scene.grassColor || '#5a8a4a';
    const density = scene.grassDensity || 0.7;
    
    let grassSvg = '';
    const bladeCount = Math.floor(30 * density);
    
    for (let i = 0; i < bladeCount; i++) {
      const x = (i / bladeCount) * width + (Math.sin(i * 3 + frameIndex) * 20);
      const h = grassHeight * (0.7 + Math.sin(i * 2.5 + frameIndex * 0.5) * 0.3);
      const curve = (Math.sin(i * 4 + frameIndex) * 15);
      const color = this.lightenColor(grassColor, Math.sin(i * 3) * 20);
      
      grassSvg += `<path d="M${x},${grassY} Q${x + curve},${grassY - h * 0.6} ${x + curve * 0.5},${grassY - h}" stroke="${color}" stroke-width="2" fill="none" opacity="0.8"/>`;
    }
    
    grassSvg += `<rect x="0" y="${grassY}" width="${width}" height="${height - grassY}" fill="${grassColor}" opacity="0.6"/>`;
    
    return grassSvg;
  }

  renderSun(width, height, scene, glowId) {
    if (!scene.sun) return '';
    
    const sunX = width * (scene.sunX || 0.5);
    const sunY = height * (scene.sunY || 0.15);
    const sunSize = width * 0.1;
    
    let rays = '';
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const x1 = sunX + Math.cos(angle) * sunSize * 1.2;
      const y1 = sunY + Math.sin(angle) * sunSize * 1.2;
      const x2 = sunX + Math.cos(angle) * sunSize * 1.8;
      const y2 = sunY + Math.sin(angle) * sunSize * 1.8;
      rays += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#FFD700" stroke-width="3" opacity="0.6"/>`;
    }
    
    return `
      <circle cx="${sunX}" cy="${sunY}" r="${sunSize * 2}" fill="url(#${glowId})"/>
      <circle cx="${sunX}" cy="${sunY}" r="${sunSize * 1.2}" fill="#FFD700" opacity="0.9"/>
      <circle cx="${sunX}" cy="${sunY}" r="${sunSize}" fill="#FFEC8B"/>
      ${rays}
    `;
  }

  renderFire(width, height, scene, glowId) {
    if (!scene.fire) return '';
    
    const fireY = height * 0.6;
    const fireX = width * 0.5;
    const flameHeight = height * 0.25;
    
    let flames = '';
    for (let i = 0; i < 5; i++) {
      const x = fireX + (i - 2) * width * 0.08;
      const h = flameHeight * (0.6 + Math.sin(i * 1.5) * 0.3);
      const hue = 20 + i * 5;
      flames += `<ellipse cx="${x}" cy="${fireY}" rx="${width * 0.05}" ry="${h}" fill="hsl(${hue}, 100%, 50%)" opacity="0.8"/>`;
    }
    
    return `
      <ellipse cx="${fireX}" cy="${fireY + flameHeight * 0.3}" rx="${width * 0.25}" ry="${flameHeight * 0.4}" fill="#8B0000" opacity="0.5"/>
      <ellipse cx="${fireX}" cy="${fireY}" rx="${width * 0.2}" ry="${flameHeight * 0.6}" fill="#FF4500" opacity="0.7"/>
      ${flames}
      <ellipse cx="${fireX}" cy="${fireY - flameHeight * 0.2}" rx="${width * 0.12}" ry="${flameHeight * 0.5}" fill="#FFD700" opacity="0.6"/>
    `;
  }

  darkenColor(hex, percent) {
    const num = parseInt(hex.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = Math.max((num >> 16) - amt, 0);
    const G = Math.max((num >> 8 & 0x00FF) - amt, 0);
    const B = Math.max((num & 0x0000FF) - amt, 0);
    return `#${(0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)}`;
  }

  lightenColor(hex, percent) {
    const num = parseInt(hex.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = Math.min((num >> 16) + amt, 255);
    const G = Math.min((num >> 8 & 0x00FF) + amt, 255);
    const B = Math.min((num & 0x0000FF) + amt, 255);
    return `#${(0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)}`;
  }
}

export default ImageGenerator;
