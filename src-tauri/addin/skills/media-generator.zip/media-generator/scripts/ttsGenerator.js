import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import ffmpeg from 'fluent-ffmpeg';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

class TTSGenerator {
  constructor(options = {}) {
    this.outputDir = options.outputDir || path.join(__dirname, '../../output');
    fs.mkdirSync(this.outputDir, { recursive: true });
  }

  async generate(text, options = {}) {
    const {
      voice = 'zh-CN-XiaoxiaoNeural',
      outputPath = null,
    } = options;

    console.log(`- Generating speech...`);

    const filename = outputPath || `speech_${Date.now()}.m4a`;
    let filepath;
    if (outputPath) {
      filepath = outputPath;
    } else {
      filepath = path.join(this.outputDir, filename);
    }
    const tempFile = path.join(this.outputDir, `temp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.mp3`);
    
    const { EdgeTTS } = await import('edge-tts-universal');
    const tts = new EdgeTTS(text, voice);
    
    let audioBuffer;
    try {
      const result = await tts.synthesize();
      audioBuffer = Buffer.from(await result.audio.arrayBuffer());
    } catch (err) {
      const { Communicate } = await import('edge-tts-universal');
      const communicate = new Communicate(text, { voice: voice });
      
      const buffers = [];
      for await (const chunk of communicate.stream()) {
        if (chunk.type === 'audio' && chunk.data) {
          buffers.push(chunk.data);
        }
      }
      audioBuffer = Buffer.concat(buffers);
    }
    
    if (!audioBuffer || audioBuffer.length === 0) {
      throw new Error('No audio was received from TTS service');
    }
    
    fs.writeFileSync(tempFile, audioBuffer);

    await new Promise((resolve, reject) => {
      ffmpeg(tempFile)
        .audioCodec('aac')
        .toFormat('mp4')
        .on('end', resolve)
        .on('error', reject)
        .save(filepath);
    });

    try { fs.unlinkSync(tempFile); } catch (e) {}

    console.log(`✔ Speech saved: ${filepath}`);
    return filepath;
  }

  static getAvailableVoices() {
    return [
      'zh-CN-XiaoxiaoNeural',
      'zh-CN-YunxiNeural',
      'zh-CN-YunyangNeural',
      'en-US-JennyNeural',
      'en-US-GuyNeural'
    ];
  }
}

export default TTSGenerator;
