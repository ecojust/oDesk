import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import sharp from 'sharp';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function generateId() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

function generateUUID() {
  return crypto.randomUUID().toUpperCase();
}

class JianyingDraftGenerator {
  constructor(options = {}) {
    this.draftDir = options.outputDir || path.join(__dirname, '../../jianying_drafts');
  }

  async createDraft(options = {}) {
    const {
      title = 'AI Generated Video',
      videoPath = null,
      audioPath = null,
      width = 1920,
      height = 1080,
      duration = 10000,
    } = options;

    const draftName = title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '_');
    const draftFolder = path.join(this.draftDir, draftName);

    if (fs.existsSync(draftFolder)) {
      fs.rmSync(draftFolder, { recursive: true, force: true });
    }

    fs.mkdirSync(draftFolder, { recursive: true });
    fs.mkdirSync(path.join(draftFolder, 'Timelines'), { recursive: true });

    const materialDir = path.join(draftFolder, 'material');
    fs.mkdirSync(materialDir, { recursive: true });

    const now = Math.floor(Date.now() / 1000);
    const timelineId = generateUUID();
    const timelineFolder = path.join(draftFolder, 'Timelines', timelineId);
    fs.mkdirSync(timelineFolder, { recursive: true });
    fs.mkdirSync(path.join(timelineFolder, 'common_attachment'), { recursive: true });

    let videoId = null;
    let audioId = null;

    if (videoPath && fs.existsSync(videoPath)) {
      videoId = generateId();
      const ext = path.extname(videoPath).toLowerCase();
      const newPath = path.join(materialDir, `${videoId}${ext}`);
      fs.copyFileSync(videoPath, newPath);
      console.log(`  Video copied: ${newPath}`);
    }

    if (audioPath && fs.existsSync(audioPath)) {
      audioId = generateId();
      const ext = path.extname(audioPath).toLowerCase();
      const newPath = path.join(materialDir, `${audioId}${ext}`);
      fs.copyFileSync(audioPath, newPath);
      console.log(`  Audio copied: ${newPath}`);
    }

    const tracks = [];
    const materials = {
      videos: [],
      images: [],
      audios: [],
      ai_translates: [], audio_balances: [], audio_effects: [], audio_fades: [],
      audio_pannings: [], audio_pitch_shifts: [], audio_track_indexes: [],
      beats: [], canvases: [], chromas: [], color_curves: [], common_mask: [],
      digital_human_model_dressing: [], digital_humans: [], drafts: [], effects: [],
      flowers: [], green_screens: [], handwrites: [], hsl: [], hsl_curves: [],
      log_color_wheels: [], loudnesses: [], manual_beautys: [],
      manual_deformations: [], material_animations: [], material_colors: [],
      multi_language_refs: [], placeholder_infos: [], placeholders: [],
      plugin_effects: [], primary_color_wheels: [], realtime_denoises: [],
      shapes: [], smart_crops: [], smart_relights: [], sound_channel_mappings: [],
      speeds: [], stickers: [], tail_leaders: [], text_templates: [], texts: [],
      time_marks: [], transitions: [], video_effects: [], video_radius: [],
      video_shadows: [], video_strokes: [], video_trackings: [],
      vocal_beautifys: [], vocal_separations: []
    };

    if (videoId) {
      const vidExt = path.extname(videoPath).toLowerCase();
      materials.videos.push({
        id: videoId,
        name: path.basename(videoPath),
        path: path.join(materialDir, `${videoId}${vidExt}`),
        width: width,
        height: height,
        duration: duration,
        type: 0,
        hdr: false,
        rotate: 0,
        crop: { x: 0, y: 0, w: 100, h: 100 },
        crop_mode: 0,
        flip: { horizontal: false, vertical: false },
        audio_path: "",
        audio_name: "",
        volume: 1,
        is_copyright: false,
        material_id: videoId,
        extra_info: "{\"platform\":\"web\",\"material_source\":\"local\"}",
        create_time: now,
        is_from_template: false,
        template_id: "",
        is_private_material: false,
        local_peer_id: "",
        ai_function_type: 0,
        label_names: [],
        filter_data: {},
        extra_type: 0,
        video_description: "",
        material_url: "",
        local_material_id: ""
      });

      tracks.push({
        id: generateId(),
        type: 0,
        property: { switch: false, volume: 1 },
        segments: [{
          id: generateId(),
          material_id: videoId,
          track_id: null,
          start_time: 0,
          end_time: duration,
          source_timerange: { start: 0, duration: duration },
          target_timerange: { start: 0, duration: duration },
          speed: 1,
          volume: 1,
          fade_in: { duration: 0, intensity: 0 },
          fade_out: { duration: 0, intensity: 0 },
          transition_id: "",
          filter_data: { light: 0, contrast: 0, saturation: 0 },
          rotate: 0,
          flip: { horizontal: false, vertical: false },
          scale: 1,
          position: { x: 0.5, y: 0.5 },
          crop: { top: 0, bottom: 0, left: 0, right: 0 }
        }]
      });
    }

    if (audioId) {
      const audExt = path.extname(audioPath).toLowerCase();
      materials.audios.push({
        id: audioId,
        name: path.basename(audioPath),
        path: path.join(materialDir, `${audioId}${audExt}`),
        duration: duration,
        type: 1,
        audio_name: path.basename(audioPath),
        volume: 1,
        is_copyright: false,
        material_id: audioId,
        extra_info: "{\"platform\":\"web\",\"material_source\":\"local\"}",
        create_time: now,
        is_from_template: false,
        template_id: "",
        is_private_material: false,
        local_peer_id: "",
        ai_function_type: 0,
        label_names: [],
        extra_type: 0,
        material_url: "",
        local_material_id: ""
      });

      tracks.push({
        id: generateId(),
        type: 1,
        property: { switch: false, volume: 1 },
        segments: [{
          id: generateId(),
          material_id: audioId,
          track_id: null,
          start_time: 0,
          end_time: duration,
          source_timerange: { start: 0, duration: duration },
          target_timerange: { start: 0, duration: duration },
          speed: 1,
          volume: 1,
          fade_in: { duration: 0, intensity: 0 },
          fade_out: { duration: 0, intensity: 0 },
          transition_id: "",
          filter_data: { volume: 1 },
          mute: false
        }]
      });
    }

    const templateData = {
      id: timelineId,
      name: draftName,
      duration: duration,
      fps: 30,
      create_time: now,
      update_time: now,
      version: 360000,
      new_version: "75.0.0",
      draft_type: "video",
      source: "default",
      path: "",
      is_drop_frame_timecode: false,
      free_render_index_mode_on: false,
      render_index_track_mode_on: false,
      color_space: -1,
      tracks: tracks,
      materials: materials,
      canvas_config: { width: width, height: height, background: null, ratio: "original" },
      cover: null,
      retouch_cover: null,
      static_cover_image_path: "",
      group_container: null,
      keyframe_graph_list: [],
      keyframes: { videos: [], audios: [], texts: [], stickers: [], effects: [], filters: [], adjusts: [], handwrites: [] },
      function_assistant_info: {
        auto_adjust: false, auto_caption: false, caption_opt: false, enhance_voice: false,
        retouch: false, eye_correction: false, color_correction: false, enhance_quality: false,
        smooth_slow_motion: false, auto_adjust_fixed: false, auto_adjust_fixed_value: 50,
        color_correction_fixed: false, color_correction_fixed_value: 50, enhance_quality_fixed: false,
        smooth_slow_motion_fixed: false, enhance_voice_fixed: false, retouch_fixed: false,
        auto_caption_template_id: "", fixed_rec_applied: false, smart_rec_applied: false,
        fps: { num: 0, den: 1 }, normalize_loudness: false, normalize_loudness_fixed: false,
        deflicker_segid_list: [], enhance_quality_segid_list: [], smooth_slow_motion_segid_list: [],
        enhance_voice_segid_list: [], auto_adjust_segid_list: [], auto_caption_segid_list: [],
        caption_opt_segid_list: [], color_correction_segid_list: [], retouch_segid_list: [],
        video_noise_segid_list: [], audio_noise_segid_list: [], normalize_loudness_segid_list: [],
        normalize_loudness_audio_denoise_segid_list: []
      },
      config: {
        maintrack_adsorb: true, video_mute: false, use_float_render: false,
        combination_max_index: 1, adjust_max_index: 1, sticker_max_index: 1,
        original_sound_last_index: 1, record_audio_last_index: 1, extract_audio_last_index: 1,
        material_save_mode: 0, lyrics_recognition_id: "", subtitle_recognition_id: "",
        lyrics_sync: true, subtitle_sync: true, lyrics_taskinfo: [], subtitle_taskinfo: [],
        multi_language_mode: "none", multi_language_current: "none", multi_language_main: "none",
        multi_language_list: [], subtitle_keywords_config: null, export_range: null,
        attachment_info: [], system_font_list: [], zoom_info_params: null
      },
      lyrics_effects: [], time_marks: null, extra_info: null, mutable_config: null,
      relationships: [], uneven_animation_template_info: { composition: "", content: "", order: "", sub_template_info_list: [] },
      platform: { app_id: 0, app_source: "", app_version: "", device_id: "", hard_disk_id: "", mac_address: "", os: "", os_version: "" },
      last_modified_platform: { app_id: 0, app_source: "", app_version: "", device_id: "", hard_disk_id: "", mac_address: "", os: "", os_version: "" },
      smart_ads_info: { draft_url: "", page_from: "", routine: "" }
    };

    fs.writeFileSync(path.join(timelineFolder, 'template.tmp'), JSON.stringify(templateData));
    fs.writeFileSync(path.join(timelineFolder, 'template-2.tmp'), JSON.stringify(templateData));

    fs.writeFileSync(path.join(timelineFolder, 'attachment_editing.json'), JSON.stringify({
      editing_draft: {
        version: "1.0.0", edit_type: 0, draft_used_recommend_function: "",
        is_use_smart_motion: false, is_use_subtitle_recognition: false, is_use_text_to_audio: false,
        is_use_ai_expand: false, is_use_ai_remove: false, is_use_audio_separation: false,
        is_use_chroma_key: false, is_use_curve_speed: false, is_use_digital_human: false,
        is_use_edit_multi_camera: false, is_use_lip_sync: false, is_use_lock_object: false,
        is_use_loudness_unify: false, is_use_noise_reduction: false, is_use_one_click_beauty: false,
        is_use_one_click_ultra_hd: false, is_use_retouch_face: false, is_use_smart_adjust_color: false,
        is_use_smart_body_beautify: false, is_use_adjust: false, is_open_expand_player: false,
        is_template_text_ai_generate: false,
        crop_info_extra: { crop_mirror_type: 0, crop_rotate: 0.0, crop_rotate_total: 0.0 },
        ai_remove_filter_words: { enter_source: "", right_id: "" },
        ai_shorts_info: { report_params: "", type: 0 },
        digital_human_template_to_video_info: { has_upload_material: false, template_type: 0 },
        image_ai_chat_info: { before_chat_edit: false, draft_modify_time: 0, message_id: "", model_name: "", need_restore: false, picture_id: "", prompt_from: "", sugs_info: [] },
        material_edit_session: { session_id: "", session_time: 0, material_edit_info: [] },
        paste_segment_list: [], text_convert_case_types: [], single_function_type: 0,
        publish_type: "", publish_enter_from: "", profile_entrance_type: "", video_recording_create_draft: "",
        has_adjusted_render_layer: false, eye_correct_enabled_multi_face_time: 0
      }
    }));

    fs.writeFileSync(path.join(timelineFolder, 'attachment_pc_common.json'), JSON.stringify({
      ai_packaging_infos: [], ai_packaging_report_info: {
        caption_id_list: [], commercial_material: "", material_source: "", method: "",
        page_from: "", style: "", task_id: "", text_style: "", tos_id: "", video_category: ""
      },
      broll: { ai_packaging_infos: [], ai_packaging_report_info: {
        caption_id_list: [], commercial_material: "", material_source: "", method: "",
        page_from: "", style: "", task_id: "", text_style: "", tos_id: "", video_category: ""
      }},
      commercial_music_category_ids: [], pc_feature_flag: 0, recognize_tasks: [],
      template_item_infos: [], unlock_template_ids: []
    }));

    fs.mkdirSync(path.join(timelineFolder, 'common_attachment'), { recursive: true });
    fs.writeFileSync(path.join(timelineFolder, 'common_attachment', 'attachment_gen_ai_info.json'), JSON.stringify({
      gen_ai: { version: "1.0.0", id: "", scene: "",
        ai_func_config: { ai_func_list: [], ai_common_configs: [], ai_effect_configs: [], aigc_generation_configs: [] },
        cc_agent_info: { is_agent_used: false, is_agent_stringent_used: false, tool_list: [], agent_stringent_used_tool_list: [] }
      }
    }));
    fs.writeFileSync(path.join(timelineFolder, 'common_attachment', 'attachment_action_scene.json'), JSON.stringify({ action_scene: { version: "1.0.0", id: "", scene: "" } }));
    fs.writeFileSync(path.join(timelineFolder, 'common_attachment', 'attachment_script_video.json'), JSON.stringify({ script_video: { version: "1.0.0", id: "", scene: "", script_content: "" } }));
    fs.writeFileSync(path.join(timelineFolder, 'common_attachment', 'attachment_plugin_draft.json'), JSON.stringify({ plugin_draft: { version: "1.0.0", id: "", scene: "" } }));
    fs.writeFileSync(path.join(timelineFolder, 'common_attachment', 'attachment_pc_timeline.json'), JSON.stringify({ pc_timeline: { version: "1.0.0", id: "", timeline_scale: 1.0 } }));

    fs.writeFileSync(path.join(draftFolder, 'template.tmp'), JSON.stringify({
      canvas_config: { background: null, height: 0, ratio: "original", width: 0 },
      color_space: -1,
      config: { adjust_max_index: 1, attachment_info: [], combination_max_index: 1, export_range: null,
        extract_audio_last_index: 1, lyrics_recognition_id: "", lyrics_sync: true, lyrics_taskinfo: [],
        maintrack_adsorb: true, material_save_mode: 0, multi_language_current: "none", multi_language_list: [],
        multi_language_main: "none", multi_language_mode: "none", original_sound_last_index: 1,
        record_audio_last_index: 1, sticker_max_index: 1, subtitle_keywords_config: null,
        subtitle_recognition_id: "", subtitle_sync: true, subtitle_taskinfo: [], system_font_list: [],
        use_float_render: false, video_mute: false, zoom_info_params: null },
      cover: null, create_time: now, draft_type: "video", duration: 0, extra_info: null, fps: 30,
      free_render_index_mode_on: false,
      function_assistant_info: { audio_noise_segid_list: [], auto_adjust: false, auto_adjust_fixed: false,
        auto_adjust_fixed_value: 50, auto_adjust_segid_list: [], auto_caption: false, auto_caption_segid_list: [],
        auto_caption_template_id: "", caption_opt: false, caption_opt_segid_list: [], color_correction: false,
        color_correction_fixed: false, color_correction_fixed_value: 50, color_correction_segid_list: [],
        deflicker_segid_list: [], enhance_quality: false, enhance_quality_fixed: false,
        enhance_quality_segid_list: [], enhance_voice_segid_list: [], enhande_voice: false,
        enhande_voice_fixed: false, eye_correction: false, eye_correction_segid_list: [],
        fixed_rec_applied: false, fps: { den: 1, num: 0 }, normalize_loudness: false,
        normalize_loudness_audio_denoise_segid_list: [], normalize_loudness_fixed: false,
        normalize_loudness_segid_list: [], retouch: false, retouch_fixed: false, retouch_segid_list: [],
        smart_rec_applied: false, smart_segid_list: [], smooth_slow_motion: false,
        smooth_slow_motion_fixed: false, video_noise_segid_list: [] },
      group_container: null, id: generateUUID(), is_drop_frame_timecode: false,
      keyframe_graph_list: [],
      keyframes: { adjusts: [], audios: [], effects: [], filters: [], handwrites: [], stickers: [], texts: [], videos: [] },
      last_modified_platform: { app_id: 0, app_source: "", app_version: "", device_id: "", hard_disk_id: "", mac_address: "", os: "", os_version: "" },
      lyrics_effects: [], materials: materials,
      mutable_config: null, name: draftName, new_version: "75.0.0", path: "",
      platform: { app_id: 0, app_source: "", app_version: "", device_id: "", hard_disk_id: "", mac_address: "", os: "", os_version: "" },
      relationships: [], render_index_track_mode_on: false, retouch_cover: null,
      smart_ads_info: { draft_url: "", page_from: "", routine: "" },
      source: "default", static_cover_image_path: "", time_marks: null, tracks: [], uneven_animation_template_info: { composition: "", content: "", order: "", sub_template_info_list: [] },
      update_time: now, version: 360000
    }));

    fs.writeFileSync(path.join(draftFolder, 'attachment_editing.json'), fs.readFileSync(path.join(timelineFolder, 'attachment_editing.json')));
    fs.writeFileSync(path.join(draftFolder, 'attachment_pc_common.json'), fs.readFileSync(path.join(timelineFolder, 'attachment_pc_common.json')));
    fs.mkdirSync(path.join(draftFolder, 'common_attachment'), { recursive: true });
    fs.writeFileSync(path.join(draftFolder, 'common_attachment', 'attachment_gen_ai_info.json'), fs.readFileSync(path.join(timelineFolder, 'common_attachment', 'attachment_gen_ai_info.json')));

    const projectJson = {
      config: { color_space: -1, render_index_track_mode_on: false, use_float_render: false },
      create_time: now * 1000,
      id: generateUUID(),
      main_timeline_id: timelineId,
      timelines: [{
        create_time: now * 1000,
        id: timelineId,
        is_marked_delete: false,
        name: draftName,
        update_time: now * 1000
      }],
      update_time: now * 1000,
      version: 0
    };
    fs.writeFileSync(path.join(draftFolder, 'Timelines', 'project.json'), JSON.stringify(projectJson));

    fs.writeFileSync(path.join(draftFolder, 'timeline_layout.json'), JSON.stringify({
      dockItems: [{ dockIndex: 0, ratio: 1, timelineIds: [timelineId], timelineNames: [draftName] }],
      layoutOrientation: 1
    }));

    fs.writeFileSync(path.join(draftFolder, 'draft_settings'), `[General]
cloud_last_modify_platform=mac
draft_create_time=${now}
draft_last_edit_time=${now}
real_edit_keys=1
real_edit_seconds=${Math.floor(duration / 1000)}`);

    fs.writeFileSync(path.join(draftFolder, 'draft_agency_config.json'), JSON.stringify({
      is_auto_agency_enabled: false, is_auto_agency_popup: false, is_single_agency_mode: false,
      marterials: null, use_converter: false, video_resolution: 1080
    }));
    fs.writeFileSync(path.join(draftFolder, 'draft_biz_config.json'), JSON.stringify({}));
    fs.writeFileSync(path.join(draftFolder, 'draft_virtual_store.json'), JSON.stringify({}));
    fs.writeFileSync(path.join(draftFolder, 'draft.extra'), Buffer.alloc(1028));
    fs.writeFileSync(path.join(draftFolder, 'draft_info.json'), Buffer.alloc(100).fill(0).toString());
    fs.writeFileSync(path.join(draftFolder, 'draft_meta_info.json'), Buffer.alloc(100).fill(0).toString());

    fs.mkdirSync(path.join(draftFolder, '.backup'), { recursive: true });

    if (videoPath && fs.existsSync(videoPath)) {
      try {
        await sharp(videoPath).resize(540, 960).jpeg({ quality: 80 }).toFile(path.join(draftFolder, 'draft_cover.jpg'));
        await sharp(videoPath).resize(540, 960).jpeg({ quality: 80 }).toFile(path.join(timelineFolder, 'draft_cover.jpg'));
      } catch (e) { console.log('Cover generation skipped'); }
    }

    console.log(`\n✅ Draft Created!`);
    console.log(`   📁 ${draftFolder}`);
    console.log(`   Video: ${videoId ? 'Yes' : 'No'}`);
    console.log(`   Audio: ${audioId ? 'Yes' : 'No'}`);
    console.log(`   Tracks: ${tracks.length}`);

    return { draftPath: draftFolder, draftFolder };
  }
}

export default JianyingDraftGenerator;
