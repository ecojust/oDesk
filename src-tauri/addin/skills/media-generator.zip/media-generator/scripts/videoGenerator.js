import ffmpeg from 'fluent-ffmpeg';
import path from 'path';
import fs from 'fs';

class VideoGenerator {
  constructor(options = {}) {
    this.outputDir = options.outputDir || './output';
    fs.mkdirSync(this.outputDir, { recursive: true });
  }

  async generate(imagePath, audioPath, outputPath) {
    const filename = outputPath || path.join(this.outputDir, 'video.mp4');
    const isSequence = imagePath.includes('%04d');

    return new Promise((resolve, reject) => {
      const cmd = ffmpeg();
      
      if (isSequence) {
        cmd.input(imagePath)
           .inputOptions(['-framerate', '30', '-stream_loop', '-1']);
      } else {
        cmd.input(imagePath)
           .inputOptions(['-loop', '1', '-framerate', '30']);
      }
      
      cmd.input(audioPath)
        .videoCodec('libx264')
        .videoFilters('scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2')
        .audioCodec('aac')
        .audioBitrate('128k')
        .outputOptions([
          '-pix_fmt', 'yuv420p',
          '-shortest',
          '-tune', 'stillimage'
        ])
        .output(filename)
        .on('end', () => resolve(filename))
        .on('error', (err) => reject(err))
        .run();
    });
  }

  async generateWithFrameTimeline(framePaths, audioPath, outputPath, frameTimeline, audioStartDelay = 0) {
    const filename = outputPath || path.join(this.outputDir, 'video.mp4');
    
    const tempDir = path.join(this.outputDir, 'temp_frames');
    fs.mkdirSync(tempDir, { recursive: true });
    
    for (let i = 0; i < framePaths.length; i++) {
      const src = framePaths[i];
      const dst = path.join(tempDir, `frame_${String(i).padStart(4, '0')}.png`);
      fs.copyFileSync(src, dst);
    }
    
    const segmentPaths = [];
    const segmentDurations = [];
    
    for (let i = 0; i < frameTimeline.length; i++) {
      const { start, end } = frameTimeline[i];
      const duration = end - start;
      const segmentPath = path.join(tempDir, `seg_${String(i).padStart(2, '0')}.mp4`);
      segmentPaths.push(segmentPath);
      segmentDurations.push(duration);
      
      await new Promise((res, rej) => {
        ffmpeg()
          .input(path.join(tempDir, `frame_${String(i).padStart(4, '0')}.png`))
          .inputOptions(['-loop', '1'])
          .videoCodec('libx264')
          .videoFilters(`scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2`)
          .outputOptions([
            '-pix_fmt', 'yuv420p', 
            '-r', '30', 
            '-t', String(duration),
            '-g', '1',
            '-keyint_min', '1',
            '-sc_threshold', '0'
          ])
          .output(segmentPath)
          .on('end', res)
          .on('error', rej)
          .run();
      });
    }
    
    const concatListPath = path.join(tempDir, 'concat.txt');
    let concatContent = segmentPaths.map(p => `file '${p}'`).join('\n');
    fs.writeFileSync(concatListPath, concatContent);
    
    const finalVideoPath = path.join(tempDir, 'video_no_audio.mp4');
    
    await new Promise((resolve, reject) => {
      ffmpeg()
        .input(concatListPath)
        .inputOptions(['-f', 'concat', '-safe', '0'])
        .videoCodec('libx264')
        .outputOptions(['-pix_fmt', 'yuv420p'])
        .output(finalVideoPath)
        .on('end', resolve)
        .on('error', reject)
        .run();
    });
    
    let audioToUse = audioPath;
    if (audioStartDelay > 0) {
      audioToUse = path.join(tempDir, 'audio_delayed.m4a');
      const delayCmd = `ffmpeg -f lavfi -i anullsrc=channel_layout=mono:sample_rate=22050 -t ${audioStartDelay} -i "${audioPath}" -filter_complex "[0:a][1:a]concat=n=2:v=0:a=1" -shortest "${audioToUse}"`;
      const { exec } = await import('child_process');
      await new Promise((resolve, reject) => {
        exec(delayCmd, (err) => err ? reject(err) : resolve());
      });
    }
    
    return new Promise((resolve, reject) => {
      ffmpeg()
        .input(finalVideoPath)
        .input(audioToUse)
        .videoCodec('libx264')
        .audioCodec('aac')
        .audioBitrate('192k')
        .outputOptions(['-pix_fmt', 'yuv420p', '-map', '0:v', '-map', '1:a'])
        .output(filename)
        .on('end', () => {
          // Keep temp dir for debugging
          // fs.rmSync(tempDir, { recursive: true });
          resolve(filename);
        })
        .on('error', (err) => {
          if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true });
          reject(err);
        })
        .run();
    });
  }
}

export default VideoGenerator;
