import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const configPath = path.join(__dirname, '../config.json');

const config = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, 'utf-8')) : {};

const cliArgs = {};
for (const arg of process.argv.slice(2)) {
  if (arg.startsWith('--')) {
    const [key, value] = arg.slice(2).split('=');
    cliArgs[key] = value;
  }
}

const title = cliArgs.title || config.title;
const text = cliArgs.text || config.text;
const voice = cliArgs.voice || config.voice;
const videoPath = cliArgs.video || config.video || null;

const imageConfig = {
  width: parseInt(cliArgs.width) || config.image?.width || 1920,
  height: parseInt(cliArgs.height) || config.image?.height || 1080,
};

async function main() {
  const TTSGenerator = (await import('./ttsGenerator.js')).default;
  const ImageGenerator = (await import('./imageGenerator.js')).default;
  const VideoGenerator = (await import('./videoGenerator.js')).default;

  const projectRoot = path.join(__dirname, '../../../..');
  const outputDir = path.join(projectRoot, 'output');

  if (fs.existsSync(outputDir)) {
    fs.rmSync(outputDir, { recursive: true });
  }
  fs.mkdirSync(outputDir, { recursive: true });

  const ttsGen = new TTSGenerator({ outputDir });
  const imageGen = new ImageGenerator({ outputDir });
  const videoGen = new VideoGenerator({ outputDir });

  try {
    console.log(`\n📖 Generating: "${title}"\n`);

    console.log(`🖼️ Generating cover image...`);
    const imageConfig = {
      width: 1080,
      height: 1920,
      backgroundColor: '#2e1a1a',
      textColor: '#f4a460',
    };
    const imagePath = await imageGen.generate(title, imageConfig);

    console.log(`🔊 Generating speech...`);
    const audioPath = await ttsGen.generate(text, { voice });

    const imageFiles = fs.readdirSync(outputDir).filter(f => f.endsWith('.png'));
    const audioFiles = fs.readdirSync(outputDir).filter(f => f.endsWith('.m4a'));
    
    if (imageFiles.length > 0 && audioFiles.length > 0) {
      const hasSequence = imagePath.includes('%04d');
      const imgPath = hasSequence ? imagePath : path.join(outputDir, imageFiles[0]);
      const audPath = path.join(outputDir, audioFiles[0]);
      const outputPath = path.join(outputDir, 'video.mp4');
      
      console.log(`🎬 Generating video...`);
      const videoPath = await videoGen.generate(imgPath, audPath, outputPath);
      
      console.log(`\n✅ Done!`);
      console.log(`   🖼️ ${imageFiles.length} animated frames`);
      console.log(`   🔊 ${audPath}`);
      console.log(`   🎬 ${videoPath}`);
    }
  } catch (error) {
    console.error(`\n❌ Error: ${error.message}`);
    process.exit(1);
  }
}

main();
