---
name: pixabay-image-downloader
description: 从 Pixabay 下载随机插画图片。当用户提到从 pixabay 下载图片、获取随机插画、保存图片时使用。需要 puppeteer-core@^23.0.0。
---

# Pixabay 图片下载器

从 Pixabay 插画搜索页面下载图片，支持翻页和去重记录。

## 快速使用

```bash
node scripts/download_images.js 10  # 下载10张
```

## 依赖安装

```bash
npm install puppeteer-core@^23.0.0
```

## 脚本 (`download_images.js`)

```javascript
const puppeteer = require("puppeteer-core");
const fs = require("fs");
const https = require("https");
const http = require("http");
const path = require("path");

const DOWNLOAD_DIR = "./pixabay_images";
const HISTORY_FILE = path.join(DOWNLOAD_DIR, "downloaded.txt");
const COUNT = parseInt(process.argv[2]) || 1;

function getDownloadedUrls() {
  if (fs.existsSync(HISTORY_FILE)) {
    return new Set(
      fs.readFileSync(HISTORY_FILE, "utf8").split("\n").filter(Boolean)
    );
  }
  return new Set();
}

function addToHistory(url) {
  fs.appendFileSync(HISTORY_FILE, url + "\n", "utf8");
}

async function downloadPixabayImages() {
  if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
  }

  const browser = await puppeteer.launch({
    executablePath:
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: false,
    args: ["--no-sandbox", "--disable-setuid-sandbox"]
  });

  const page = await browser.newPage();
  await page.setRequestInterception(true);

  const downloadedUrls = getDownloadedUrls();
  console.log("Already downloaded:", downloadedUrls.size);

  let imageUrls = new Set();
  page.on("request", (request) => {
    const url = request.url();
    if (
      url.includes("cdn.pixabay.com/photo/") &&
      (url.includes(".jpg") || url.includes(".png"))
    ) {
      imageUrls.add(url);
    }
    request.continue();
  });

  let downloaded = 0;
  let pageNum = 1;

  while (downloaded < COUNT) {
    const url = `https://pixabay.com/zh/illustrations/search/?order=ec&pagi=${pageNum}`;
    console.log(`Page ${pageNum}: ${url}`);
    await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
    await new Promise((r) => setTimeout(r, 2000));

    const newUrls = [...imageUrls].filter((url) => !downloadedUrls.has(url));
    console.log(`  Found ${imageUrls.size} total, ${newUrls.length} new`);

    for (const url of newUrls) {
      if (downloaded >= COUNT) break;
      const filename = path.join(DOWNLOAD_DIR, `pixabay_${Date.now()}_${downloaded}.jpg`);
      console.log(`  Downloading [${downloaded + 1}/${COUNT}]`);
      try {
        await downloadFile(url, filename);
        addToHistory(url);
        downloaded++;
      } catch (err) {
        console.error("  Download failed:", err.message);
      }
    }

    if (newUrls.length === 0 || downloaded >= COUNT) break;
    pageNum++;
  }

  await browser.close();
  console.log(`Done! Downloaded ${downloaded} images.`);
}

function downloadFile(url, filename) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const client = urlObj.protocol === "https:" ? https : http;

    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        Referer: "https://pixabay.com/"
      }
    };

    const req = client.get(options, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        resolve(downloadFile(res.headers.location, filename));
        return;
      }

      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode}`));
        return;
      }

      const file = fs.createWriteStream(filename);
      res.pipe(file);
      file.on("finish", () => {
        file.close();
        resolve(filename);
      });
    });

    req.on("error", reject);
  });
}

downloadPixabayImages().catch(console.error);
```

## 输出

- 图片目录: `pixabay_images/`
- 下载历史: `pixabay_images/downloaded.txt`

## 注意事项

- Chrome 路径: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`
- 使用翻页参数 `&pagi=N` 加载更多图片
- 支持指定下载数量: `node scripts/download_images.js N`
- 自动跳过已下载图片