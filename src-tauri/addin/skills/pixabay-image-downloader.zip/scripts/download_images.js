const puppeteer = require("puppeteer-core");
const fs = require("fs");
const https = require("https");
const http = require("http");
const path = require("path");

// 项目根目录: scripts -> skill -> .opencode/skill -> .opencode -> 项目根目录
const PROJECT_ROOT = path.join(__dirname, "..", "..", "..", "..");
const DOWNLOAD_DIR = path.join(PROJECT_ROOT, "pixabay_images");
const HISTORY_FILE = path.join(DOWNLOAD_DIR, "downloaded.txt");
const COUNT = parseInt(process.argv[2]) || 1;

function getDownloadedUrls() {
  if (fs.existsSync(HISTORY_FILE)) {
    return new Set(
      fs.readFileSync(HISTORY_FILE, "utf8").split("\n").filter(Boolean),
    );
  }
  return new Set();
}

function addToHistory(url) {
  fs.appendFileSync(HISTORY_FILE, url + "\n", "utf8");
}

async function downloadPixabayImages() {
  if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
  }

  const browser = await puppeteer.launch({
    executablePath:
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: false,
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });

  const page = await browser.newPage();
  await page.setRequestInterception(true);

  const downloadedUrls = getDownloadedUrls();
  console.log("Already downloaded:", downloadedUrls.size);

  let imageUrls = new Set();
  page.on("request", (request) => {
    const url = request.url();
    if (
      url.includes("cdn.pixabay.com/photo/") &&
      (url.includes(".jpg") || url.includes(".png"))
    ) {
      imageUrls.add(url);
    }
    request.continue();
  });

  let downloaded = 0;
  let pageNum = 1;

  while (downloaded < COUNT) {
    const url = `https://pixabay.com/zh/illustrations/search/?order=ec&pagi=${pageNum}`;
    console.log(`Page ${pageNum}: ${url}`);
    await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
    await new Promise((r) => setTimeout(r, 2000));

    const newUrls = [...imageUrls].filter((url) => !downloadedUrls.has(url));
    console.log(`  Found ${imageUrls.size} total, ${newUrls.length} new`);

    for (const url of newUrls) {
      if (downloaded >= COUNT) break;
      const timestamp = Date.now();
      const filename = path.join(
        DOWNLOAD_DIR,
        `pixabay_${timestamp}_${downloaded}.jpg`,
      );
      console.log(`  Downloading [${downloaded + 1}/${COUNT}] ${url}`);
      try {
        await downloadFile(url, filename);
        addToHistory(url);
        downloaded++;
        console.log(`  Saved: ${filename}`);
      } catch (err) {
        console.error("  Download failed:", err.message);
      }
    }

    if (newUrls.length === 0 || downloaded >= COUNT) break;
    pageNum++;
  }

  await browser.close();
  console.log(`Done! Downloaded ${downloaded} images.`);
}

function downloadFile(url, filename) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const client = urlObj.protocol === "https:" ? https : http;

    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        Referer: "https://pixabay.com/",
      },
    };

    const req = client.get(options, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        resolve(downloadFile(res.headers.location, filename));
        return;
      }

      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode}`));
        return;
      }

      const file = fs.createWriteStream(filename);
      res.pipe(file);
      file.on("finish", () => {
        file.close();
        resolve(filename);
      });
    });

    req.on("error", reject);
  });
}

downloadPixabayImages().catch(console.error);
